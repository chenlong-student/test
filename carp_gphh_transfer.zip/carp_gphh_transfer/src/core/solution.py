"""
解的表示：用于成本计算的 Route 和 Solution 类。

Route 是一辆车所服务弧的序列。
Solution 是覆盖所有需求弧的 Route 集合。
"""

import math
from copy import deepcopy
from typing import List, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from .graph import Arc, Graph


class Route:
    """单条车辆路径：服务弧序列 + 弧之间的空驶成本。

    追踪:
        - 按顺序服务的弧
        - 弧之间的空驶（空车通行）距离
        - 总成本分解（服务 + 空驶）
        - 载重和容量利用率
    """

    def __init__(self, vehicle_id: int = 0, depot: int = 1,
                 capacity: float = float("inf")):
        self.vehicle_id = vehicle_id
        self.depot = depot
        self.capacity = capacity
        self._arcs: List["Arc"] = []
        self._deadhead_costs: List[float] = []
        self._cumulative_load: List[float] = []

    def add_arc(self, arc: "Arc", deadhead_cost: float) -> None:
        """向路径追加一条弧。

        参数:
            arc: 被服务的弧。
            deadhead_cost: 从上一位置到弧起点的空驶成本。
        """
        self._arcs.append(arc)
        self._deadhead_costs.append(deadhead_cost)
        prev_load = self._cumulative_load[-1] if self._cumulative_load else 0.0
        self._cumulative_load.append(prev_load + arc.demanda)

    @property
    def arcs(self) -> List["Arc"]:
        return self._arcs

    @property
    def num_arcs(self) -> int:
        return len(self._arcs)

    @property
    def total_demand(self) -> float:
        return sum(a.demanda for a in self._arcs)

    @property
    def service_cost(self) -> float:
        """弧服务成本之和。"""
        return sum(a.coste for a in self._arcs)

    @property
    def deadhead_cost(self) -> float:
        """弧之间空驶通行成本之和。"""
        return sum(self._deadhead_costs)

    @property
    def total_cost(self) -> float:
        """路径总成本 = 服务成本 + 空驶成本。"""
        return self.service_cost + self.deadhead_cost

    @property
    def utilization(self) -> float:
        """容量利用率：total_demand / capacity。"""
        if self.capacity <= 0 or math.isinf(self.capacity):
            return 0.0
        return self.total_demand / self.capacity

    def __len__(self) -> int:
        return len(self._arcs)

    def __repr__(self) -> str:
        return (f"Route(v{self.vehicle_id}, arcs={len(self._arcs)}, "
                f"load={self.total_demand:.0f}/{self.capacity:.0f}, "
                f"cost={self.total_cost:.1f})")


class Solution:
    """完整解：覆盖所有需求弧的一组路径。

    提供总成本计算、可行性检查和比较功能。
    """

    def __init__(self, depot: int = 1, capacity: float = float("inf"),
                 num_vehicles: int = 1):
        self.depot = depot
        self.capacity = capacity
        self.num_vehicles = num_vehicles
        self.routes: List[Route] = []
        self.final_return_costs: List[float] = []  # 每辆车返回车场的成本

    def add_route(self, route: Route, return_cost: float = 0.0) -> None:
        """向解中添加一条已完成路径。"""
        self.routes.append(route)
        self.final_return_costs.append(return_cost)

    @property
    def total_cost(self) -> float:
        """解的总成本 = 所有路径成本之和 + 返回车场成本之和。"""
        return sum(r.total_cost for r in self.routes) + sum(self.final_return_costs)

    @property
    def total_service_cost(self) -> float:
        return sum(r.service_cost for r in self.routes)

    @property
    def total_deadhead_cost(self) -> float:
        return sum(r.deadhead_cost for r in self.routes) + sum(self.final_return_costs)

    @property
    def num_routes_used(self) -> int:
        """非空路径数量。"""
        return sum(1 for r in self.routes if len(r) > 0)

    @property
    def total_arcs_serviced(self) -> int:
        return sum(len(r) for r in self.routes)

    def is_feasible(self, total_required_arcs: int) -> bool:
        """检查是否所有需求弧都已被服务。"""
        return self.total_arcs_serviced == total_required_arcs

    def __lt__(self, other: "Solution") -> bool:
        return self.total_cost < other.total_cost

    def __repr__(self) -> str:
        return (f"Solution(routes={self.num_routes_used}, "
                f"cost={self.total_cost:.1f}, "
                f"service={self.total_service_cost:.1f}, "
                f"deadhead={self.total_deadhead_cost:.1f})")