"""
弧路径问题的图表示。

提供 Arc（带需求/成本的有向边）和 Graph（邻接表 + OD矩阵）类，
供 CPP 和 CARP 环境共同使用。
"""

import math
import heapq
from copy import deepcopy
from typing import List, Dict, Tuple, Optional


class Arc:
    """图中的有向弧，具有需求量和通行成本。

    每条弧都有一个强制配对的逆向弧（通过 set_reverse 绑定）。
    CARP：需求弧 demand > 0，非需求弧 demand = 0。
    CPP：  所有弧 demand = 1（全部需要服务）。

    属性:
        start_vertex: 起始节点编号（从1开始）。
        end_vertex:   结束节点编号（从1开始）。
        demanda:      当前需求值（可能相对原始值有扰动）。
        coste:        当前通行成本（可能相对原始值有扰动）。
        demanda_original: 扰动前的原始需求。
        coste_original:   扰动前的原始成本。
        reverse_arc:  指向配对逆向弧的引用。
    """

    __slots__ = (
        "start_vertex", "end_vertex", "coste", "demanda",
        "coste_original", "demanda_original", "reverse_arc",
    )

    def __init__(self, start_vertex: int, end_vertex: int,
                 demanda: float, coste: float):
        self.start_vertex = start_vertex
        self.end_vertex = end_vertex
        self.coste = coste
        self.demanda = demanda
        self.coste_original = coste
        self.demanda_original = demanda
        self.reverse_arc: Optional["Arc"] = None

    def set_reverse(self, reverse_arc: "Arc") -> None:
        """将此弧与其逆向弧配对绑定。"""
        self.reverse_arc = reverse_arc

    def randomize(self, rng, demand_rate: float = 0.20,
                  cost_rate: float = 0.20) -> None:
        """使用高斯噪声扰动需求和成本（用于随机实例生成）。"""
        import random as _random
        if rng is None:
            rng = _random.Random()

        if self.demanda_original > 0:
            try:
                new_demanda = int(rng.gauss(
                    self.demanda_original,
                    self.demanda_original * demand_rate
                ))
            except (OverflowError, ValueError):
                new_demanda = self.demanda_original
            new_demanda = max(1, new_demanda)
        else:
            new_demanda = 0

        try:
            new_coste = int(rng.gauss(
                self.coste_original,
                self.coste_original * cost_rate
            ))
        except (OverflowError, ValueError):
            new_coste = self.coste_original
        new_coste = max(1, new_coste)

        self.demanda = new_demanda
        self.coste = new_coste

        if self.reverse_arc is not None:
            self.reverse_arc.demanda = self.demanda
            self.reverse_arc.coste = self.coste

    def copy(self) -> "Arc":
        """返回一个独立状态的深拷贝，但保持相同的 reverse_arc 引用。"""
        new_arc = Arc(self.start_vertex, self.end_vertex,
                      self.demanda, self.coste)
        new_arc.coste_original = self.coste_original
        new_arc.demanda_original = self.demanda_original
        new_arc.reverse_arc = self.reverse_arc
        return new_arc

    @property
    def is_required(self) -> bool:
        """需求为正的弧即为'需求弧'（必须服务）。"""
        return self.demanda > 0

    def __repr__(self) -> str:
        return (f"Arc({self.start_vertex}->{self.end_vertex}, "
                f"demand={self.demanda}, cost={self.coste})")

    def __eq__(self, other) -> bool:
        if not isinstance(other, Arc):
            return False
        return (self.start_vertex == other.start_vertex
                and self.end_vertex == other.end_vertex
                and self.demanda == other.demanda
                and self.coste == other.coste)

    def __hash__(self) -> int:
        return hash((self.start_vertex, self.end_vertex,
                     self.demanda, self.coste))


class Graph:
    """带邻接表、OD（全源最短路径）矩阵和弧管理的图。

    维护:
        - 所有弧（需求弧 + 非需求弧）
        - OD矩阵：od[i][j] = 顶点i到j的最短路径距离
        - 节点度数和拓扑特征（供GP终端符使用）
    """

    def __init__(self, vertices: int, depot: int = 1):
        """
        参数:
            vertices: 顶点数量（从1开始编号，因此数组大小为 vertices + 1）。
            depot:    车场顶点编号（默认: 1）。
        """
        self.vertices = vertices
        self.depot = depot
        self.size = vertices + 1  # 用于1-based数组访问

        # 图中所有弧
        self.all_arcs: List[Arc] = []

        # OD（最短路径）矩阵：od[i][j] = i→j 的距离
        self.od: List[List[float]] = []
        self._od_dirty = True

        # Dijkstra用的邻接表
        self._adj: List[List[Tuple[int, float]]] = [[] for _ in range(self.size)]

        # 预计算的拓扑特征
        self._node_degrees: Optional[List[int]] = None
        self._clustering_coeffs: Optional[Dict[int, float]] = None

    # ------------------------------------------------------------------
    # 构建
    # ------------------------------------------------------------------
    def add_arc(self, arc: Arc) -> None:
        """向图中添加一条弧。正向弧和逆向弧都必须分别添加。"""
        self.all_arcs.append(arc)
        self._adj[arc.start_vertex].append((arc.end_vertex, arc.coste))
        self._od_dirty = True

    def add_arc_pair(self, u: int, v: int, demand: float, cost: float) -> Tuple[Arc, Arc]:
        """创建并添加一对正向+逆向弧。

        返回:
            (正向弧, 逆向弧)
        """
        fwd = Arc(u, v, demand, cost)
        rev = Arc(v, u, demand, cost)
        fwd.set_reverse(rev)
        rev.set_reverse(fwd)
        self.add_arc(fwd)
        self.add_arc(rev)
        return fwd, rev

    def build_od_matrix(self) -> None:
        """使用Dijkstra算法计算全源最短路径距离。"""
        if not self._od_dirty:
            return

        self.od = [[math.inf] * self.size for _ in range(self.size)]
        for i in range(1, self.size):
            self.od[i][i] = 0.0
            distances = self._dijkstra(i)
            for j in range(1, self.size):
                self.od[i][j] = distances[j]

        self._od_dirty = False

    def _dijkstra(self, start: int) -> List[float]:
        """从 `start` 出发的单源最短路径。"""
        dist = [math.inf] * self.size
        dist[start] = 0.0
        pq = [(0.0, start)]

        while pq:
            d, u = heapq.heappop(pq)
            if d > dist[u]:
                continue
            for v, cost in self._adj[u]:
                nd = d + cost
                if nd < dist[v]:
                    dist[v] = nd
                    heapq.heappush(pq, (nd, v))
        return dist

    # ------------------------------------------------------------------
    # 拓扑特征（供CPP提议策略终端符使用）
    # ------------------------------------------------------------------
    def compute_node_degrees(self) -> List[int]:
        """计算残差（未访问）图中每个节点的度数。

        返回:
            列表，索引 i 处为顶点 i 的度数（1-based）。
        """
        degrees = [0] * self.size
        for arc in self.all_arcs:
            degrees[arc.start_vertex] += 1
        self._node_degrees = degrees
        return degrees

    def get_degree(self, vertex: int) -> int:
        """获取指定顶点的度数（如未缓存则先计算）。"""
        if self._node_degrees is None:
            self.compute_node_degrees()
        return self._node_degrees[vertex] if vertex < len(self._node_degrees) else 0

    def get_clustering_coefficient(self, vertex: int) -> float:
        """计算顶点的局部聚类系数。

        C(v) = (2 * 邻居之间的边数) / (degree(v) * (degree(v) - 1))
        """
        neighbors = set()
        for arc in self.all_arcs:
            if arc.start_vertex == vertex:
                neighbors.add(arc.end_vertex)

        deg = len(neighbors)
        if deg < 2:
            return 0.0

        edges_between = 0
        neighbor_list = list(neighbors)
        for i in range(len(neighbor_list)):
            for j in range(i + 1, len(neighbor_list)):
                u, v = neighbor_list[i], neighbor_list[j]
                # 检查是否存在 u→v 或 v→u
                for arc in self.all_arcs:
                    if (arc.start_vertex == u and arc.end_vertex == v) or \
                       (arc.start_vertex == v and arc.end_vertex == u):
                        edges_between += 1
                        break

        return (2.0 * edges_between) / (deg * (deg - 1))

    def get_betweenness_proxy(self, vertex: int) -> float:
        """基于节点度数的简单中介中心性代理指标。

        使用度中心性作为中介中心性的计算高效替代。高度数节点通常是桥接节点。
        """
        if self._node_degrees is None:
            self.compute_node_degrees()
        max_deg = max(self._node_degrees[1:]) if len(self._node_degrees) > 1 else 1
        if max_deg == 0:
            return 0.0
        return self._node_degrees[vertex] / max_deg

    # ------------------------------------------------------------------
    # 查询
    # ------------------------------------------------------------------
    @property
    def required_arcs(self) -> List[Arc]:
        """需求为正的弧（必须服务）。"""
        return [a for a in self.all_arcs if a.is_required]

    @property
    def non_required_arcs(self) -> List[Arc]:
        """需求为零的弧（可用于空驶穿行）。"""
        return [a for a in self.all_arcs if not a.is_required]

    def distance(self, u: int, v: int) -> float:
        """从 u 到 v 的最短路径距离。"""
        if self._od_dirty:
            self.build_od_matrix()
        return self.od[u][v]

    def __repr__(self) -> str:
        return (f"Graph(V={self.vertices}, arcs={len(self.all_arcs)}, "
                f"required={len(self.required_arcs)}, depot={self.depot})")