# src/core/__init__.py
"""核心数据结构：图、状态、解。

提供弧路径问题的基础数据模型：
- Arc / Graph: 图表示与OD矩阵
- VehicleState / DecisionContext: 仿真状态与GP特征上下文
- Route / Solution: 解的表示与成本计算
"""
from .graph import Arc, Graph
from .state import VehicleState, DecisionContext
from .solution import Route, Solution

__all__ = ["Arc", "Graph", "VehicleState", "DecisionContext", "Route", "Solution"]