"""
路径仿真的动态决策状态。

提供 VehicleState（单车追踪）和 DecisionContext
（每个决策步暴露给GP树的特征向量）。
"""

import math
from dataclasses import dataclass, field
from typing import List, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from .graph import Arc, Graph


@dataclass
class VehicleState:
    """路径仿真中单辆车的状态。

    属性:
        vehicle_id:        车辆唯一编号。
        capacity:          最大容量 Q。
        remaining_capacity: 当前剩余容量。
        current_position:  当前所在顶点位置（1-based）。
        total_cost:        累计路径成本（空驶 + 服务）。
        route:             本车已服务弧的序列。
    """
    vehicle_id: int
    capacity: float
    remaining_capacity: float
    current_position: int
    total_cost: float = 0.0
    route: List["Arc"] = field(default_factory=list)

    @property
    def load(self) -> float:
        """当前载重（已用容量）。"""
        return self.capacity - self.remaining_capacity

    @property
    def fullness(self) -> float:
        """容量利用率：load / capacity。"""
        if self.capacity <= 0 or math.isinf(self.capacity):
            return 0.0
        return self.load / self.capacity

    @property
    def is_full(self) -> bool:
        """车辆是否已无剩余容量。"""
        return self.remaining_capacity <= 0

    def can_service(self, demand: float) -> bool:
        """检查车辆是否有足够容量服务给定的需求。"""
        return self.remaining_capacity >= demand

    def service(self, arc: "Arc", deadhead_cost: float,
                od_matrix, depot: int) -> float:
        """服务一条弧：先空驶到达弧起点，再穿行服务。

        参数:
            arc:           要服务的弧。
            deadhead_cost: 从当前位置到弧起点的通行成本。
            od_matrix:     全源最短路径矩阵。
            depot:         车场顶点编号。

        返回:
            本次服务动作的总成本（空驶 + 服务）。
            同时更新 current_position 和 route。
            如果容量不足，会先返回车场补充。
        """
        if self.remaining_capacity < arc.demanda:
            # 容量不足，必须先返回车场补充
            if self.current_position != depot:
                self.total_cost += od_matrix[self.current_position][depot]
            self.current_position = depot
            self.remaining_capacity = self.capacity

            # 然后从车场前往弧起点
            deadhead_cost = od_matrix[depot][arc.start_vertex]

        # 空驶到弧起点
        self.total_cost += deadhead_cost
        # 服务弧
        self.total_cost += arc.coste
        self.remaining_capacity -= arc.demanda
        self.current_position = arc.end_vertex
        self.route.append(arc)

        return deadhead_cost + arc.coste

    def return_to_depot(self, od_matrix, depot: int) -> float:
        """返回车场并补充容量。

        返回:
            到车场的空驶成本（如已在车场则返回0）。
        """
        if self.current_position == depot:
            return 0.0
        cost = od_matrix[self.current_position][depot]
        self.total_cost += cost
        self.current_position = depot
        self.remaining_capacity = self.capacity
        return cost

    def reset(self) -> None:
        """将车辆重置为初始状态。"""
        self.remaining_capacity = self.capacity
        self.total_cost = 0.0
        self.route.clear()

    def __repr__(self) -> str:
        return (f"Vehicle({self.vehicle_id}, pos={self.current_position}, "
                f"rem_cap={self.remaining_capacity}/{self.capacity}, "
                f"cost={self.total_cost:.1f})")


@dataclass
class DecisionContext:
    """单个决策步中呈现给GP树的特征上下文。

    这就是栈机求值器所使用的'上下文'数组。所有特征均为数值型（float）。

    注意：特征到上下文数组索引的实际映射定义在GP终端符模块中。
    本数据类提供命名访问方式。
    """

    # --- 通用拓扑特征（CPP和CARP均使用） ---
    cost_from_here: float = 0.0          # CFH：dist(当前位置, 弧起点)
    cost_from_depot_arc: float = 0.0      # CTD：dist(车场, 弧起点)
    cost_from_arc_depot: float = 0.0      # CFD：dist(弧终点, 车场)
    deadheading_cost: float = 0.0          # DC：dist(弧起点, 弧终点)
    serving_cost: float = 0.0             # SC：弧的通行成本 arc.coste
    fraction_unserved_tasks: float = 0.0  # FRT：未服务任务占比
    fraction_unassigned_tasks: float = 0.0# FUT：尚未分配的任务占比

    # --- 扩展拓扑特征（CPP提议阶段） ---
    degree_start: float = 0.0             # DEG_S：弧起始顶点的度数
    degree_end: float = 0.0               # DEG_E：弧结束顶点的度数
    clustering_coeff: float = 0.0         # CLUS：弧周围的局部聚类系数
    betweenness_proxy: float = 0.0        # BETW：弧的桥接程度
    dist_to_depot: float = 0.0            # DIST_DEPOT：到车场的接近度

    # --- 容量感知特征（CARP选择阶段） ---
    remaining_capacity: float = 0.0       # RQ：车辆剩余容量
    demand: float = 0.0                   # DEM：弧的需求量
    fullness: float = 0.0                 # FULL：车辆载重 / 容量
    cost_return_depot: float = 0.0        # CR：dist(当前位置, 车场)
    capacity_risk: float = 0.0            # CapRisk：需求 / 剩余容量
    nearest_other_demand: float = 0.0     # DEM1：最近其他弧的需求量
    nearest_other_cost: float = 0.0       # CTT1：到最近其他弧的成本
    cost_from_other_vehicle: float = 0.0  # CFR1：从其他车辆路径到弧的成本
    remaining_other_vehicle: float = 0.0  # RQ1：其他车辆的剩余容量

    # --- 临时随机常量 ---
    random_value: float = 0.0             # ERC：∈ [0, 1)

    def to_context_array(self, index_map: dict) -> List[float]:
        """将命名特征转换为按终端索引映射索引的数组。

        参数:
            index_map: 终端名称 → 数组索引 的字典。

        返回:
            长度为 max(index_map.values()) + 1 的 List[float]，
            未赋值的元素默认为 1.0。
        """
        max_idx = max(index_map.values()) if index_map else 0
        ctx = [1.0] * (max_idx + 1)

        # 字段名到终端名称的映射
        field_to_terminal = {
            "cost_from_here": "CFH",
            "cost_from_arc_depot": "CFD",
            "cost_from_other_vehicle": "CFR1",
            "nearest_other_cost": "CTT1",
            "cost_from_depot_arc": "CTD",
            "cost_return_depot": "CR",
            "demand": "DEM",
            "nearest_other_demand": "DEM1",
            "deadheading_cost": "DC",
            "fullness": "FULL",
            "fraction_unserved_tasks": "FRT",
            "fraction_unassigned_tasks": "FUT",
            "remaining_capacity": "RQ",
            "remaining_other_vehicle": "RQ1",
            "serving_cost": "SC",
            "random_value": "ERC",
            "degree_start": "DEG_S",
            "degree_end": "DEG_E",
            "clustering_coeff": "CLUS",
            "betweenness_proxy": "BETW",
            "dist_to_depot": "DIST_DEPOT",
            "capacity_risk": "CapRisk",
        }

        for field_name, value in self.__dict__.items():
            terminal_name = field_to_terminal.get(field_name)
            if terminal_name is not None and terminal_name in index_map:
                ctx[index_map[terminal_name]] = float(value)

        return ctx