"""
第二阶段选择策略训练的CARP终端符集合。

包括拓扑特征和容量感知特征。
选择树需要学习在拓扑便利性和容量风险之间进行权衡。

终端索引映射与CPP保持独立，以防止特征泄漏。
"""

from typing import Dict, List


# ======================================================================
# CARP 终端符集合（拓扑 + 容量，20个终端符）
# ======================================================================

CARP_TERMINALS_BASIC: Dict[str, str] = {
    # 拓扑特征（与CPP共享）
    "CFH":    "CFH：从当前位置到弧起点的距离",
    "CFD":    "CFD：从弧终点到车场的距离",
    "CTD":    "CTD：从车场到弧起点的距离",
    "DC":     "DC：弧的直接穿行成本",
    "SC":     "SC：弧的服务成本",
    "FRT":    "FRT：未访问弧数 / 总需求弧数",
    "FUT":    "FUT：(总数 - 已分配) / 总数",
    # 容量特征（CARP独有）
    "DEM":    "DEM：弧的需求量",
    "FULL":   "FULL：车辆载重 / 容量",
    "RQ":     "RQ：车辆剩余容量",
    "CR":     "CR：从当前位置到车场的距离",
}

CARP_TERMINALS_EXTENDED: Dict[str, str] = {
    # 扩展拓扑
    "DEG_S":      "DEG_S：弧起始顶点的度数",
    "DEG_E":      "DEG_E：弧结束顶点的度数",
    "CLUS":       "CLUS：弧周围的聚类系数",
    "BETW":       "BETW：中介中心性代理指标（桥检测）",
    "DIST_DEPOT": "DIST_DEPOT：弧到车场的距离",

    # 扩展容量
    "CFR1":   "CFR1：从最近其他车辆路径到该弧的成本",
    "CTT1":   "CTT1：从该弧到最近其他弧的成本",
    "DEM1":   "DEM1：最近其他弧的需求量",
    "RQ1":    "RQ1：最近其他车辆的剩余容量",
    "CapRisk":"CapRisk：需求 / 剩余容量（容量耗尽风险）",
}

CARP_TERMINAL_INDEX: Dict[str, int] = {
    # --- 基础拓扑 ---
    "CFH":    0,
    "CFD":    1,
    "CTD":    2,
    "DC":     3,
    "SC":     4,
    "FRT":    5,
    "FUT":    6,
    # --- 基础容量 ---
    "DEM":    7,
    "FULL":   8,
    "RQ":     9,
    "CR":     10,
    # --- 扩展拓扑 ---
    "DEG_S":  11,
    "DEG_E":  12,
    "CLUS":   13,
    "BETW":   14,
    "DIST_DEPOT": 15,
    # --- 扩展容量 ---
    "CFR1":   16,
    "CTT1":   17,
    "DEM1":   18,
    "RQ1":    19,
    "CapRisk":20,
    # --- 临时随机常量 ---
    "ERC":    21,
}

CARP_TERMINAL_NAMES: List[str] = list(CARP_TERMINAL_INDEX.keys())


def get_carp_terminal_index(terminal_name: str) -> int:
    """获取CARP终端符对应的上下文数组索引。

    参数:
        terminal_name: 终端符缩写（如 "CFH", "CapRisk"）。

    返回:
        上下文数组中的整数索引，未知时返回 -1。
    """
    return CARP_TERMINAL_INDEX.get(terminal_name, -1)


def get_carp_terminal_names(include_erc: bool = True,
                            use_extended: bool = True) -> List[str]:
    """获取CARP终端符名称列表。

    参数:
        include_erc:   是否包含临时随机常量。
        use_extended:  是否包含扩展终端符。

    返回:
        终端符名称字符串列表。
    """
    names = list(CARP_TERMINALS_BASIC.keys())
    if use_extended:
        names.extend(CARP_TERMINALS_EXTENDED.keys())
    if include_erc:
        names.append("ERC")
    return names