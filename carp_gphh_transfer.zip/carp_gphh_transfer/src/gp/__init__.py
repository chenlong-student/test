# src/gp/__init__.py
"""遗传编程引擎：演化GP树解决弧路径问题。

- GPEngine / GPSettings: 快速栈机评估器与演化配置
- 原语集: 受保护的算术/三角函数（无NaN传播）
- 终端符集: 拓扑特征（CPP）与容量感知特征（CARP）
- 树简化器: 符号代数简化，用于可解释性
"""
from .primitives import (
    add, sub, mul, div, max_func, min_func,
    if_func, sin, cos, exp, ln, neg, sqrt_func, abs_func,
    PRIMITIVE_REGISTRY,
)
from .gp_engine import GPEngine, GPSettings
from .tree_simplifier import simplify_individual, tree_to_expression

__all__ = [
    "add", "sub", "mul", "div", "max_func", "min_func",
    "if_func", "sin", "cos", "exp", "ln", "neg", "sqrt_func", "abs_func",
    "PRIMITIVE_REGISTRY",
    "GPEngine", "GPSettings",
    "simplify_individual", "tree_to_expression",
]