"""
第一阶段提议策略训练的CPP终端符集合。

这些终端符是纯拓扑特征 —— 不包含任何与容量相关的特征。
提议树只能从图结构中学习。

终端索引映射定义了栈机求值器的上下文数组布局。
"""

from typing import Dict, List


# ======================================================================
# CPP 终端符集合（仅拓扑，12个终端符）
# ======================================================================

CPP_TERMINALS_BASIC: Dict[str, str] = {
    "CFH":        "CFH：从当前位置到弧起点的距离",
    "CFD":        "CFD：从弧终点到车场的距离",
    "CTD":        "CTD：从车场到弧起点的距离",
    "DC":         "DC：弧的直接穿行成本",
    "SC":         "SC：弧的服务成本",
    "FRT":        "FRT：未访问弧数 / 总需求弧数",
    "FUT":        "FUT：(总数 - 已分配) / 总数",
}

CPP_TERMINALS_EXTENDED: Dict[str, str] = {
    "DEG_S":      "DEG_S：弧起始顶点在当前图中的度数",
    "DEG_E":      "DEG_E：弧结束顶点在当前图中的度数",
    "CLUS":       "CLUS：弧周围的平均局部聚类系数",
    "BETW":       "BETW：归一化度中心性代理指标（桥检测）",
    "DIST_DEPOT": "DIST_DEPOT：弧端点到车场的平均距离",
}

CPP_TERMINAL_INDEX: Dict[str, int] = {
    # --- 基础拓扑 ---
    "CFH":    0,
    "CFD":    1,
    "CTD":    2,
    "DC":     3,
    "SC":     4,
    "FRT":    5,
    "FUT":    6,
    # --- 扩展拓扑 ---
    "DEG_S":  7,
    "DEG_E":  8,
    "CLUS":   9,
    "BETW":   10,
    "DIST_DEPOT": 11,
    # --- 临时随机常量 ---
    "ERC":    12,
}

CPP_TERMINAL_NAMES: List[str] = list(CPP_TERMINAL_INDEX.keys())


def get_cpp_terminal_index(terminal_name: str) -> int:
    """获取CPP终端符对应的上下文数组索引。

    参数:
        terminal_name: 终端符缩写（如 "CFH", "DEG_S"）。

    返回:
        上下文数组中的整数索引，未知时返回 -1。
    """
    return CPP_TERMINAL_INDEX.get(terminal_name, -1)


def get_cpp_terminal_names(include_erc: bool = True,
                            use_extended: bool = True) -> List[str]:
    """获取CPP终端符名称列表。

    参数:
        include_erc:   是否包含临时随机常量。
        use_extended:  是否包含扩展拓扑终端符。

    返回:
        终端符名称字符串列表。
    """
    names = list(CPP_TERMINALS_BASIC.keys())
    if use_extended:
        names.extend(CPP_TERMINALS_EXTENDED.keys())
    if include_erc:
        names.append("ERC")
    return names