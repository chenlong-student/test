"""
面向GPHH的遗传编程进化引擎。

基于现有代码库（GPHH_CARP/evaluate.py）中的快速栈机评估器改写。
支持CPP（第一阶段）和CARP（第二阶段）两种训练模式，可配置终端符集合。

核心特性：
- 预编译栈机程序，每个操作O(1)评估
- 预计算特征上下文（避免重复计算）
- 批量适应度评估
- 带多样性半径的精英保留
- 个体序列化（JSON + pickle）
"""

import os
import sys
import math
import time
import random
import statistics
import heapq
import json
import pickle
from copy import deepcopy
from dataclasses import dataclass, field
from typing import List, Tuple, Dict, Optional, Callable, Any

from deap import gp, creator, base, tools

# 导入原语和终端符
from .primitives import PRIMITIVE_REGISTRY, get_primitive_func, get_primitive_arity
from .terminals_cpp import CPP_TERMINAL_INDEX, get_cpp_terminal_names
from .terminals_carp import CARP_TERMINAL_INDEX, get_carp_terminal_names


# ======================================================================
# 设置数据类
# ======================================================================

@dataclass
class GPSettings:
    """GP进化超参数。"""
    # 问题类型
    problem: str = "CARP"  # "CPP" 或 "CARP"
    seed: int = 0

    # 进化
    generations: int = 51
    population_size: int = 1024

    # 树结构约束
    min_depth_init: int = 2
    max_depth_init: int = 6
    min_depth_subtree: int = 2
    max_depth_subtree: int = 4
    max_depth_mutate: int = 8
    max_depth_mate: int = 8
    max_depth_reproduct: int = 8
    max_attempts_unique: int = 100

    # 选择与繁殖
    tourn_size: int = 7
    mutate_prob: float = 0.15
    crossover_prob: float = 0.80
    elitism_size: int = 10
    elitism_radius: float = 0.002

    # 函数集配置
    use_add: bool = True
    use_sub: bool = True
    use_mul: bool = True
    use_div: bool = True
    use_max: bool = True
    use_min: bool = True
    use_if: bool = False
    use_sin: bool = False
    use_cos: bool = False
    use_exp: bool = False
    use_ln: bool = False
    use_neg: bool = False
    use_sqrt: bool = False
    use_abs: bool = False

    # 终端符配置
    use_extended_terminals: bool = True
    include_erc: bool = True

    # 适应度
    fitness_type: str = "MIN"  # "MIN" 表示适应度越小越好（即成本最小化）

    # 评估
    training_sample_num: int = 5
    testing_sample_num: int = 500
    demand_change_rate: float = 0.20
    cost_change_rate: float = 0.20
    rotate_eval_model: bool = True

    # 两阶段
    k_candidates: int = 5  # 提议策略的Top-k值

    # 输出
    output_dir: str = "saved_models"

    @property
    def reproduct_prob(self) -> float:
        return 1.0 - self.mutate_prob - self.crossover_prob


# ======================================================================
# GP引擎
# ======================================================================

class GPEngine:
    """GP进化主引擎，用于训练路径策略。

    支持两种模式：
    - 模式 "CPP":  训练提议策略（仅拓扑终端符）。
    - 模式 "CARP": 训练选择策略（容量感知终端符），
                   可选配冻结的提议策略进行两阶段训练。
    """

    def __init__(self, settings: GPSettings):
        self.settings = settings
        self.pset: Optional[gp.PrimitiveSet] = None
        self.toolbox: Optional[base.Toolbox] = None
        self.terminal_index: Dict[str, int] = {}
        self.primitive_funcs: Dict[str, Callable] = {}

        # 内部状态
        self._rng = random.Random(settings.seed)
        self._best_per_gen: List[Any] = []
        self._stats_history: List[Dict] = []

        # 冻结的提议策略（用于第二阶段训练）
        self._proposal_individual: Optional[Any] = None
        self._proposal_program: Optional[tuple] = None

        # DEAP初始化
        self._setup_deap()
        self._build_pset()
        self._setup_toolbox()

    # ------------------------------------------------------------------
    # 初始化
    # ------------------------------------------------------------------
    def _setup_deap(self) -> None:
        """创建DEAP适应度和个体类型。"""
        # 如果已定义则跳过，避免重复创建
        try:
            creator.create("FitnessMin", base.Fitness, weights=(-1.0,))
            creator.create("Individual", gp.PrimitiveTree, fitness=creator.FitnessMin)
        except RuntimeError:
            # 已在此进程中创建过
            pass

    def _build_pset(self) -> None:
        """根据问题模式构建原语集。"""
        s = self.settings
        self.pset = gp.PrimitiveSet("MAIN", 0)

        # --- 添加终端符 ---
        if s.problem == "CPP":
            terminal_names = get_cpp_terminal_names(
                include_erc=s.include_erc,
                use_extended=s.use_extended_terminals,
            )
            self.terminal_index = CPP_TERMINAL_INDEX.copy()
        else:
            terminal_names = get_carp_terminal_names(
                include_erc=s.include_erc,
                use_extended=s.use_extended_terminals,
            )
            self.terminal_index = CARP_TERMINAL_INDEX.copy()

        for tname in terminal_names:
            self.pset.addTerminal(1.0, name=tname)

        # --- 添加原语 ---
        prim_config = [
            (s.use_add, "add"), (s.use_sub, "sub"), (s.use_mul, "mul"),
            (s.use_div, "div"), (s.use_max, "max"), (s.use_min, "min"),
        ]
        for enabled, name in prim_config:
            if enabled:
                func, arity = PRIMITIVE_REGISTRY[name]
                self.pset.addPrimitive(func, arity, name=name)
                self.primitive_funcs[name] = func

        if s.use_if:
            func, arity = PRIMITIVE_REGISTRY["if"]
            self.pset.addPrimitive(func, arity, name="if")
            self.primitive_funcs["if"] = func

        unary_config = [
            (s.use_sin, "sin"), (s.use_cos, "cos"), (s.use_exp, "exp"),
            (s.use_ln, "ln"), (s.use_neg, "neg"), (s.use_sqrt, "sqrt"),
            (s.use_abs, "abs"),
        ]
        for enabled, name in unary_config:
            if enabled:
                func, arity = PRIMITIVE_REGISTRY[name]
                self.pset.addPrimitive(func, arity, name=name)
                self.primitive_funcs[name] = func

    def _setup_toolbox(self) -> None:
        """配置DEAP工具箱，注册遗传算子。"""
        s = self.settings
        self.toolbox = base.Toolbox()

        # --- 个体生成方法（必须在种群生成之前注册）---
        self.toolbox.register(
            "expr_full",
            gp.genFull, pset=self.pset,
            min_=s.min_depth_init, max_=s.max_depth_init
        )
        self.toolbox.register(
            "expr_grow",
            gp.genGrow, pset=self.pset,
            min_=s.min_depth_init, max_=s.max_depth_init
        )
        self.toolbox.register(
            "expr_half",
            gp.genHalfAndHalf, pset=self.pset,
            min_=s.min_depth_init, max_=s.max_depth_init
        )

        # 个体创建器
        self.toolbox.register(
            "individual",
            tools.initIterate, creator.Individual,
            self.toolbox.expr_half
        )

        # 种群初始化（依赖个体定义）
        self.toolbox.register(
            "population",
            tools.initRepeat, list, self.toolbox.individual
        )

        # 遗传算子
        self.toolbox.register("select", tools.selTournament,
                              tournsize=s.tourn_size)

        self.toolbox.register(
            "mate", gp.cxOnePoint
        )
        self.toolbox.register(
            "mutate", gp.mutUniform,
            expr=self.toolbox.expr_grow,
            pset=self.pset
        )

        # 用深度限制装饰遗传算子
        self.toolbox.decorate("mate",
                              gp.staticLimit(key=lambda ind: ind.height,
                                            max_value=s.max_depth_mate))
        self.toolbox.decorate("mutate",
                              gp.staticLimit(key=lambda ind: ind.height,
                                            max_value=s.max_depth_mutate))

    # ------------------------------------------------------------------
    # 程序编译（快速栈机）
    # ------------------------------------------------------------------
    def compile_program(self, individual, terminal_index=None) -> tuple:
        """将GP树编译为栈机指令元组。

        每条指令格式：
            ("const", value)      → 压入常量
            ("term", index)       → 压入 context[index]
            ("prim", func, arity) → 弹出 arity 个参数，调用函数，压入结果

        参数:
            individual:     待编译的DEAP个体。
            terminal_index: 可选字典，映射终端符名称 → 数组索引。
                           若为None，则使用 self.terminal_index。

        返回:
            指令元组（缓存于个体对象上）。
        """
        if terminal_index is None:
            terminal_index = self.terminal_index

        # 检查缓存 —— 缓存键包含 terminal_index 的标识
        cache_key = (str(individual), id(terminal_index))
        cached_key = getattr(individual, "_fast_eval_cache_key", None)
        cached_prog = getattr(individual, "_fast_eval_program", None)

        if cached_key == cache_key and cached_prog is not None:
            return cached_prog

        def walk(index: int):
            node = individual[index]
            cursor = index + 1
            program = []

            if isinstance(node, gp.Primitive):
                for _ in range(node.arity):
                    child_prog, cursor = walk(cursor)
                    program.extend(child_prog)
                func = self.primitive_funcs.get(node.name)
                if func is None:
                    raise KeyError(f"未知原语: {node.name}")
                program.append(("prim", func, node.arity))
                return program, cursor

            node_name = getattr(node, "name", None)
            if node_name is not None and node_name in terminal_index:
                program.append(("term", terminal_index[node_name]))
                return program, cursor

            # 终端符不在索引中 → 尝试作为数值常量
            value = getattr(node, "value", node)
            if callable(value):
                raise TypeError(f"不支持的可调用终端符: {node_name}")
            try:
                program.append(("const", float(value)))
            except (ValueError, TypeError):
                # 当终端符名称不在索引中时提供清晰的错误信息
                # （例如：CARP终端符 'FULL' 使用了CPP终端索引）
                raise KeyError(
                    f"终端符 '{node_name}' 不在终端索引中 "
                    f"（共 {len(terminal_index)} 个条目）。"
                    f"是否对此树使用了错误的终端索引？"
                )
            return program, cursor

        program, next_index = walk(0)
        if next_index != len(individual):
            raise ValueError(
                f"GP树编译失败: 消耗了 {next_index}/{len(individual)} 个节点"
            )

        program = tuple(program)
        individual._fast_eval_cache_key = cache_key
        individual._fast_eval_program = program
        return program

    def execute_program(self, program: tuple, context: List[float]) -> float:
        """在上下文数组上执行已编译的程序。

        参数:
            program: 由 compile_program() 返回的编译后指令元组。
            context: 以 terminal_index 索引的特征上下文数组（浮点数列表）。

        返回:
            浮点数优先级评分。
        """
        stack = []

        for instruction in program:
            op_type = instruction[0]

            if op_type == "const":
                stack.append(instruction[1])
            elif op_type == "term":
                stack.append(context[instruction[1]])
            elif op_type == "prim":
                func = instruction[1]
                arity = instruction[2]

                if arity == 1:
                    stack.append(func(stack.pop()))
                elif arity == 2:
                    right = stack.pop()
                    left = stack.pop()
                    stack.append(func(left, right))
                else:  # arity == 3
                    third = stack.pop()
                    second = stack.pop()
                    first = stack.pop()
                    stack.append(func(first, second, third))

        return stack[-1] if stack else 1.0

    # ------------------------------------------------------------------
    # 个体评估（单实例）
    # ------------------------------------------------------------------
    def evaluate_on_cpp(self, individual, instance) -> float:
        """在CPP实例上评估个体：单车、无容量约束。

        GP树对所有未访问弧评分；每步选择评分最高（或最低）的弧。
        """
        from src.core.graph import Graph
        from src.env.cpp_env import CPPEnv

        program = self.compile_program(individual)
        env = CPPEnv(instance, depot=instance.depot, seed=instance.seed)
        env.reset()
        rng = random.Random(instance.seed)

        context = [1.0] * (max(self.terminal_index.values()) + 1) \
            if self.terminal_index else [1.0] * 16

        while not env.is_done():
            best_value = None
            best_arc = None

            vehicle = env.vehicles[0]
            pos = vehicle.current_position

            for arc in env.get_unvisited_arcs():
                # 为 (车辆, 弧) 对构建上下文
                ctx = env._build_context(0, arc)
                arr = ctx.to_context_array(self.terminal_index)

                value = self.execute_program(program, arr)

                if best_value is None or (
                    self.settings.fitness_type == "MIN" and value < best_value
                ) or (
                    self.settings.fitness_type != "MIN" and value > best_value
                ):
                    best_value = value
                    best_arc = arc

            if best_arc is None:
                break

            env.step((0, best_arc))

        return env.finalize()

    def evaluate_on_carp(self, individual, instance,
                          proposal_individual=None) -> float:
        """在CARP实例上评估个体。

        如果提供了 proposal_individual，使用两阶段评估：
            1. 提议树对所有弧评分 → Top-k
            2. 此（选择）树评估 k+1 个选项 → 最终动作

        否则使用传统单阶段评估。
        """
        from src.env.carp_env import CARPEnv

        program = self.compile_program(individual)
        proposal_program = None
        if proposal_individual is not None:
            from src.gp.terminals_cpp import CPP_TERMINAL_INDEX
            proposal_program = self.compile_program(
                proposal_individual, terminal_index=CPP_TERMINAL_INDEX
            )

        env = CARPEnv(
            instance,
            depot=instance.depot,
            capacity=instance.capacity if hasattr(instance, 'capacity') else 100.0,
            num_vehicles=instance.num_vehicles if hasattr(instance, 'num_vehicles') else 5,
            seed=instance.seed,
        )
        env.reset()
        rng = random.Random(instance.seed)

        k = self.settings.k_candidates
        context = [1.0] * (max(self.terminal_index.values()) + 1) \
            if self.terminal_index else [1.0] * 16

        while not env.is_done():
            vehicle = env.active_vehicle
            unvisited = env.get_unvisited_arcs()

            if not unvisited:
                break

            if proposal_program is not None:
                # ----- 两阶段评估 -----
                # 第一阶段：提议（CPP树，纯拓扑）
                # 硬约束门：过滤不可行弧
                feasible_arcs = []
                for arc in unvisited:
                    if arc.demanda <= vehicle.capacity:
                        feasible_arcs.append(arc)

                if not feasible_arcs:
                    # 所有弧的需求量都超过最大容量 → 此容量Q下不可行
                    # 如果车辆已在车场且满容量，返回车场也无济于事；处以惩罚并停止
                    if (vehicle.current_position == env.depot
                            and vehicle.remaining_capacity >= vehicle.capacity):
                        return float("inf")
                    # 否则，返回车场补充容量后重试
                    env.step((0, None))
                    continue

                # 用提议树对所有可行弧评分
                scored = []
                from src.gp.terminals_cpp import CPP_TERMINAL_INDEX

                for arc in feasible_arcs:
                    ctx = env._build_context(0, arc)
                    arr = ctx.to_context_array(CPP_TERMINAL_INDEX)
                    score = self.execute_program(proposal_program, arr)
                    scored.append((score, arc))

                # 按评分取Top-k
                if self.settings.fitness_type == "MIN":
                    scored.sort(key=lambda x: x[0])
                else:
                    scored.sort(key=lambda x: -x[0])

                candidates = [arc for _, arc in scored[:k]]

                # 如果不足k个，用最近的拓扑邻居补齐
                if len(candidates) < k:
                    for arc in feasible_arcs:
                        if arc not in candidates:
                            candidates.append(arc)
                        if len(candidates) >= k:
                            break

                # 第二阶段：在 k+1 个选项上用选择树（CARP树）评估
                best_value = None
                best_action = None

                for arc in candidates:
                    ctx = env._build_context(0, arc)
                    arr = ctx.to_context_array(self.terminal_index)
                    value = self.execute_program(program, arr)

                    if best_value is None or (
                        self.settings.fitness_type == "MIN" and value < best_value
                    ) or (
                        self.settings.fitness_type != "MIN" and value > best_value
                    ):
                        best_value = value
                        best_action = (0, arc)

                # 第 k+1 个选项：返回车场
                rtd_ctx = env.build_return_to_depot_context()
                rtd_arr = rtd_ctx.to_context_array(self.terminal_index)
                rtd_value = self.execute_program(program, rtd_arr)

                if best_value is None or (
                    self.settings.fitness_type == "MIN" and rtd_value < best_value
                ) or (
                    self.settings.fitness_type != "MIN" and rtd_value > best_value
                ):
                    best_action = (0, None)

                if best_action is None:
                    best_action = (0, candidates[0]) if candidates else (0, None)

                env.step(best_action)

            else:
                # ----- 单阶段评估（传统1S-GPHH）-----
                best_value = None
                best_action = None

                for arc in unvisited:
                    ctx = env._build_context(0, arc)
                    arr = ctx.to_context_array(self.terminal_index)
                    value = self.execute_program(program, arr)

                    if best_value is None or (
                        self.settings.fitness_type == "MIN" and value < best_value
                    ) or (
                        self.settings.fitness_type != "MIN" and value > best_value
                    ):
                        best_value = value
                        best_action = (0, arc)

                if best_action is None:
                    break

                env.step(best_action)

        return env.finalize()

    # ------------------------------------------------------------------
    # 批量评估
    # ------------------------------------------------------------------
    def evaluate_batch(self, individual, instance_list: List,
                       proposal_individual=None) -> float:
        """跨多个实例评估个体。

        返回:
            所有实例的平均总成本。
        """
        total_fitness = 0.0
        for instance in instance_list:
            if self.settings.problem == "CPP":
                fitness = self.evaluate_on_cpp(individual, instance)
            else:
                fitness = self.evaluate_on_carp(
                    individual, instance, proposal_individual
                )
            total_fitness += fitness

        avg_fitness = total_fitness / len(instance_list)
        individual.fitness = avg_fitness
        return individual

    def evaluate_population(self, population: List,
                            instance_list: List,
                            proposal_individual=None) -> List:
        """评估种群中所有个体。

        返回:
            已赋适应度值的种群。
        """
        fitness_cache = {}
        cache_prefix = tuple(s.seed if hasattr(s, 'seed')
                            else id(s) for s in instance_list)

        for ind in population:
            sig = getattr(ind, "_fast_eval_cache_key", str(ind))
            cache_key = (cache_prefix, sig)

            if cache_key in fitness_cache:
                ind.fitness = fitness_cache[cache_key]
                continue

            self.evaluate_batch(ind, instance_list, proposal_individual)
            fitness_cache[cache_key] = ind.fitness

        return population

    # ------------------------------------------------------------------
    # 繁殖
    # ------------------------------------------------------------------
    def breed_population(self, population: List) -> List:
        """通过选择、交叉、变异生成下一代。

        保留精英个体，并维护多样性半径。
        """
        s = self.settings

        # --- 精英保留 ---
        new_pop = []
        reverse = s.fitness_type != "MIN"

        if s.elitism_size > 0:
            pop_sorted = sorted(population, key=lambda ind: ind.fitness,
                                reverse=reverse)

            elite_fitnesses = []
            for ind in pop_sorted:
                if len(new_pop) >= s.elitism_size:
                    break

                if elite_fitnesses:
                    min_norm_diff = min(
                        abs(ind.fitness - f) / max(
                            max(elite_fitnesses) - min(elite_fitnesses), 1e-12
                        )
                        for f in elite_fitnesses
                    )
                    if min_norm_diff < s.elitism_radius:
                        continue

                child = deepcopy(ind)
                if hasattr(child, "fitness"):
                    try:
                        del child.fitness
                    except AttributeError:
                        pass
                new_pop.append(child)
                elite_fitnesses.append(ind.fitness)

        # --- 填充剩余位置 ---
        while len(new_pop) < s.population_size:
            r = self._rng.random()

            if r < s.crossover_prob and \
               len(new_pop) <= s.population_size - 2:
                # 交叉 → 2个子代
                p1 = self.toolbox.select(population, 1)[0]
                p2 = self.toolbox.select(population, 1)[0]

                if p1 is p2:
                    for _ in range(s.max_attempts_unique):
                        p2 = self.toolbox.select(population, 1)[0]
                        if p1 is not p2:
                            break

                c1 = deepcopy(p1)
                c2 = deepcopy(p2)
                if hasattr(c1, "fitness"):
                    try:
                        del c1.fitness
                    except AttributeError:
                        pass
                if hasattr(c2, "fitness"):
                    try:
                        del c2.fitness
                    except AttributeError:
                        pass

                self.toolbox.mate(c1, c2)
                new_pop.append(c1)
                new_pop.append(c2)

            elif r < s.crossover_prob + s.mutate_prob:
                # 变异 → 1个子代
                p = self.toolbox.select(population, 1)[0]
                c = deepcopy(p)
                if hasattr(c, "fitness"):
                    try:
                        del c.fitness
                    except AttributeError:
                        pass

                self.toolbox.mutate(c)

                if p is c:
                    for _ in range(s.max_attempts_unique):
                        self.toolbox.mutate(c)
                        if p is not c:
                            break

                new_pop.append(c)

            else:
                # 复制 → 1个子代
                p = self.toolbox.select(population, 1)[0]
                c = deepcopy(p)
                if hasattr(c, "fitness"):
                    try:
                        del c.fitness
                    except AttributeError:
                        pass
                new_pop.append(c)

        return new_pop[:s.population_size]

    # ------------------------------------------------------------------
    # 完整进化运行
    # ------------------------------------------------------------------
    def run(self, train_instances: List,
            test_instances: Optional[List] = None,
            proposal_individual=None,
            callbacks: Optional[Dict[str, Callable]] = None) -> Dict:
        """运行完整的GP进化。

        参数:
            train_instances:    训练实例对象列表。
            test_instances:     可选的每代测试实例列表。
            proposal_individual: 冻结的提议树（仅第二阶段使用）。
            callbacks:          {"on_generation": fn, "on_finish": fn} 回调字典。

        返回:
            包含以下键的字典: best_individual, best_fitness, stats_history,
            best_per_generation。
        """
        s = self.settings

        # 1. 初始化种群
        pop = self.toolbox.population(n=s.population_size)
        pop = self._remove_duplicates(pop)

        # 2. 评估初始种群
        pop = self.evaluate_population(pop, train_instances,
                                       proposal_individual)

        # 3. 进化循环
        self._best_per_gen = []
        self._stats_history = []

        for gen in range(s.generations):
            gen_start = time.time()

            # 找出最优个体
            best_ind = self._find_best(pop)
            best_copy = deepcopy(best_ind)
            self._best_per_gen.append(best_copy)

            # 记录统计信息
            stats = self._compute_stats(pop, best_ind, gen)
            self._stats_history.append(stats)

            # 打印进度
            print(f"[Gen {gen:3d}] Best={best_ind.fitness:.2f}  "
                  f"AvgFit={stats['fit_mean']:.2f}  "
                  f"Size={stats['best_size']}  "
                  f"Height={stats['best_height']}  "
                  f"UniqTerm={stats['best_unique_terms']}")

            # 回调
            if callbacks and "on_generation" in callbacks:
                callbacks["on_generation"](gen, best_ind, pop)

            # 最后一代 → 不再繁殖
            if gen == s.generations - 1:
                break

            # 轮换评估样本
            if s.rotate_eval_model and hasattr(train_instances[0], 'resetSeedInstance'):
                for inst in train_instances:
                    inst.resetSeedInstance(s.seed, s, gen + 1)

            # 繁殖
            new_pop = self.breed_population(pop)

            # 评估
            pop = self.evaluate_population(
                new_pop, train_instances, proposal_individual
            )

            gen_time = time.time() - gen_start
            stats["gen_time"] = gen_time

        # 4. 最终最佳个体
        best_overall = self._find_best(self._best_per_gen)

        # 5. 测试评估
        test_fitness = None
        if test_instances:
            self.evaluate_batch(best_overall, test_instances,
                               proposal_individual)
            test_fitness = best_overall.fitness
            print(f"\n测试适应度: {test_fitness:.2f}")

        # 6. 回调
        if callbacks and "on_finish" in callbacks:
            callbacks["on_finish"](best_overall, self._stats_history)

        return {
            "best_individual": best_overall,
            "best_fitness": best_overall.fitness,
            "test_fitness": test_fitness,
            "stats_history": self._stats_history,
            "best_per_generation": self._best_per_gen,
        }

    # ------------------------------------------------------------------
    # 辅助方法
    # ------------------------------------------------------------------
    def _find_best(self, population: List) -> Any:
        """找到种群中的最佳个体。"""
        if self.settings.fitness_type == "MIN":
            return min(population, key=lambda ind: ind.fitness)
        return max(population, key=lambda ind: ind.fitness)

    def _remove_duplicates(self, population: List) -> List:
        """确保种群中没有重复个体。"""
        seen = set()
        unique = []
        for ind in population:
            sig = str(ind)
            if sig not in seen:
                seen.add(sig)
                unique.append(ind)

        # 如果不够则补充
        while len(unique) < self.settings.population_size:
            new_ind = self.toolbox.individual()
            new_sig = str(new_ind)
            if new_sig not in seen:
                seen.add(new_sig)
                unique.append(new_ind)

        return unique[:self.settings.population_size]

    def _compute_stats(self, pop: List, best_ind, gen: int) -> Dict:
        """计算代统计信息。"""
        prog_heights = [ind.height for ind in pop]
        prog_sizes = [len(ind) for ind in pop]
        fits = [ind.fitness for ind in pop]

        # 统计最佳个体中的唯一终端符数量
        best_terms = set()
        for node in best_ind:
            node_name = getattr(node, "name", None)
            arity = getattr(node, "arity", None)
            if node_name is not None and arity == 0:
                best_terms.add(node_name)

        return {
            "gen": gen,
            "best_fitness": best_ind.fitness,
            "best_size": len(best_ind),
            "best_height": best_ind.height,
            "best_unique_terms": len(best_terms),
            "fit_mean": statistics.fmean(fits) if fits else 0.0,
            "fit_std": statistics.pstdev(fits) if len(fits) > 1 else 0.0,
            "size_mean": statistics.fmean(prog_sizes) if prog_sizes else 0.0,
            "height_mean": statistics.fmean(prog_heights) if prog_heights else 0.0,
            "pop_size": len(pop),
        }

    # ------------------------------------------------------------------
    # 序列化
    # ------------------------------------------------------------------
    def save_individual(self, individual, filepath_base: str,
                        metadata: Optional[Dict] = None) -> None:
        """将个体保存为JSON（可读）和pickle（快速加载）。

        参数:
            individual:    要保存的GP个体。
            filepath_base: 不带扩展名的基础路径。
            metadata:      可选字典，包含在JSON中。
        """
        from .tree_simplifier import tree_to_expression

        os.makedirs(os.path.dirname(filepath_base), exist_ok=True)

        # JSON格式（人类可读）
        json_data = {
            "fitness": individual.fitness if hasattr(individual, "fitness") else None,
            "size": len(individual),
            "height": individual.height,
            "expression": tree_to_expression(individual),
            "raw_tree": str(individual),
            "terminals_used": list(set(
                getattr(n, "name", None)
                for n in individual
                if getattr(n, "name", None) is not None
                and getattr(n, "arity", None) == 0
            )),
            "problem": self.settings.problem,
            "k_candidates": self.settings.k_candidates,
        }
        if metadata:
            json_data["metadata"] = metadata

        with open(f"{filepath_base}.json", "w", encoding="utf-8") as f:
            json.dump(json_data, f, indent=2, ensure_ascii=False)

        # Pickle格式（快速加载）
        with open(f"{filepath_base}.pkl", "wb") as f:
            pickle.dump(individual, f)

        print(f"个体已保存至 {filepath_base}.json 和 .pkl")

    def load_individual(self, filepath: str) -> Any:
        """从pickle文件加载个体。

        参数:
            filepath: .pkl 文件路径。

        返回:
            DEAP个体。
        """
        with open(filepath, "rb") as f:
            return pickle.load(f)

    def load_proposal_policy(self, filepath: str) -> None:
        """为两阶段评估加载冻结的提议策略。

        参数:
            filepath: 提议树 .pkl 文件的路径。
        """
        self._proposal_individual = self.load_individual(filepath)
        from src.gp.terminals_cpp import CPP_TERMINAL_INDEX
        self._proposal_program = self.compile_program(
            self._proposal_individual, terminal_index=CPP_TERMINAL_INDEX
        )
        print(f"已从 {filepath} 加载提议策略")

    def set_proposal_policy(self, individual: Any) -> None:
        """直接设置冻结的提议策略。

        参数:
            individual: DEAP个体（提议树）。
        """
        self._proposal_individual = deepcopy(individual)
        from src.gp.terminals_cpp import CPP_TERMINAL_INDEX
        self._proposal_program = self.compile_program(
            self._proposal_individual, terminal_index=CPP_TERMINAL_INDEX
        )

    def get_proposal_policy(self) -> Optional[Any]:
        """获取冻结的提议策略（如果已设置）。"""
        return self._proposal_individual