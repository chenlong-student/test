"""
基于符号代数的GP树简化器。

将DEAP PrimitiveTree解析为AST，应用代数简化规则，
返回简化后的树。
改编自现有代码库中的 individualSimple.py。
"""

import math
from typing import List, Tuple, Union, Any

from deap import gp


# ======================================================================
# AST表示
# ======================================================================
# ('const', number)
# ('var', 'ARG0')
# ('op', name, [child1, child2, ...])

def parse_tree_nodes(nodes: List[Any]) -> Tuple[tuple, int]:
    """将 PrimitiveTree 节点解析为AST。

    返回:
        (ast, length)，其中 length 为消耗的节点数。
    """
    def parse_at(i: int) -> Tuple[tuple, int]:
        node = nodes[i]
        if isinstance(node, gp.Primitive):
            name = node.name
            arity = node.arity
            children = []
            consumed = 1
            j = i + 1
            for _ in range(arity):
                child_ast, child_len = parse_at(j)
                children.append(child_ast)
                j += child_len
                consumed += child_len
            return ("op", name, tuple(children)), consumed
        else:
            val = node.value if hasattr(node, "value") else node
            if isinstance(val, (int, float)):
                return ("const", float(val)), 1
            else:
                return ("var", str(val)), 1

    ast, length = parse_at(0)
    return ast


def ast_eq(a: tuple, b: tuple) -> bool:
    """AST节点的结构相等性检查。"""
    if a[0] != b[0]:
        return False
    if a[0] == "const":
        return float(a[1]) == float(b[1])
    if a[0] == "var":
        return a[1] == b[1]
    if a[1] != b[1]:
        return False
    if len(a[2]) != len(b[2]):
        return False
    return all(ast_eq(x, y) for x, y in zip(a[2], b[2]))


def _eval_op_const(name: str, const_children: List[tuple]) -> Union[tuple, None]:
    """对常量子节点执行运算符求值（常量折叠）。"""
    vals = [c[1] for c in const_children]
    try:
        if name == "add":
            return ("const", vals[0] + vals[1])
        if name == "sub":
            return ("const", vals[0] - vals[1])
        if name == "mul":
            return ("const", vals[0] * vals[1])
        if name == "div":
            return ("const", vals[0] / vals[1] if vals[1] != 0 else 1.0)
        if name == "max":
            return ("const", vals[0] if vals[0] > vals[1] else vals[1])
        if name == "min":
            return ("const", vals[1] if vals[0] > vals[1] else vals[0])
        if name == "sin":
            return ("const", math.sin(vals[0]))
        if name == "cos":
            return ("const", math.cos(vals[0]))
        if name == "exp":
            return ("const", math.exp(vals[0]))
        if name == "ln":
            if vals[0] == 0:
                return ("const", 1.0)
            if vals[0] < 0:
                vals[0] = -vals[0]
            return ("const", math.log(vals[0]))
        if name == "neg":
            return ("const", -vals[0])
        if name == "sqrt":
            if vals[0] < 0:
                vals[0] = -vals[0]
            return ("const", math.sqrt(vals[0]))
        if name == "abs":
            if vals[0] < 0:
                vals[0] = -vals[0]
            return ("const", vals[0])
    except Exception:
        pass
    return None


def simplify_ast(node: tuple) -> tuple:
    """使用代数恒等式递归简化AST节点。"""
    ntype = node[0]
    if ntype in ("const", "var"):
        return node

    _, name, children = node

    # --- 1. 递归简化子节点 ---
    simplified_children = [simplify_ast(ch) for ch in children]

    # --- 2. 常量折叠 ---
    all_const = all(ch[0] == "const" for ch in simplified_children)
    if all_const:
        res = _eval_op_const(name, simplified_children)
        if res is not None:
            return res

    # --- 3. 代数恒等式 ---
    if len(simplified_children) == 2:
        a, b = simplified_children

        # sub(x, x) = 0
        if name == "sub" and ast_eq(a, b):
            return ("const", 0.0)
        # div(x, x) = 1
        if name == "div" and ast_eq(a, b):
            return ("const", 1.0)
        # max(x, x) = min(x, x) = x
        if name in ("max", "min") and ast_eq(a, b):
            return a

        # 单位元
        if name == "add":
            if a == ("const", 0.0):
                return b
            if b == ("const", 0.0):
                return a
        if name == "sub":
            if b == ("const", 0.0):
                return a
        if name == "mul":
            if a == ("const", 0.0) or b == ("const", 0.0):
                return ("const", 0.0)
            if a == ("const", 1.0):
                return b
            if b == ("const", 1.0):
                return a
        if name == "div":
            if b == ("const", 1.0):
                return a

    # --- 4. 一元恒等式 ---
    if len(simplified_children) == 1:
        child = simplified_children[0]

        # sqrt(mul(x, x)) = abs(x)
        if name == "sqrt" and child[0] == "op" and child[1] == "mul":
            c0, c1 = child[2]
            if ast_eq(c0, c1):
                return ("op", "abs", (c0,))

        # mul(sqrt(x), sqrt(x)) = x
        if name == "mul":
            if a[0] == "op" and a[1] == "sqrt" and b[0] == "op" and b[1] == "sqrt":
                if ast_eq(a[2][0], b[2][0]):
                    return a[2][0]

        # ln(exp(x)) = x
        if name == "ln" and child[0] == "op" and child[1] == "exp":
            return child[2][0]

        # exp(ln(x)) = abs(x)
        if name == "exp" and child[0] == "op" and child[1] == "ln":
            inner_x = child[2][0]
            return ("op", "abs", (inner_x,))

        # 对常量0的一元运算
        if child[0] == "const" and child[1] == 0.0:
            if name == "sin":
                return ("const", 0.0)
            if name == "cos":
                return ("const", 1.0)
            if name == "exp":
                return ("const", 1.0)
            if name == "ln":
                return ("const", 1.0)

    return ("op", name, tuple(simplified_children))


def ast_to_string(ast: tuple) -> str:
    """将AST转换回表达式字符串，供 PrimitiveTree.from_string() 使用。"""
    if ast[0] == "const":
        v = ast[1]
        if abs(v - int(v)) < 1e-12:
            return str(int(v))
        else:
            return repr(float(v))
    if ast[0] == "var":
        return ast[1]
    # 运算符
    name = ast[1]
    child_strs = [ast_to_string(ch) for ch in ast[2]]
    return f"{name}(" + ", ".join(child_strs) + ")"


def simplify_individual(individual, pset) -> Any:
    """简化DEAP个体（PrimitiveTree）并返回新个体。

    参数:
        individual: DEAP gp.PrimitiveTree 个体。
        pset:       用于构建树的 PrimitiveSet。

    返回:
        与输入类型相同的新简化个体。
    """
    from deap import creator

    nodes = list(individual)
    ast = parse_tree_nodes(nodes)
    simp = simplify_ast(ast)
    expr_str = ast_to_string(simp)

    # 从字符串重建
    new_tree = gp.PrimitiveTree.from_string(expr_str, pset)

    # 保留 Individual 类型
    if hasattr(creator, "Individual"):
        return creator.Individual(new_tree)
    return new_tree


def tree_to_expression(individual) -> str:
    """将GP树转换为人类可读的数学表达式。

    参数:
        individual: DEAP gp.PrimitiveTree 个体。

    返回:
        简化公式的字符串表示。
    """
    nodes = list(individual)
    ast = parse_tree_nodes(nodes)
    simp = simplify_ast(ast)
    return ast_to_string(simp)