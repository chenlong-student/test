"""
GP原语（函数节点）定义。

所有函数均受数值保护（不会传播NaN/Inf）。
PRIMITIVE_REGISTRY 将函数名映射为 (func, arity) 对。
"""

import math
from typing import Callable, Dict, Tuple


# ======================================================================
# 二元算术运算（arity 2）
# ======================================================================

def add(a: float, b: float) -> float:
    """加法。"""
    return a + b


def sub(a: float, b: float) -> float:
    """减法。"""
    return a - b


def mul(a: float, b: float) -> float:
    """乘法。"""
    return a * b


def div(a: float, b: float) -> float:
    """受保护的除法：除以零时返回 1.0。"""
    if b == 0.0:
        return 1.0
    return a / b


def max_func(a: float, b: float) -> float:
    """取最大值。"""
    return a if a > b else b


def min_func(a: float, b: float) -> float:
    """取最小值。"""
    return a if a < b else b


# ======================================================================
# 三元运算（arity 3）
# ======================================================================

def if_func(a: float, b: float, c: float) -> float:
    """If-then-else：若 a > 0 则返回 b，否则返回 c。"""
    return b if a > 0.0 else c


# ======================================================================
# 一元运算（arity 1）
# ======================================================================

def sin(a: float) -> float:
    """正弦函数，受异常保护。"""
    try:
        return math.sin(a)
    except (ValueError, OverflowError):
        return 1.0


def cos(a: float) -> float:
    """余弦函数，受异常保护。"""
    try:
        return math.cos(a)
    except (ValueError, OverflowError):
        return 1.0


def exp(a: float) -> float:
    """指数函数，受异常保护。"""
    try:
        return math.exp(a)
    except (ValueError, OverflowError):
        return 1.0


def ln(a: float) -> float:
    """受保护的自然对数：若 a != 0 返回 ln(|a|)，否则返回 1.0。"""
    try:
        if a == 0.0:
            return 1.0
        if a < 0.0:
            a = -a
        return math.log(a)
    except (ValueError, OverflowError):
        return 1.0


def neg(a: float) -> float:
    """取负。"""
    return -a


def sqrt_func(a: float) -> float:
    """受保护的平方根：返回 sqrt(|a|)。"""
    try:
        if a < 0.0:
            a = -a
        return math.sqrt(a)
    except (ValueError, OverflowError):
        return 1.0


def abs_func(a: float) -> float:
    """绝对值。"""
    return math.fabs(a)


# ======================================================================
# 原语注册表
# ======================================================================

PRIMITIVE_REGISTRY: Dict[str, Tuple[Callable, int]] = {
    "add": (add, 2),
    "sub": (sub, 2),
    "mul": (mul, 2),
    "div": (div, 2),
    "max": (max_func, 2),
    "min": (min_func, 2),
    "if":  (if_func, 3),
    "sin": (sin, 1),
    "cos": (cos, 1),
    "exp": (exp, 1),
    "ln":  (ln, 1),
    "neg": (neg, 1),
    "sqrt": (sqrt_func, 1),
    "abs": (abs_func, 1),
}


def get_primitive_func(name: str) -> Callable:
    """根据名称获取原语函数。

    参数:
        name: 原语名称（如 "add", "div"）。

    返回:
        可调用函数。
    """
    if name not in PRIMITIVE_REGISTRY:
        raise KeyError(f"未知原语: {name}")
    return PRIMITIVE_REGISTRY[name][0]


def get_primitive_arity(name: str) -> int:
    """获取原语函数的参数数量。

    参数:
        name: 原语名称。

    返回:
        arity（参数个数）。
    """
    if name not in PRIMITIVE_REGISTRY:
        raise KeyError(f"未知原语: {name}")
    return PRIMITIVE_REGISTRY[name][1]