"""
CARP（容量约束弧路径问题）仿真环境。

多车辆、容量约束、车场补给的路径问题。
车辆容量耗尽时必须返回车场重新装满。

用于第二阶段：训练具有容量感知能力的选择策略。
"""

import math
import random
from typing import List, Tuple, Optional, TYPE_CHECKING

from .base_env import BaseRouteEnv

if TYPE_CHECKING:
    from src.core.graph import Arc, Graph
    from src.core.state import VehicleState, DecisionContext


class CARPEnv(BaseRouteEnv):
    """CARP环境：多车辆、容量Q、可返回车场补给。

    特征上下文同时包含拓扑特征和容量感知特征。
    """

    # "返回车场"动作的特殊标记
    RETURN_TO_DEPOT = None  # 在动作元组中以 arc=None 表示

    def __init__(self, graph: "Graph", depot: int = 1,
                 capacity: float = 100.0, num_vehicles: int = 5,
                 seed: int = 0):
        """
        参数：
            graph:         已构建OD矩阵的图
            depot:         车场顶点索引
            capacity:      车辆容量 Q
            num_vehicles:  可用车辆数量
            seed:          ERC终端符的随机种子
        """
        super().__init__(graph, depot)
        self.base_capacity = capacity
        self.num_vehicles = num_vehicles
        self.rng = random.Random(seed)

        # 当前活跃车辆索引
        self._active_vehicle: int = 0

        # 预计算的拓扑特征
        self._node_degrees: List[int] = []
        self._clustering_cache: dict = {}

    # ------------------------------------------------------------------
    # 生命周期
    # ------------------------------------------------------------------
    def _create_vehicles(self) -> List["VehicleState"]:
        from src.core.state import VehicleState
        return [
            VehicleState(
                vehicle_id=i,
                capacity=self.base_capacity,
                remaining_capacity=self.base_capacity,
                current_position=self.depot,
            )
            for i in range(self.num_vehicles)
        ]

    def reset(self) -> "DecisionContext":
        """重置环境并预计算拓扑特征。"""
        result = super().reset()
        self._node_degrees = self.graph.compute_node_degrees()
        self._clustering_cache = {}
        self._active_vehicle = 0
        return result

    # ------------------------------------------------------------------
    # 动作处理
    # ------------------------------------------------------------------
    def _handle_action(self, vehicle_idx: int,
                       arc: Optional["Arc"]) -> float:
        """执行动作：服务弧或返回车场。

        返回：
            本步骤产生的代价。
        """
        vehicle = self.vehicles[vehicle_idx]

        if arc is None:
            # 返回车场动作
            return self._do_return_to_depot(vehicle)
        else:
            return self._do_service_arc(vehicle, arc)

    def _do_return_to_depot(self, vehicle: "VehicleState") -> float:
        """将车辆返回车场并补充容量。

        返回：
            到车场的空驶代价。
        """
        if vehicle.current_position == self.depot:
            # 已在车场 — 仍然补给但代价为零
            vehicle.remaining_capacity = vehicle.capacity
            return 0.0

        cost = self.od[vehicle.current_position][self.depot]
        vehicle.total_cost += cost
        vehicle.current_position = self.depot
        vehicle.remaining_capacity = vehicle.capacity
        return cost

    def _do_service_arc(self, vehicle: "VehicleState",
                        arc: "Arc") -> float:
        """服务一条弧：先空驶到弧起点，再遍历该弧。

        如果剩余容量 < 弧需求量：
            1. 先返回车场（自动补给）
            2. 再从车场前往弧起点

        返回：
            总代价（空驶 + 服务，包含可能的被迫返回车场代价）。
        """
        total_step_cost = 0.0

        if vehicle.remaining_capacity < arc.demanda:
            # 被迫返回车场
            total_step_cost += self._do_return_to_depot(vehicle)

        # 从当前位置空驶到弧起点
        deadhead = self.od[vehicle.current_position][arc.start_vertex]
        total_step_cost += deadhead + arc.coste

        vehicle.total_cost += total_step_cost
        vehicle.current_position = arc.end_vertex
        vehicle.remaining_capacity -= arc.demanda
        vehicle.route.append(arc)

        # 从未访问集合中移除弧及其反向弧
        self._remove_arc_and_reverse(arc)

        return total_step_cost

    def finalize(self) -> float:
        """将所有车辆返回车场并计算最终代价。

        返回：
            总解代价。
        """
        total = 0.0
        for v in self.vehicles:
            if v.current_position != self.depot:
                return_cost = self.od[v.current_position][self.depot]
                v.total_cost += return_cost
            total += v.total_cost
        return total

    # ------------------------------------------------------------------
    # 特征上下文（CARP：拓扑 + 容量感知）
    # ------------------------------------------------------------------
    def _build_context(self, vehicle_idx: int,
                       arc: Optional["Arc"]) -> "DecisionContext":
        """为 (车辆, 弧) 对构建容量感知的 DecisionContext。

        当弧为 None（返回车场动作）时，构建一个将拓扑特征
        表示为车场返回动作的上下文。
        """
        from src.core.state import DecisionContext

        ctx = DecisionContext()
        ctx.random_value = self.rng.random()

        vehicle = self.vehicles[vehicle_idx]
        pos = vehicle.current_position

        # --- 每车特征（与弧无关） ---
        ctx.remaining_capacity = vehicle.remaining_capacity
        ctx.fullness = vehicle.fullness
        ctx.cost_return_depot = self.od[pos][self.depot]

        if arc is None:
            # 返回车场动作的上下文：
            # 设置特征使其表示"返回车场"选项
            ctx.cost_from_here = self.od[pos][self.depot]
            ctx.cost_from_depot_arc = 0.0
            ctx.cost_from_arc_depot = 0.0
            ctx.deadheading_cost = 0.0
            ctx.serving_cost = 0.0
            ctx.demand = 0.0
            ctx.capacity_risk = 0.0
            ctx.degree_start = 0.0
            ctx.degree_end = 0.0
            ctx.clustering_coeff = 0.0
            ctx.betweenness_proxy = 0.0
            ctx.dist_to_depot = 0.0

            # 全局状态
            total_tasks = max(1, self.total_required_arcs)
            ctx.fraction_unserved_tasks = len(self._unvisited) / total_tasks
            ctx.fraction_unassigned_tasks = (
                (total_tasks - self.step_count * 2) / total_tasks
            )
            return ctx

        # --- 弧相关特征 ---
        # 基本拓扑
        ctx.cost_from_here = self.od[pos][arc.start_vertex]
        ctx.cost_from_depot_arc = self.od[self.depot][arc.start_vertex]
        ctx.cost_from_arc_depot = self.od[arc.end_vertex][self.depot]
        ctx.deadheading_cost = self.od[arc.start_vertex][arc.end_vertex]
        ctx.serving_cost = arc.coste

        # 容量特征
        ctx.demand = arc.demanda
        if vehicle.remaining_capacity > 0 and arc.demanda > 0:
            ctx.capacity_risk = arc.demanda / vehicle.remaining_capacity
        else:
            ctx.capacity_risk = 0.0 if arc.demanda == 0 else 1.0

        # 邻居特征（最近的另一条未访问弧）
        ctx.nearest_other_demand, ctx.nearest_other_cost = \
            self._compute_nearest_neighbor_features(arc)

        # 其他车辆特征
        ctx.cost_from_other_vehicle, ctx.remaining_other_vehicle = \
            self._compute_other_vehicle_features(vehicle_idx, arc)

        # 全局状态
        total_tasks = max(1, self.total_required_arcs)
        ctx.fraction_unserved_tasks = len(self._unvisited) / total_tasks
        ctx.fraction_unassigned_tasks = (
            (total_tasks - self.step_count * 2) / total_tasks
        )

        # 扩展拓扑特征
        ctx.degree_start = float(
            self._node_degrees[arc.start_vertex]
            if arc.start_vertex < len(self._node_degrees) else 0
        )
        ctx.degree_end = float(
            self._node_degrees[arc.end_vertex]
            if arc.end_vertex < len(self._node_degrees) else 0
        )

        clus_s = self._get_clustering(arc.start_vertex)
        clus_e = self._get_clustering(arc.end_vertex)
        ctx.clustering_coeff = (clus_s + clus_e) / 2.0

        max_deg = max(self._node_degrees[1:]) if len(self._node_degrees) > 1 else 1
        if max_deg > 0:
            ctx.betweenness_proxy = float(
                self._node_degrees[arc.start_vertex]
            ) / max_deg

        ctx.dist_to_depot = (
            self.od[self.depot][arc.start_vertex] +
            self.od[self.depot][arc.end_vertex]
        ) / 2.0

        return ctx

    def _get_clustering(self, vertex: int) -> float:
        """带缓存的聚类系数查询。"""
        if vertex not in self._clustering_cache:
            self._clustering_cache[vertex] = \
                self.graph.get_clustering_coefficient(vertex)
        return self._clustering_cache[vertex]

    def _compute_nearest_neighbor_features(self, arc: "Arc") -> Tuple[float, float]:
        """计算 DEM1（最近其他弧的需求量）和 CTT1（到最近其他弧的代价）。"""
        best_dem = 0.0
        best_ctt = 0.0
        best_dem_dist = float("inf")
        best_ctt_dist = float("inf")

        for other in self._unvisited:
            if other is arc:
                continue
            ctt_dist = self.od[arc.end_vertex][other.start_vertex]
            if ctt_dist < best_ctt_dist:
                best_ctt_dist = ctt_dist
                best_ctt = float(ctt_dist)

            dem_dist = self.od[other.end_vertex][arc.start_vertex]
            if dem_dist < best_dem_dist:
                best_dem_dist = dem_dist
                best_dem = other.demanda

        return best_dem, best_ctt

    def _compute_other_vehicle_features(self, vehicle_idx: int,
                                        arc: "Arc") -> Tuple[float, float]:
        """计算 CFR1（最近其他车辆的代价）和 RQ1（该车的剩余容量）。"""
        best_dist = float("inf")
        best_remaining = 0.0

        for other_idx, other_v in enumerate(self.vehicles):
            if other_idx == vehicle_idx:
                continue

            dist = self.od[other_v.current_position][arc.start_vertex]
            if dist < best_dist:
                best_dist = dist
                best_remaining = other_v.remaining_capacity

        if best_dist == float("inf"):
            best_dist = 0.0

        return best_dist, best_remaining

    # ------------------------------------------------------------------
    # 环境查询
    # ------------------------------------------------------------------
    def build_context_for_arc(self, arc: "Arc") -> "DecisionContext":
        """为特定弧构建上下文，使用当前活跃车辆。"""
        return self._build_context(self._active_vehicle, arc)

    def build_return_to_depot_context(self) -> "DecisionContext":
        """为"返回车场"特权动作构建上下文。"""
        return self._build_context(self._active_vehicle, None)

    @property
    def active_vehicle(self) -> "VehicleState":
        """当前活跃车辆。"""
        return self.vehicles[self._active_vehicle]

    def get_remaining_capacity(self, vehicle_idx: int = 0) -> float:
        """获取指定车辆的剩余容量。"""
        return self.vehicles[vehicle_idx].remaining_capacity

    def get_vehicle_position(self, vehicle_idx: int = 0) -> int:
        """获取指定车辆的当前位置。"""
        return self.vehicles[vehicle_idx].current_position