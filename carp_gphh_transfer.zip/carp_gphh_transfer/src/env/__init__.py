# src/env/__init__.py
"""仿真环境：CPP与CARP的路径规划模拟器。

- BaseRouteEnv: 共享的仿真循环骨架
- CPPEnv: 中国邮递员问题（无容量约束，单车辆）
- CARPEnv: 容量约束弧路径问题（多车辆，容量限制，返回车场）
"""
from .base_env import BaseRouteEnv
from .cpp_env import CPPEnv
from .carp_env import CARPEnv

__all__ = ["BaseRouteEnv", "CPPEnv", "CARPEnv"]