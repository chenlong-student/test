"""
CPP（中国邮递员问题）仿真环境。

单车辆、无容量约束、单车场。
所有需求弧必须被恰好服务一次。
车辆不需要在完成任务前返回车场。

用于第一阶段：在纯拓扑上训练提议策略。
"""

import math
import random
from typing import List, Tuple, Optional, TYPE_CHECKING

from .base_env import BaseRouteEnv

if TYPE_CHECKING:
    from src.core.graph import Arc, Graph
    from src.core.state import VehicleState, DecisionContext


class CPPEnv(BaseRouteEnv):
    """CPP环境：单车辆、无限容量。

    特征上下文仅包含拓扑特征（无容量特征）。
    """

    def __init__(self, graph: "Graph", depot: int = 1, seed: int = 0):
        super().__init__(graph, depot)
        self.rng = random.Random(seed)
        self._unvisited = []
        self._unvisited_set = set()

        # 预计算的拓扑特征
        self._node_degrees: List[int] = []
        self._clustering_cache: dict = {}

    # ------------------------------------------------------------------
    # 生命周期
    # ------------------------------------------------------------------
    def _create_vehicles(self) -> List["VehicleState"]:
        from src.core.state import VehicleState
        return [VehicleState(
            vehicle_id=0,
            capacity=float("inf"),
            remaining_capacity=float("inf"),
            current_position=self.depot,
        )]

    def reset(self) -> "DecisionContext":
        """重置环境并预计算拓扑特征。"""
        result = super().reset()
        self._node_degrees = self.graph.compute_node_degrees()
        self._clustering_cache = {}
        return result

    # ------------------------------------------------------------------
    # 动作处理
    # ------------------------------------------------------------------
    def _handle_action(self, vehicle_idx: int,
                       arc: Optional["Arc"]) -> float:
        """服务选中的弧。CPP中无需容量检查。"""
        if arc is None:
            # 无动作 — 在CPP中不应发生，但优雅处理
            return 0.0

        vehicle = self.vehicles[vehicle_idx]
        deadhead = self.od[vehicle.current_position][arc.start_vertex]

        # 移动到弧的起点，服务该弧
        vehicle.total_cost += deadhead + arc.coste
        vehicle.current_position = arc.end_vertex
        vehicle.route.append(arc)

        # 从未访问集合中移除弧及其反向弧
        self._remove_arc_and_reverse(arc)

        return deadhead + arc.coste

    def finalize(self) -> float:
        """将车辆返回车场并计算最终代价。

        返回：
            包含最终返回车场路径的总解代价。
        """
        vehicle = self.vehicles[0]
        if vehicle.current_position != self.depot:
            return_cost = self.od[vehicle.current_position][self.depot]
            vehicle.total_cost += return_cost
            return vehicle.total_cost
        return vehicle.total_cost

    # ------------------------------------------------------------------
    # 特征上下文（CPP：仅拓扑）
    # ------------------------------------------------------------------
    def _build_context(self, vehicle_idx: int,
                       arc: Optional["Arc"]) -> "DecisionContext":
        """构建仅拓扑的 DecisionContext。

        当弧为 None 时，返回当前状态的最简上下文。
        """
        from src.core.state import DecisionContext

        ctx = DecisionContext()
        ctx.random_value = self.rng.random()

        if arc is None:
            return ctx

        vehicle = self.vehicles[vehicle_idx]
        pos = vehicle.current_position

        # 基本拓扑特征
        ctx.cost_from_here = self.od[pos][arc.start_vertex]
        ctx.cost_from_depot_arc = self.od[self.depot][arc.start_vertex]
        ctx.cost_from_arc_depot = self.od[arc.end_vertex][self.depot]
        ctx.deadheading_cost = self.od[arc.start_vertex][arc.end_vertex]
        ctx.serving_cost = arc.coste

        # 全局状态
        total_tasks = max(1, self.total_required_arcs)
        ctx.fraction_unserved_tasks = len(self._unvisited) / total_tasks
        ctx.fraction_unassigned_tasks = (total_tasks - self.step_count * 2) / total_tasks

        # 扩展拓扑特征
        ctx.degree_start = float(self._node_degrees[arc.start_vertex]
                                 if arc.start_vertex < len(self._node_degrees) else 0)
        ctx.degree_end = float(self._node_degrees[arc.end_vertex]
                               if arc.end_vertex < len(self._node_degrees) else 0)

        # 聚类系数（起点和终点节点的平均值）
        clus_s = self._get_clustering(arc.start_vertex)
        clus_e = self._get_clustering(arc.end_vertex)
        ctx.clustering_coeff = (clus_s + clus_e) / 2.0

        # 介数代理值
        max_deg = max(self._node_degrees[1:]) if len(self._node_degrees) > 1 else 1
        if max_deg > 0:
            ctx.betweenness_proxy = float(
                self._node_degrees[arc.start_vertex]
            ) / max_deg

        # 到车场的距离
        ctx.dist_to_depot = (
            self.od[self.depot][arc.start_vertex] +
            self.od[self.depot][arc.end_vertex]
        ) / 2.0

        # CPP中容量特征设为中性值
        ctx.remaining_capacity = 1.0
        ctx.demand = 1.0
        ctx.fullness = 0.0
        ctx.cost_return_depot = self.od[pos][self.depot]
        ctx.capacity_risk = 0.0

        return ctx

    def _get_clustering(self, vertex: int) -> float:
        """带缓存的聚类系数查询。"""
        if vertex not in self._clustering_cache:
            self._clustering_cache[vertex] = self.graph.get_clustering_coefficient(vertex)
        return self._clustering_cache[vertex]

    # ------------------------------------------------------------------
    # CPP专用：为特定弧构建上下文（用于批量评分）
    # ------------------------------------------------------------------
    def build_context_for_arc(self, arc: "Arc") -> "DecisionContext":
        """为当前车辆位置下的特定弧构建上下文。

        用于提议策略中对所有未访问弧进行评分。
        """
        return self._build_context(0, arc)