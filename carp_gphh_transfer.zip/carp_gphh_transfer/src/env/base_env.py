"""
弧路径问题仿真环境的抽象基类。

CPPEnv 和 CARPEnv 均继承自此类，共享核心仿真循环结构，
在约束处理上进行特化。
"""

import math
from abc import ABC, abstractmethod
from typing import List, Tuple, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from src.core.graph import Arc, Graph
    from src.core.state import VehicleState, DecisionContext
    from src.core.solution import Solution


class BaseRouteEnv(ABC):
    """弧路径问题的抽象仿真环境。

    子类必须实现：
        - _build_context(): 为当前状态下的某条弧创建 DecisionContext
        - _handle_action(): 执行所选动作并更新状态

    标准交互循环：
        while not env.is_done():
            candidates = env.get_unvisited_arcs()
            scores = policy.evaluate(candidates, env)
            action = select_best(scores)
            env.step(action)
    """

    def __init__(self, graph: "Graph", depot: int = 1):
        """
        参数：
            graph: 已构建好OD矩阵的图实例
            depot: 车场顶点索引（从1开始）
        """
        self.graph = graph
        self.depot = depot
        self.od = graph.od  # OD矩阵的快捷引用

        # 车辆状态列表
        self.vehicles: List["VehicleState"] = []

        # 未访问弧的追踪
        self._unvisited: List["Arc"] = []
        self._unvisited_set: set = set()
        self._reverse_index: dict = {}  # 弧 → 其反向弧

        # 统计信息
        self.total_cost: float = 0.0
        self.step_count: int = 0
        self.total_required_arcs: int = 0

    # ------------------------------------------------------------------
    # 生命周期
    # ------------------------------------------------------------------
    def reset(self) -> "DecisionContext":
        """将环境重置为初始状态。

        返回：
            初始 DecisionContext（在执行任何动作之前）。
        """
        from src.core.state import VehicleState

        required = self.graph.required_arcs
        self._unvisited = list(required)
        self._unvisited_set = set(required)

        # 构建反向弧索引
        self._reverse_index = {}
        for arc in self.graph.all_arcs:
            if arc.reverse_arc is not None:
                self._reverse_index[arc] = arc.reverse_arc

        self.total_required_arcs = len(required)
        self.total_cost = 0.0
        self.step_count = 0

        # 初始化车辆
        self.vehicles = self._create_vehicles()

        return self._build_context(0, None)

    @abstractmethod
    def _create_vehicles(self) -> List["VehicleState"]:
        """创建初始车辆状态。"""
        ...

    # ------------------------------------------------------------------
    # 核心仿真接口
    # ------------------------------------------------------------------
    def step(self, action: Tuple[int, Optional["Arc"]]) -> Tuple[
        "DecisionContext", float, bool, dict
    ]:
        """执行一个决策步骤。

        参数：
            action: (车辆索引, 弧) 对，或 (车辆索引, None) 表示返回车场

        返回：
            (context, cost, done, info) 元组
        """
        vehicle_idx, arc = action
        self.step_count += 1

        cost = self._handle_action(vehicle_idx, arc)
        self.total_cost += cost
        done = self.is_done()

        # 确定下一个活跃车辆（最早可用的）
        next_vehicle_idx = self._select_next_vehicle()
        context = self._build_context(next_vehicle_idx, None)

        info = {
            "step": self.step_count,
            "total_cost": self.total_cost,
            "remaining_arcs": len(self._unvisited),
        }

        return context, cost, done, info

    @abstractmethod
    def _handle_action(self, vehicle_idx: int,
                       arc: Optional["Arc"]) -> float:
        """执行动作并返回产生的代价。"""
        ...

    def is_done(self) -> bool:
        """检查是否所有需求弧都已被服务。"""
        return len(self._unvisited) == 0

    # ------------------------------------------------------------------
    # 查询方法
    # ------------------------------------------------------------------
    def get_unvisited_arcs(self) -> List["Arc"]:
        """获取仍需服务的弧列表。"""
        return self._unvisited

    def get_unvisited_count(self) -> int:
        """获取尚未服务的弧数量。"""
        return len(self._unvisited)

    def get_reverse_arc(self, arc: "Arc") -> Optional["Arc"]:
        """获取某弧的反向弧。"""
        return self._reverse_index.get(arc)

    def distance(self, u: int, v: int) -> float:
        """两顶点之间的最短路径距离。"""
        return self.od[u][v]

    def _remove_arc_and_reverse(self, arc: "Arc") -> None:
        """从未访问集合中移除一条弧及其反向弧。"""
        if arc in self._unvisited_set:
            self._unvisited.remove(arc)
            self._unvisited_set.discard(arc)

        reverse_arc = self._reverse_index.get(arc)
        if reverse_arc is not None and reverse_arc in self._unvisited_set:
            self._unvisited.remove(reverse_arc)
            self._unvisited_set.discard(reverse_arc)

    def _select_next_vehicle(self) -> int:
        """选择下一步为哪辆车规划（默认：第一辆）。"""
        return 0

    # ------------------------------------------------------------------
    # 特征上下文构建（抽象方法）
    # ------------------------------------------------------------------
    @abstractmethod
    def _build_context(self, vehicle_idx: int,
                       arc: Optional["Arc"]) -> "DecisionContext":
        """为特定的（车辆, 弧）对构建 DecisionContext。"""
        ...

    def get_solution(self) -> "Solution":
        """从当前仿真状态构建 Solution 对象。"""
        from src.core.solution import Solution, Route

        solution = Solution(
            depot=self.depot,
            capacity=self.vehicles[0].capacity if self.vehicles else float("inf"),
            num_vehicles=len(self.vehicles),
        )

        for v in self.vehicles:
            route = Route(
                vehicle_id=v.vehicle_id,
                depot=self.depot,
                capacity=v.capacity,
            )
            for i, arc in enumerate(v.route):
                deadhead = 0.0
                if i == 0:
                    deadhead = self.od[self.depot][arc.start_vertex]
                else:
                    prev = v.route[i - 1]
                    deadhead = self.od[prev.end_vertex][arc.start_vertex]
                route.add_arc(arc, deadhead)

            return_cost = 0.0
            if v.route and v.current_position != self.depot:
                return_cost = self.od[v.current_position][self.depot]

            solution.add_route(route, return_cost)

        return solution