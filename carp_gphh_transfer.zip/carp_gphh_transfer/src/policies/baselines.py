"""
用于对比实验的基线策略。

包含：
1. SingleTreePolicy (1S-GPHH)：传统单阶段 GPHH
2. KNNProposalPolicy：第一阶段替换为 K 近邻
3. RandomProposalPolicy：第一阶段替换为随机选择
4. AugmentMergeHeuristic：经典 Augment-Merge 算法
5. PathScanningHeuristic：经典 Path-Scanning 算法
"""

import math
import random
import heapq
from typing import List, Tuple, Optional, TYPE_CHECKING

from .base_policy import BasePolicy

if TYPE_CHECKING:
    from src.env.carp_env import CARPEnv
    from src.env.cpp_env import CPPEnv
    from src.core.graph import Arc

RETURN_TO_DEPOT = None


# ======================================================================
# 1. 单树 GPHH（传统基线）
# ======================================================================

class SingleTreePolicy(BasePolicy):
    """传统单树 GPHH：一棵树对所有未访问弧进行评分。

    所有特征（拓扑 + 容量）输入到单个 GP 树中。
    """

    def __init__(self, gp_individual, gp_engine,
                 name: str = "1S-GPHH"):
        super().__init__(name)
        self.individual = gp_individual
        self.engine = gp_engine
        self._program = gp_engine.compile_program(gp_individual)

        from src.gp.terminals_carp import CARP_TERMINAL_INDEX
        self._terminal_index = CARP_TERMINAL_INDEX

    def select_action(self, env: "CARPEnv") -> Tuple[int, Optional["Arc"]]:
        self._stats["total_decisions"] += 1
        unvisited = env.get_unvisited_arcs()

        if not unvisited:
            return (0, RETURN_TO_DEPOT)

        best_value = None
        best_arc = None

        for arc in unvisited:
            ctx = env._build_context(0, arc)
            arr = ctx.to_context_array(self._terminal_index)
            value = self.engine.execute_program(self._program, arr)

            if best_value is None or (
                self.engine.settings.fitness_type == "MIN"
                and value < best_value
            ) or (
                self.engine.settings.fitness_type != "MIN"
                and value > best_value
            ):
                best_value = value
                best_arc = arc

        if best_arc is None:
            return (0, RETURN_TO_DEPOT)

        return (0, best_arc)

    def simulate(self, env, max_steps: int = 10000):
        """运行完整仿真。"""
        for _ in range(max_steps):
            if env.is_done():
                break
            action = self.select_action(env)
            env.step(action)

        env.finalize()
        return env.get_solution()


# ======================================================================
# 2. KNN 提议基线
# ======================================================================

class KNNProposalPolicy(BasePolicy):
    """按 Dijkstra 距离提出 k 条最近的未访问弧。

    用于测试 CPP 学习的拓扑直觉是否能超越
    简单的几何邻近性。
    """

    def __init__(self, k_candidates: int = 5,
                 name: str = "KNN-Proposal"):
        super().__init__(name)
        self.k = k_candidates

    def select_action(self, env) -> Tuple[int, Optional["Arc"]]:
        raise NotImplementedError("Use propose() with a SelectionPolicy")

    def propose(self, env: "CARPEnv") -> List["Arc"]:
        unvisited = env.get_unvisited_arcs()
        if not unvisited:
            return []

        pos = env.get_vehicle_position()

        # 按到当前位置的 Dijkstra 距离排序弧
        scored = [(env.distance(pos, arc.start_vertex), arc)
                  for arc in unvisited]
        scored.sort(key=lambda x: x[0])

        return [arc for _, arc in scored[:self.k]]


# ======================================================================
# 3. 随机提议基线
# ======================================================================

class RandomProposalPolicy(BasePolicy):
    """提出 k 条随机未访问弧。

    这是下界：测试任何智能提议是否优于随机剪枝。
    """

    def __init__(self, k_candidates: int = 5,
                 seed: int = 0,
                 name: str = "Random-Proposal"):
        super().__init__(name)
        self.k = k_candidates
        self.rng = random.Random(seed)

    def select_action(self, env) -> Tuple[int, Optional["Arc"]]:
        raise NotImplementedError("Use propose() with a SelectionPolicy")

    def propose(self, env: "CARPEnv") -> List["Arc"]:
        unvisited = env.get_unvisited_arcs()
        if not unvisited:
            return []

        n = min(self.k, len(unvisited))
        return self.rng.sample(unvisited, n)


# ======================================================================
# 4. Augment-Merge 启发式
# ======================================================================

class AugmentMergeHeuristic(BasePolicy):
    """面向 CARP 的经典 Augment-Merge 算法。

    阶段 1（扩张）：单独服务每条需求弧，弧之间返回车场。
    阶段 2（合并）：合并节省成本最多的路径。
    """

    def __init__(self, name: str = "Augment-Merge"):
        super().__init__(name)

    def select_action(self, env) -> Tuple[int, Optional["Arc"]]:
        raise NotImplementedError("AugmentMerge uses solve(), not step-by-step")

    def solve(self, env: "CARPEnv") -> "Solution":
        """使用 Augment-Merge 求解 CARP 实例。

        参数:
            env: CARP 环境（需是新重置的）。

        返回:
            包含完整路径的 Solution。
        """
        from src.core.solution import Solution, Route

        od = env.od
        depot = env.depot
        capacity = env.base_capacity
        required = list(env.get_unvisited_arcs())  # 拷贝

        # 阶段 1：为每条需求弧创建一条路径
        routes = []
        for arc in required:
            route = Route(vehicle_id=len(routes), depot=depot,
                         capacity=capacity)
            # 车场 → 弧起点
            d1 = od[depot][arc.start_vertex]
            route.add_arc(arc, d1)
            routes.append(route)

        # 阶段 2：贪心合并
        changed = True
        while changed:
            changed = False
            best_saving = 0.0
            best_pair = None

            for i in range(len(routes)):
                for j in range(len(routes)):
                    if i == j:
                        continue
                    ri = routes[i]
                    rj = routes[j]

                    # 检查容量约束
                    if ri.total_demand + rj.total_demand > capacity:
                        continue

                    # 节省 = 从 ri 返回车场的成本
                    #        + 从车场到 rj 的成本
                    #        - 从 ri 最后一条弧到 rj 第一条弧的成本
                    last_i = ri.arcs[-1] if ri.arcs else None
                    first_j = rj.arcs[0] if rj.arcs else None

                    if last_i is None or first_j is None:
                        continue

                    saving = (od[last_i.end_vertex][depot]
                              + od[depot][first_j.start_vertex]
                              - od[last_i.end_vertex][first_j.start_vertex])

                    if saving > best_saving:
                        best_saving = saving
                        best_pair = (i, j)

            if best_pair is not None and best_saving > 0:
                i, j = best_pair
                # 将 rj 合并到 ri 中
                ri = routes[i]
                rj = routes[j]

                for arc in rj.arcs:
                    prev = ri.arcs[-1] if ri.arcs else None
                    dh = (od[prev.end_vertex][arc.start_vertex]
                          if prev else od[depot][arc.start_vertex])
                    ri.add_arc(arc, dh)

                routes.pop(j)
                changed = True

        # 构建解
        solution = Solution(depot=depot, capacity=capacity,
                           num_vehicles=len(routes))
        for route in routes:
            last = route.arcs[-1] if route.arcs else None
            return_cost = (od[last.end_vertex][depot]
                          if last else 0.0)
            solution.add_route(route, return_cost)

        return solution


# ======================================================================
# 5. Path-Scanning 启发式
# ======================================================================

class PathScanningHeuristic(BasePolicy):
    """面向 CARP 的经典 Path-Scanning 算法。

    贪心地扩展当前路径，添加最近的容量可行的需求弧。
    当没有可行弧时，返回车场并开始一条新路径。
    """

    def __init__(self, name: str = "Path-Scanning"):
        super().__init__(name)

    def select_action(self, env) -> Tuple[int, Optional["Arc"]]:
        raise NotImplementedError("PathScanning uses solve(), not step-by-step")

    def solve(self, env: "CARPEnv") -> "Solution":
        """使用 Path-Scanning 求解 CARP。

        使用 5 条平局打破规则（如 Golden et al.），
        返回找到的最佳解。

        参数:
            env: CARP 环境（需是新重置的）。

        返回:
            所有规则中的最佳 Solution。
        """
        from src.core.solution import Solution, Route

        od = env.od
        depot = env.depot
        capacity = env.base_capacity

        # 5 条平局打破规则
        criteria = [
            ("min_dist", lambda a, pos: od[pos][a.start_vertex]),
            ("max_demand", lambda a, pos: -a.demanda),
            ("min_demand_per_cost", lambda a, pos:
                a.demanda / max(a.coste, 1)),
            ("max_dist_to_depot", lambda a, pos:
                -od[a.end_vertex][depot]),
            ("if_dist_to_depot_lt_half_cap", lambda a, pos:
                od[a.end_vertex][depot]
                if a.demanda <= capacity / 2
                else float("inf")),
        ]

        best_solution = None
        best_cost = float("inf")

        for crit_name, crit_fn in criteria:
            required = list(env.get_unvisited_arcs())
            routes = []
            current_route = None
            current_load = 0.0
            current_pos = depot

            while required:
                # 找到最近的容量可行弧
                feasible = [
                    a for a in required
                    if a.demanda <= capacity - current_load
                ]

                if feasible:
                    # 应用平局打破规则
                    feasible.sort(key=lambda a: (
                        od[current_pos][a.start_vertex],
                        crit_fn(a, current_pos),
                    ))
                    best_arc = feasible[0]
                else:
                    best_arc = None

                if best_arc is None:
                    # 关闭当前路径并开始新路径
                    if current_route:
                        return_cost = od[current_pos][depot]
                        routes.append((current_route, return_cost))
                    current_route = Route(
                        vehicle_id=len(routes),
                        depot=depot, capacity=capacity,
                    )
                    current_load = 0.0
                    current_pos = depot
                    continue

                # 服务该弧
                if current_route is None:
                    current_route = Route(
                        vehicle_id=len(routes),
                        depot=depot, capacity=capacity,
                    )

                deadhead = od[current_pos][best_arc.start_vertex]
                current_route.add_arc(best_arc, deadhead)
                current_load += best_arc.demanda
                current_pos = best_arc.end_vertex
                required.remove(best_arc)

            # 关闭最后一条路径
            if current_route and len(current_route) > 0:
                return_cost = od[current_pos][depot]
                routes.append((current_route, return_cost))

            # 构建解
            sol = Solution(depot=depot, capacity=capacity,
                          num_vehicles=len(routes))
            for route, ret_cost in routes:
                sol.add_route(route, ret_cost)

            if sol.total_cost < best_cost:
                best_cost = sol.total_cost
                best_solution = sol

        return best_solution