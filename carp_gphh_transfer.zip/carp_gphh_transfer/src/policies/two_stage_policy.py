"""
两阶段组合策略：提议 → 选择 流水线。

将冻结的 CPP 训练 ProposalPolicy 与 CARP 训练 SelectionPolicy
绑定在一起，形成完整的 2S-GPHH 决策流水线。

流水线：
    1. ProposalPolicy.propose(env) → top-k 候选弧
    2. SelectionPolicy.select_from_candidates(env, candidates) → 最终动作
    3. 如果没有可行候选 → 自动返回车场
"""

import time
from typing import List, Tuple, Optional, TYPE_CHECKING

from .base_policy import BasePolicy
from .proposal_policy import ProposalPolicy
from .selection_policy import SelectionPolicy, RETURN_TO_DEPOT

if TYPE_CHECKING:
    from src.env.carp_env import CARPEnv
    from src.core.graph import Arc


class TwoStagePolicy(BasePolicy):
    """面向 CARP 的完整两阶段 GPHH 策略。

    组合：
    - 第一阶段（提议）：   CPP 训练的拓扑树 → Top-k 候选
    - 第二阶段（选择）：   CARP 训练的容量树 → 最终动作

    包含返回车场机制作为第 (k+1) 个特权选项。
    """

    def __init__(self, proposal_policy: ProposalPolicy,
                 selection_policy: SelectionPolicy,
                 k_candidates: int = 5,
                 name: str = "2S-GPHH"):
        """
        参数:
            proposal_policy:  已训练并冻结的 ProposalPolicy。
            selection_policy: 已训练的 SelectionPolicy。
            k_candidates:     提议阶段的候选数量。
            name:             策略名称。
        """
        super().__init__(name)
        self.proposal = proposal_policy
        self.selection = selection_policy
        self.k = k_candidates

        # 计时统计
        self._proposal_times: List[float] = []
        self._selection_times: List[float] = []

    def select_action(self, env: "CARPEnv") -> Tuple[int, Optional["Arc"]]:
        """执行两阶段决策流水线。

        参数:
            env: CARP 环境。

        返回:
            (vehicle_idx, arc) 表示服务该弧，
            或 (vehicle_idx, None) 表示返回车场。
        """
        self._stats["total_decisions"] += 1

        # --- 第一阶段：提议 ---
        t_start = time.perf_counter()
        candidates = self.proposal.propose(env)
        t_proposal = time.perf_counter() - t_start
        self._proposal_times.append(t_proposal)

        # 如果没有可行候选 → 返回车场
        if not candidates:
            self._stats["return_to_depot_count"] += 1
            return (0, RETURN_TO_DEPOT)

        # --- 第二阶段：选择 ---
        t_start = time.perf_counter()
        action = self.selection.select_from_candidates(env, candidates)
        t_selection = time.perf_counter() - t_start
        self._selection_times.append(t_selection)

        return action

    def simulate(self, env: "CARPEnv",
                 max_steps: int = 10000) -> "Solution":
        """使用此两阶段策略运行完整的仿真。

        参数:
            env:       CARP 环境（调用前应先 reset）。
            max_steps: 步数安全上限。

        返回:
            包含完整路径方案的 Solution 对象。
        """
        self.reset_stats()

        for _ in range(max_steps):
            if env.is_done():
                break

            action = self.select_action(env)
            env.step(action)

        # 收尾：将所有车辆返回车场
        env.finalize()
        return env.get_solution()

    def get_timing_stats(self) -> dict:
        """获取各阶段的计时统计。"""
        import statistics
        return {
            "proposal_mean_ms": (statistics.fmean(self._proposal_times) * 1000
                                if self._proposal_times else 0.0),
            "selection_mean_ms": (statistics.fmean(self._selection_times) * 1000
                                 if self._selection_times else 0.0),
            "total_mean_ms": (
                statistics.fmean([
                    p + s for p, s in zip(
                        self._proposal_times,
                        self._selection_times
                    )
                ]) * 1000
                if self._proposal_times else 0.0
            ),
        }

    def get_rejection_rate(self) -> float:
        """获取选择返回车场的决策比例。"""
        if self._stats["total_decisions"] == 0:
            return 0.0
        return (self._stats["return_to_depot_count"]
                / self._stats["total_decisions"])

    def reset_stats(self) -> None:
        """重置所有统计信息。"""
        super().reset_stats()
        self._proposal_times = []
        self._selection_times = []
        self.proposal._stats = {
            "total_decisions": 0,
            "return_to_depot_count": 0,
        }
        self.selection._stats = {
            "total_decisions": 0,
            "return_to_depot_count": 0,
        }

    def __repr__(self) -> str:
        return (f"TwoStagePolicy(k={self.k}, "
                f"proposal={self.proposal}, "
                f"selection={self.selection})")