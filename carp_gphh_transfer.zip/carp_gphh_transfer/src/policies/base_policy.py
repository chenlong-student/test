"""
路径策略的抽象基类。

所有策略（单树、两阶段、经典启发式）都实现此接口，
使其在实验中可以互换使用。
"""

from abc import ABC, abstractmethod
from typing import List, Tuple, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from src.core.graph import Arc
    from src.env.base_env import BaseRouteEnv
    from src.env.carp_env import CARPEnv


class BasePolicy(ABC):
    """抽象路径策略。

    策略将当前环境状态映射为动作：
        action = policy.select_action(env)
    其中 action 为 (vehicle_idx, arc) 表示服务该弧，
    或 (vehicle_idx, None) 表示返回车场。
    """

    def __init__(self, name: str = "BasePolicy"):
        self.name = name
        self._stats: dict = {
            "total_decisions": 0,
            "return_to_depot_count": 0,
        }

    @abstractmethod
    def select_action(self, env: "BaseRouteEnv") -> Tuple[int, Optional["Arc"]]:
        """根据当前环境状态选择下一步动作。

        参数:
            env: 路径规划环境（CPPEnv 或 CARPEnv）。

        返回:
            (vehicle_idx, arc) 表示服务该弧，
            或 (vehicle_idx, None) 表示返回车场。
        """
        ...

    def reset_stats(self) -> None:
        """重置内部统计信息。"""
        self._stats = {
            "total_decisions": 0,
            "return_to_depot_count": 0,
        }

    def get_stats(self) -> dict:
        """获取当前运行的策略统计数据。"""
        return self._stats.copy()

    def __repr__(self) -> str:
        return f"{self.name}"