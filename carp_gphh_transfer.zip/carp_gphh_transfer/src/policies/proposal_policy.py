"""
第一阶段：CPP 提议策略（拓扑候选推荐）。

使用冻结的 CPP 训练 GP 树，基于纯拓扑特征对所有未访问弧
进行评分，输出 Top-k 候选集。

关键机制：
- 硬约束门：在评分前过滤掉 demand > Q_max 的弧。
- Top-k 选择：返回优先级评分最高的 k 条弧。
- 填充：如果剩余弧不足 k 条，用拓扑最近邻填充。
"""

import heapq
from typing import List, Tuple, Optional, TYPE_CHECKING

from .base_policy import BasePolicy

if TYPE_CHECKING:
    from src.env.carp_env import CARPEnv
    from src.core.graph import Arc


class ProposalPolicy(BasePolicy):
    """CPP 训练的拓扑提议策略。

    此策略在 CPP 实例（无容量约束）上训练，学习通用的图遍历启发式。
    在第二阶段训练期间被冻结，以防止容量信息泄漏。
    """

    def __init__(self, gp_individual, gp_engine,
                 k_candidates: int = 5,
                 name: str = "ProposalPolicy"):
        """
        参数:
            gp_individual:  冻结的 CPP 训练 DEAP 个体。
            gp_engine:      GPEngine 实例，用于程序执行。
            k_candidates:   提议的候选数量 (k)。
            name:           策略名称，用于日志记录。
        """
        super().__init__(name)
        self.individual = gp_individual
        self.engine = gp_engine
        self.k = k_candidates

        # CPP 终端索引（纯拓扑）—— 必须在编译之前设置，
        # 否则 compile_program 会默认使用引擎的 CARP 索引，
        # 导致 7 个在 CPP/CARP 中索引不同的共享终端名称
        # （DEG_S, DEG_E, CLUS, BETW, DIST_DEPOT, ERC）
        # 静默地从上下文数组中读取错误的特征值。
        from src.gp.terminals_cpp import CPP_TERMINAL_INDEX
        self._terminal_index = CPP_TERMINAL_INDEX

        # 预编译提议程序以加速评估
        self._program = gp_engine.compile_program(
            gp_individual, terminal_index=self._terminal_index
        )

    def select_action(self, env) -> Tuple[int, Optional["Arc"]]:
        """不直接使用 — ProposalPolicy 由 TwoStagePolicy 调用。"""
        raise NotImplementedError(
            "ProposalPolicy.propose() should be called, not select_action()"
        )

    def propose(self, env: "CARPEnv") -> List["Arc"]:
        """从未访问弧中提出 Top-k 候选集。

        流程:
        1. 硬约束门：过滤 demand > Q_max 的弧
        2. 使用 CPP 拓扑树对所有可行弧评分
        3. 按优先级评分返回 top-k
        4. 如果剩余弧不足 k 条，用拓扑最近邻填充

        参数:
            env: 带有未访问弧和车辆状态的 CARP 环境。

        返回:
            最多 k 个 Arc 对象的列表，按提议优先级排序。
        """
        unvisited = env.get_unvisited_arcs()
        if not unvisited:
            return []

        vehicle = env.active_vehicle
        max_capacity = vehicle.capacity

        # --- 步骤 1：硬约束门 ---
        feasible_arcs = []
        for arc in unvisited:
            # 过滤掉即使满容量也无法服务的弧
            if arc.demanda <= max_capacity:
                feasible_arcs.append(arc)

        # 如果没有可行弧，返回空列表 → 触发返回车场
        if not feasible_arcs:
            return []

        # --- 步骤 2：对所有可行弧评分 ---
        scored = []

        for arc in feasible_arcs:
            # 构建纯拓扑特征上下文
            ctx = env._build_context(0, arc)
            arr = ctx.to_context_array(self._terminal_index)

            # 执行 CPP 提议树
            score = self.engine.execute_program(self._program, arr)
            scored.append((score, arc))

        # --- 步骤 3：Top-k 选择 ---
        # 对于 "MIN" 适应度（成本最小化）：评分越低 = 优先级越高
        if self.engine.settings.fitness_type == "MIN":
            scored.sort(key=lambda x: x[0])
        else:
            scored.sort(key=lambda x: -x[0])

        candidates = [arc for _, arc in scored[:self.k]]

        # --- 步骤 4：填充（如果可行弧不足 k 条）---
        if len(candidates) < self.k:
            # 用拓扑最近邻填充
            current_pos = env.get_vehicle_position()
            remaining = [
                arc for arc in feasible_arcs
                if arc not in candidates
            ]
            # 按到当前位置的距离排序
            remaining.sort(
                key=lambda a: env.distance(current_pos, a.start_vertex)
            )

            for arc in remaining:
                if len(candidates) >= self.k:
                    break
                candidates.append(arc)

        return candidates[:self.k]

    def get_terminal_usage(self) -> List[str]:
        """获取此提议树中使用的终端名称列表。"""
        terminals = set()
        for node in self.individual:
            node_name = getattr(node, "name", None)
            node_arity = getattr(node, "arity", None)
            if node_name is not None and node_arity == 0:
                terminals.add(node_name)
        return sorted(terminals)

    @property
    def tree_size(self) -> int:
        return len(self.individual)

    @property
    def tree_height(self) -> int:
        return self.individual.height

    def __repr__(self) -> str:
        return (f"ProposalPolicy(k={self.k}, "
                f"size={self.tree_size}, height={self.tree_height})")