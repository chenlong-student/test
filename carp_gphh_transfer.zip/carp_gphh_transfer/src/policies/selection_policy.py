"""
第二阶段：CARP 选择策略（容量感知细粒度选择）。

使用 CARP 训练的 GP 树评估 k+1 个选项，
其中第 (k+1) 个选项是特权的"返回车场"动作，
用于防止容量死锁。
"""

from typing import List, Tuple, Optional, TYPE_CHECKING

from .base_policy import BasePolicy

if TYPE_CHECKING:
    from src.env.carp_env import CARPEnv
    from src.core.graph import Arc


# 返回车场动作的哨兵值
RETURN_TO_DEPOT = None


class SelectionPolicy(BasePolicy):
    """CARP 训练的容量感知选择策略。

    此策略使用容量感知特征评估 k 条提议弧 + 1 个"返回车场"选项，
    从中选择最佳选项。
    """

    def __init__(self, gp_individual, gp_engine,
                 name: str = "SelectionPolicy"):
        """
        参数:
            gp_individual: CARP 训练的 DEAP 个体。
            gp_engine:     GPEngine 实例，用于程序执行。
            name:          策略名称，用于日志记录。
        """
        super().__init__(name)
        self.individual = gp_individual
        self.engine = gp_engine

        # 预编译选择程序
        self._program = gp_engine.compile_program(gp_individual)

        # CARP 终端索引（容量感知）
        from src.gp.terminals_carp import CARP_TERMINAL_INDEX
        self._terminal_index = CARP_TERMINAL_INDEX

    def select_action(self, env: "CARPEnv") -> Tuple[int, Optional["Arc"]]:
        """从所有未访问弧中选择最佳动作。

        当选择策略以单阶段模式运行（无提议策略）时使用此方法，
        扫描所有未访问弧。
        """
        unvisited = env.get_unvisited_arcs()
        if not unvisited:
            return (0, RETURN_TO_DEPOT)

        vehicle = env.active_vehicle
        vehicle_idx = 0  # 默认使用第一辆车

        best_value = None
        best_arc = None

        for arc in unvisited:
            ctx = env._build_context(vehicle_idx, arc)
            arr = ctx.to_context_array(self._terminal_index)
            value = self.engine.execute_program(self._program, arr)

            if best_value is None or (
                self.engine.settings.fitness_type == "MIN"
                and value < best_value
            ) or (
                self.engine.settings.fitness_type != "MIN"
                and value > best_value
            ):
                best_value = value
                best_arc = arc

        if best_arc is None:
            return (vehicle_idx, RETURN_TO_DEPOT)

        return (vehicle_idx, best_arc)

    def select_from_candidates(
        self, env: "CARPEnv",
        candidates: List["Arc"]
    ) -> Tuple[int, Optional["Arc"]]:
        """从候选池 + 返回车场选项中选择最佳动作。

        这是两阶段模式：选择策略评估 k 条提议弧 + 1 个"返回车场"选项。

        参数:
            env:        CARP 环境。
            candidates: ProposalPolicy 提议的 Top-k 弧。

        返回:
            (vehicle_idx, selected_arc) 或 (vehicle_idx, None) 表示返回车场。
        """
        vehicle_idx = 0
        best_value = None
        best_action = (vehicle_idx, RETURN_TO_DEPOT)

        # --- 评估 k 条候选弧 ---
        for arc in candidates:
            ctx = env._build_context(vehicle_idx, arc)
            arr = ctx.to_context_array(self._terminal_index)
            value = self.engine.execute_program(self._program, arr)

            if best_value is None or (
                self.engine.settings.fitness_type == "MIN"
                and value < best_value
            ) or (
                self.engine.settings.fitness_type != "MIN"
                and value > best_value
            ):
                best_value = value
                best_action = (vehicle_idx, arc)

        # --- 评估第 (k+1) 个选项：返回车场 ---
        rtd_ctx = env.build_return_to_depot_context()
        rtd_arr = rtd_ctx.to_context_array(self._terminal_index)
        rtd_value = self.engine.execute_program(self._program, rtd_arr)

        if best_value is None or (
            self.engine.settings.fitness_type == "MIN"
            and rtd_value < best_value
        ) or (
            self.engine.settings.fitness_type != "MIN"
            and rtd_value > best_value
        ):
            best_action = (vehicle_idx, RETURN_TO_DEPOT)
            self._stats["return_to_depot_count"] += 1

        return best_action

    def get_terminal_usage(self) -> List[str]:
        """获取此选择树中使用的终端名称列表。"""
        terminals = set()
        for node in self.individual:
            node_name = getattr(node, "name", None)
            node_arity = getattr(node, "arity", None)
            if node_name is not None and node_arity == 0:
                terminals.add(node_name)
        return sorted(terminals)

    @property
    def tree_size(self) -> int:
        return len(self.individual)

    @property
    def tree_height(self) -> int:
        return self.individual.height

    def __repr__(self) -> str:
        return (f"SelectionPolicy(size={self.tree_size}, "
                f"height={self.tree_height})")