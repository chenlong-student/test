# src/utils/__init__.py
"""工具函数：I/O解析、日志记录、指标计算与个体管理。

- io_parser: .dat实例文件解析器 + SeededSample随机扰动
- metrics: 统计指标（均值、标准差、PDR、Wilcoxon检验）
- logger: 结构化实验日志（Rich终端 + CSV文件）
- individual_io: GP树的磁盘读写（表达式格式）
"""
from .io_parser import (
    parse_instance_file, build_graph_from_file, build_graph_from_dict,
    list_instance_files, load_all_instances, SeededSample,
)
from .metrics import (
    compute_mean, compute_std, compute_pdr,
    compute_wilcoxon_p_value, summarize_runs,
)
from .logger import ExperimentLogger
from .individual_io import save_individual, load_individual, save_pipeline

__all__ = [
    "parse_instance_file", "build_graph_from_file", "build_graph_from_dict",
    "list_instance_files", "load_all_instances", "SeededSample",
    "compute_mean", "compute_std", "compute_pdr",
    "compute_wilcoxon_p_value", "summarize_runs",
    "ExperimentLogger",
    "save_individual", "load_individual", "save_pipeline",
]