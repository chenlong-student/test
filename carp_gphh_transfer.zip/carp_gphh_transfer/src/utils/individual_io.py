"""
GP个体（树）和解决方案的磁盘I/O。

将GP树导出为紧凑表达式字符串，并重新导入进行再训练。
格式：每个个体一行，前缀表达式格式。
"""

import os
import glob
from typing import List, Optional, Tuple

from src.gp.gp_engine import GPEngine


# --- 兼容性别名（实验脚本使用）----------------------------------------------


def save_individual(individual, filepath: str,
                    metadata: Optional[dict] = None) -> None:
    """将GP个体保存到文件（兼容性包装函数）。

    参数:
        individual:  DEAP个体或PrimitiveTree。
        filepath:    输出文件路径（不含扩展名）。
        metadata:    可选的元数据字典，保存为JSON。
    """
    os.makedirs(os.path.dirname(filepath), exist_ok=True)

    tree = individual.tree if hasattr(individual, "tree") else individual

    # 保存树表达式
    expr_str = str(tree).replace("\n", " ")
    with open(filepath + ".txt", "w", encoding="utf-8") as f:
        f.write(f"# GP Individual\n")
        f.write(f"# Height: {tree.height}\n")
        f.write(f"# Length: {len(tree)}\n")
        f.write(expr_str)
        f.write("\n")

    # 保存元数据（如有提供）
    if metadata:
        import json
        import pickle
        # 保存元数据JSON
        json_meta = {k: v for k, v in metadata.items() if k != "stats"}
        with open(filepath + "_meta.json", "w", encoding="utf-8") as f:
            json.dump(json_meta, f, indent=2, ensure_ascii=False)
        # 保存pickle格式的个体（含DEAP元数据）
        with open(filepath + ".pkl", "wb") as f:
            pickle.dump(individual, f)


def load_individual(filepath: str):
    """从文件加载GP个体（兼容性包装函数）。

    支持 .pkl（pickle格式）和 .txt（表达式格式）。

    参数:
        filepath: 个体文件路径（.pkl 或 .txt）。

    返回:
        反序列化后的DEAP个体或PrimitiveTree。

    异常:
        FileNotFoundError: 文件不存在。
    """
    import pickle

    # 尝试pickle格式
    if filepath.endswith(".pkl") and os.path.isfile(filepath):
        with open(filepath, "rb") as f:
            return pickle.load(f)

    # 也尝试 .pkl 扩展名
    pkl_path = filepath + ".pkl"
    if os.path.isfile(pkl_path):
        with open(pkl_path, "rb") as f:
            return pickle.load(f)

    # 回退到表达式格式
    if filepath.endswith(".txt") and os.path.isfile(filepath):
        return import_individual(filepath, GPEngine())

    txt_path = filepath + ".txt"
    if os.path.isfile(txt_path):
        return import_individual(txt_path, GPEngine())

    raise FileNotFoundError(f"个体文件未找到: {filepath}（尝试过 .pkl 和 .txt）")


def save_pipeline(proposal_individual, selection_individual,
                  output_dir: str, stage1_name: str = "best_stage1",
                  stage2_name: str = "best_stage2") -> Tuple[str, str]:
    """保存完整的2S-GPHH流水线（提案树 + 选择树）。

    参数:
        proposal_individual:  阶段1提案GP个体。
        selection_individual: 阶段2选择GP个体。
        output_dir:           输出目录。
        stage1_name:          提案树文件名。
        stage2_name:          选择树文件名。

    返回:
        (提案路径, 选择路径) 元组。
    """
    os.makedirs(output_dir, exist_ok=True)
    prop_path = os.path.join(output_dir, stage1_name)
    sel_path = os.path.join(output_dir, stage2_name)
    save_individual(proposal_individual, prop_path)
    save_individual(selection_individual, sel_path)
    return prop_path, sel_path


# --- 导出 ------------------------------------------------------------------

def export_individual(individual, filepath: str) -> None:
    """将单个GP个体导出为表达式文件。

    参数:
        individual: gp.PrimitiveTree 或具有 .tree 属性。
        filepath:   输出文件路径（.txt 或 .expr）。
    """
    os.makedirs(os.path.dirname(filepath), exist_ok=True)

    tree = individual.tree if hasattr(individual, "tree") else individual
    # 转换为无换行符的可读前缀表达式
    expr_str = str(tree).replace("\n", " ")

    with open(filepath, "w", encoding="utf-8") as f:
        f.write(f"# GP Individual\n")
        f.write(f"# Height: {tree.height}\n")
        f.write(f"# Length: {len(tree)}\n")
        f.write(expr_str)
        f.write("\n")


def export_best_individual(individual, output_dir: str, stage: str = "stage1",
                           extra_info: Optional[str] = None) -> str:
    """将最佳个体导出到标准位置。

    参数:
        individual:  要导出的个体。
        output_dir:  输出目录。
        stage:       "stage1"（提案）或 "stage2"（选择）。
        extra_info:  可选标识符（例如，种群大小）。

    返回:
        输出文件路径。
    """
    os.makedirs(output_dir, exist_ok=True)

    suffix = f"_{extra_info}" if extra_info else ""
    filename = f"best_{stage}{suffix}.txt"
    filepath = os.path.join(output_dir, filename)

    export_individual(individual, filepath)
    return filepath


# --- 导入 ------------------------------------------------------------------

def import_individual(filepath: str, gp_engine: GPEngine):
    """从表达式文件导入GP个体。

    参数:
        filepath:   表达式文件路径。
        gp_engine:  GPEngine实例（需要其pset）。

    返回:
        反序列化后的PrimitiveTree个体。

    异常:
        FileNotFoundError: 文件不存在。
        ValueError:        文件格式无效。
    """
    if not os.path.isfile(filepath):
        raise FileNotFoundError(f"文件不存在: {filepath}")

    with open(filepath, "r", encoding="utf-8") as f:
        lines = f.readlines()

    # 跳过注释行和空行
    expr_lines = [l.strip() for l in lines
                  if l.strip() and not l.startswith("#")]

    if not expr_lines:
        raise ValueError(f"文件中未找到表达式: {filepath}")

    expr_str = expr_lines[0]

    # 使用gp_engine的pset进行反序列化
    return gp_engine.individual_from_string(expr_str)


def import_best_individual(output_dir: str, stage: str = "stage1",
                           gp_engine: Optional[GPEngine] = None,
                           extra_info: Optional[str] = None):
    """从标准位置导入最佳GP个体。

    参数:
        output_dir:  个体保存的目录。
        stage:       "stage1" 或 "stage2"。
        gp_engine:   GPEngine实例（如未提供则自动创建）。
        extra_info:  可选标识符。

    返回:
        (individual, filepath) 元组。
    """
    suffix = f"_{extra_info}" if extra_info else ""
    filename = f"best_{stage}{suffix}.txt"
    filepath = os.path.join(output_dir, filename)

    if gp_engine is None:
        gp_engine = GPEngine()

    individual = import_individual(filepath, gp_engine)
    return individual, filepath


# --- 批量操作 ---------------------------------------------------------------

def export_population(population: List, output_dir: str,
                      prefix: str = "pop") -> List[str]:
    """导出整个种群。

    参数:
        population: 个体列表。
        output_dir: 输出目录。
        prefix:     文件名前缀。

    返回:
        已导出文件的路径列表。
    """
    os.makedirs(output_dir, exist_ok=True)
    paths = []
    for i, ind in enumerate(population):
        path = os.path.join(output_dir, f"{prefix}_{i:04d}.txt")
        export_individual(ind, path)
        paths.append(path)
    return paths


def import_population(directory: str, gp_engine: GPEngine,
                      pattern: str = "pop_*.txt") -> List:
    """从目录导入所有GP个体。

    参数:
        directory: 包含表达式文件的目录。
        gp_engine: GPEngine实例。
        pattern:   用于文件匹配的glob模式。

    返回:
        已导入个体的列表。
    """
    search_pattern = os.path.join(directory, pattern)
    files = sorted(glob.glob(search_pattern))

    individuals = []
    for f in files:
        try:
            ind = import_individual(f, gp_engine)
            individuals.append(ind)
        except Exception as e:
            print(f"警告：跳过 {f}: {e}")

    return individuals


# --- 解决方案日志 ----------------------------------------------------------

def log_solution(solution, filepath: str) -> None:
    """将CARP/CPP解决方案附加到日志文件。

    每一行：实例名称 \\t 总成本 \\t 路线1 | 路线2 | ...

    参数:
        solution: RouteSolution对象。
        filepath: 日志文件路径。
    """
    os.makedirs(os.path.dirname(filepath), exist_ok=True)

    routes_str = " | ".join(
        ",".join(str(a) for a in route) for route in solution.routes
    )
    line = f"{solution.instance_name}\t{solution.total_cost}\t{routes_str}\n"

    with open(filepath, "a", encoding="utf-8") as f:
        f.write(line)


# --- 别名（兼容旧API） ----------------------------------------------------------

save_individual = export_individual
load_individual = import_individual


def save_pipeline(proposal_ind, selection_ind, output_dir: str,
                   proposal_name: str = "best_stage1",
                   selection_name: str = "best_stage2") -> Tuple[str, str]:
    """将提议树和选择树一起保存（完整管线）。

    参数:
        proposal_ind:   提议策略个体。
        selection_ind:  选择策略个体。
        output_dir:     输出目录。
        proposal_name:  提议文件的名称。
        selection_name: 选择文件的名称。

    返回:
        (proposal_path, selection_path) 元组。
    """
    os.makedirs(output_dir, exist_ok=True)

    prop_path = os.path.join(output_dir, f"{proposal_name}.txt")
    sel_path = os.path.join(output_dir, f"{selection_name}.txt")

    export_individual(proposal_ind, prop_path)
    export_individual(selection_ind, sel_path)

    return prop_path, sel_path