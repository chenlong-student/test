"""
实验跟踪的结构化日志记录器。

使用Rich库进行终端输出，使用标准CSV进行文件日志。
在所有实验脚本中提供一致的格式化输出。
"""

import os
import csv
import json
from datetime import datetime
from typing import Dict, List, Optional, Any


class ExperimentLogger:
    """GP进化和实验运行的日志记录器。

    功能：
    - 带进度指示的Rich控制台输出
    - 每代指标的CSV统计文件
    - 结构化事件记录的JSONLines日志
    - 自动时间戳和运行元数据
    """

    def __init__(self, log_dir: str = "logs",
                 experiment_name: str = "experiment",
                 use_rich: bool = True):
        """
        参数:
            log_dir:         日志文件目录。
            experiment_name: 日志文件名称前缀。
            use_rich:        是否使用Rich进行控制台输出。
        """
        self.log_dir = log_dir
        self.experiment_name = experiment_name
        self.use_rich = use_rich

        os.makedirs(log_dir, exist_ok=True)

        # 用于唯一运行标识的时间戳
        self.timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        self.run_id = f"{experiment_name}_{self.timestamp}"

        # 文件路径
        self.csv_path = os.path.join(log_dir, f"{self.run_id}_stats.csv")
        self.jsonl_path = os.path.join(log_dir, f"{self.run_id}_events.jsonl")
        self.summary_path = os.path.join(log_dir, f"{self.run_id}_summary.json")

        # Rich控制台
        self.console = None
        if use_rich:
            try:
                from rich.console import Console
                self.console = Console()
            except ImportError:
                pass

        # 初始化CSV
        self._csv_file = None
        self._csv_writer = None
        self._csv_initialized = False

        # 元数据
        self.metadata: Dict[str, Any] = {
            "run_id": self.run_id,
            "experiment": experiment_name,
            "timestamp": self.timestamp,
        }

    # ------------------------------------------------------------------
    # CSV代数统计
    # ------------------------------------------------------------------
    def init_csv(self, columns: List[str]) -> None:
        """初始化CSV统计文件，写入列标题。"""
        self._csv_file = open(self.csv_path, "w", newline="", encoding="utf-8")
        self._csv_writer = csv.writer(self._csv_file)
        self._csv_writer.writerow(columns)
        self._csv_initialized = True

    def log_csv_row(self, row: List[Any]) -> None:
        """向CSV统计文件追加一行。"""
        if not self._csv_initialized:
            raise RuntimeError("CSV未初始化。请先调用 init_csv()。")
        self._csv_writer.writerow(row)
        self._csv_file.flush()

    def close_csv(self) -> None:
        """关闭CSV文件。"""
        if self._csv_file:
            self._csv_file.close()
            self._csv_file = None

    # ------------------------------------------------------------------
    # JSONLines事件日志
    # ------------------------------------------------------------------
    def log_event(self, event_type: str, data: Dict[str, Any]) -> None:
        """将结构化事件记录为一行JSON。"""
        entry = {
            "timestamp": datetime.now().isoformat(),
            "event_type": event_type,
            **data,
        }
        with open(self.jsonl_path, "a", encoding="utf-8") as f:
            f.write(json.dumps(entry, ensure_ascii=False) + "\n")

    # ------------------------------------------------------------------
    # 控制台输出
    # ------------------------------------------------------------------
    def info(self, message: str) -> None:
        """输出信息消息。"""
        if self.console:
            self.console.print(f"[cyan][INFO][/cyan] {message}")
        else:
            print(f"[INFO] {message}")

    def success(self, message: str) -> None:
        """输出成功消息。"""
        if self.console:
            self.console.print(f"[green][OK][/green] {message}")
        else:
            print(f"[OK] {message}")

    def warning(self, message: str) -> None:
        """输出警告消息。"""
        if self.console:
            self.console.print(f"[yellow][WARN][/yellow] {message}")
        else:
            print(f"[WARN] {message}")

    def error(self, message: str) -> None:
        """输出错误消息。"""
        if self.console:
            self.console.print(f"[red][ERROR][/red] {message}")
        else:
            print(f"[ERROR] {message}")

    def section(self, title: str) -> None:
        """输出章节标题。"""
        if self.console:
            self.console.print(f"\n[bold magenta]{'='*60}[/bold magenta]")
            self.console.print(f"[bold magenta]  {title}[/bold magenta]")
            self.console.print(f"[bold magenta]{'='*60}[/bold magenta]\n")
        else:
            print(f"\n{'='*60}")
            print(f"  {title}")
            print(f"{'='*60}\n")

    def table(self, headers: List[str], rows: List[List[Any]],
              title: str = "") -> None:
        """输出格式化表格。"""
        if self.console:
            from rich.table import Table
            tbl = Table(title=title)
            for h in headers:
                tbl.add_column(h)
            for row in rows:
                tbl.add_row(*[str(c) for c in row])
            self.console.print(tbl)
        else:
            if title:
                print(f"\n--- {title} ---")
            print("\t".join(headers))
            for row in rows:
                print("\t".join(str(c) for c in row))

    # ------------------------------------------------------------------
    # 摘要
    # ------------------------------------------------------------------
    def save_summary(self, summary_data: Dict[str, Any]) -> None:
        """将最终实验摘要保存为JSON。"""
        data = {
            **self.metadata,
            **summary_data,
        }
        with open(self.summary_path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)

        self.info(f"摘要已保存到 {self.summary_path}")

    def set_metadata(self, key: str, value: Any) -> None:
        """设置元数据字段。"""
        self.metadata[key] = value

    def __del__(self):
        self.close_csv()