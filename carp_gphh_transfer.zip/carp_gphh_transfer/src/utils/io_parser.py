"""
CARP/CPP 基准实例的 .dat 文件解析器。

解析西语（UC）格式的实例文件。该格式用于：
- CARP: gdb, val, egl 数据集
- CPP: 从 CARP 转换而来的数据集（仅拓扑信息，无容量/需求）

格式示例：
    NOMBRE : gdb1
    VERTICES : 12
    ARISTAS_REQ : 22
    VEHICULOS : 5
    CAPACIDAD : 5
    LISTA_ARISTAS_REQ :
    ( 1, 2)  coste 13 demanda 1
    ...
    DEPOSITO :  1
"""

import glob
import os
import re
from typing import Dict, List, Optional, Tuple, Union
from dataclasses import dataclass


# ---------------------------------------------------------------------------
# 解析用的中间数据结构
# ---------------------------------------------------------------------------

@dataclass
class EdgeRow:
    """解析后的单条边行（中间表示，在构建 Graph 对象之前）。"""
    edge_id: int               # 边索引（从 0 开始）
    node_a: int                # 端点 A
    node_b: int                # 端点 B
    cost: float                # 通行成本
    demand: float = 0.0        # 需求量


class DistanceMatrix:
    """解析阶段的稀疏距离矩阵。

    在 .dat 文件中，边行同时定义了图的连通性和距离。
    此类在构建 Graph 之前暂存这些信息。
    """

    def __init__(self):
        self._data: Dict[Tuple[int, int], float] = {}

    def set_distance(self, u: int, v: int, dist: float) -> None:
        self._data[(u, v)] = dist

    def get_distance(self, u: int, v: int) -> float:
        return self._data.get((u, v), float("inf"))

    def all_pairs(self) -> Dict[Tuple[int, int], float]:
        return dict(self._data)


@dataclass
class ParsedInstance:
    """保存实例的解析后数据（在构建 Graph 对象之前）。"""
    name: str                            # 实例名称
    vertices: int                        # 顶点数量
    edges: List[EdgeRow]                 # 所有边行
    required_edges: List[EdgeRow]        # 需服务边行
    depot: int                           # 车库顶点编号（默认 1）
    capacity: float                      # 车辆容量（CPP 无容量，设为 inf）
    num_vehicles: int                    # 车辆数量
    raw: Dict[str, Union[int, float, str]]  # 原始描述符字段

    def to_graph(self) -> "Graph":
        """从解析后的数据构建 Graph 对象。

        每条边展开为一对有向弧（正向 + 逆向）。
        需服务边具有正需求（demand > 0），非需边需求为 0。
        CPP 实例：所有边均为需求边（demand=1，与拓扑相关）。

        返回:
            完全构建的 Graph 对象。
        """
        from src.core.graph import Graph

        graph = Graph(vertices=self.vertices, depot=self.depot)

        required_ids = {e.edge_id for e in self.required_edges}

        for e in self.edges:
            is_required = e.edge_id in required_ids
            demand = float(e.demand) if is_required else 0.0
            # CPP 实例：所有边均有需求但原始 demand 为 0，设为 1
            if is_required and demand <= 0:
                demand = 1.0
            graph.add_arc_pair(e.node_a, e.node_b, demand, e.cost)

        graph.build_od_matrix()
        return graph


# ---------------------------------------------------------------------------
# 公共 API
# ---------------------------------------------------------------------------

def parse_dat_file(filepath: str) -> ParsedInstance:
    """解析单个西语格式的 .dat 实例文件。

    这是主要入口点。支持 CARP（有需求/容量）和 CPP（纯拓扑）格式。

    参数:
        filepath: .dat 文件的路径。

    返回:
        ParsedInstance 对象。

    异常:
        FileNotFoundError: 文件不存在。
        ValueError:        文件格式无法识别。
    """
    with open(filepath, "r", encoding="utf-8") as f:
        text = f.read()

    # 分割为节
    sections = _split_uc_sections(text)

    # 解析头部描述符
    desc = _parse_uc_header(sections.get("HEADER", ""))

    # 解析需服务边列表
    required_edges = _parse_uc_edge_list(
        sections.get("LISTA_ARISTAS_REQ", ""),
        start_id=0,
    )

    # 解析非需边列表（仅 CARP 中有）
    non_required_edges: List[EdgeRow] = []
    next_id = len(required_edges)
    if "LISTA_ARISTAS_NOREQ" in sections:
        non_required_edges = _parse_uc_edge_list(
            sections["LISTA_ARISTAS_NOREQ"],
            start_id=next_id,
        )
        next_id += len(non_required_edges)

    # 所有边 = 需求边 + 非需求边
    all_edges = required_edges + non_required_edges

    # 车辆容量：CARP 有 CAPACIDAD，CPP 没有
    capacity = float(desc.get("CAPACIDAD", float("inf")))

    # 车辆数量
    num_vehicles = int(desc.get("VEHICULOS", 1))

    # 车库
    depot = int(desc.get("DEPOSITO", 1))

    return ParsedInstance(
        name=str(desc.get("NOMBRE", "unknown")),
        vertices=int(desc.get("VERTICES", 0)),
        edges=all_edges,
        required_edges=required_edges,
        depot=depot,
        capacity=capacity,
        num_vehicles=num_vehicles,
        raw=desc,
    )


def parse_multiple_dat_files(data_dir: str, file_pattern: str = "*.dat",
                             verbose: bool = True) -> List[ParsedInstance]:
    """解析目录中所有匹配的 .dat 文件。

    参数:
        data_dir:     数据目录路径。
        file_pattern: 文件的 glob 模式（默认："*.dat"）。
        verbose:      是否打印进度信息。

    返回:
        ParsedInstance 对象列表。
    """
    search = os.path.join(data_dir, file_pattern)
    files = sorted(glob.glob(search))

    if not files:
        raise FileNotFoundError(f"在 {search} 中未找到文件")

    if verbose:
        print(f"在 {data_dir} 中找到 {len(files)} 个实例文件")

    instances = []
    for fp in files:
        try:
            inst = parse_dat_file(fp)
            instances.append(inst)
            if verbose:
                print(f"  ✓ {os.path.basename(fp)} → {inst.name}")
        except Exception as e:
            if verbose:
                print(f"  ✗ {os.path.basename(fp)}: {e}")

    return instances


# ---------------------------------------------------------------------------
# 兼容性包装（供实验脚本使用——返回字典而非 ParsedInstance）
# ---------------------------------------------------------------------------

def parse_instance_file(filepath: str) -> dict:
    """解析实例文件并返回字典格式的数据。

    这是 parse_dat_file 的兼容性包装函数，
    返回字典而非 ParsedInstance，供实验脚本使用。

    参数:
        filepath: .dat 文件的路径。

    返回:
        包含已解析实例数据的字典。
    """
    inst = parse_dat_file(filepath)

    edges_list = []
    for e in inst.edges:
        edges_list.append({
            "u": e.node_a,
            "v": e.node_b,
            "cost": e.cost,
            "demand": e.demand,
        })

    # 需服务边的索引
    required_ids = {e.edge_id for e in inst.required_edges}
    required_indices = [i for i, e in enumerate(inst.edges) if e.edge_id in required_ids]

    return {
        "name": inst.name,
        "vertices": inst.vertices,
        "depot": inst.depot,
        "capacity": inst.capacity,
        "vehicles": inst.num_vehicles,
        "edges": edges_list,
        "required_edges": required_indices,
    }


def build_graph_from_dict(data: dict) -> "Graph":
    """从 parse_instance_file 返回的字典构建 Graph 对象。

    参数:
        data: parse_instance_file 返回的字典。

    返回:
        完全构建的 Graph 对象。
    """
    from src.core.graph import Graph

    required_set = set(data.get("required_edges") or [])

    graph = Graph(vertices=data["vertices"], depot=data.get("depot", 1))

    for i, e in enumerate(data.get("edges", [])):
        is_required = i in required_set
        demand = float(e.get("demand", 0)) if is_required else 0.0
        # CPP 实例：需服务边但 demand 为 0，设为 1
        if is_required and demand <= 0:
            demand = 1.0
        cost = float(e.get("cost", 0))
        graph.add_arc_pair(e["u"], e["v"], demand, cost)

    graph.build_od_matrix()
    return graph


def build_graph_from_file(filepath: str) -> "Graph":
    """直接从 .dat 文件构建 Graph 对象（便捷函数）。

    等同于 build_graph_from_dict(parse_instance_file(filepath))。
    """
    return build_graph_from_dict(parse_instance_file(filepath))


def list_instance_files(data_dir: str, pattern: str = "*.dat") -> List[str]:
    """列出数据目录中所有匹配的实例文件。

    参数:
        data_dir: 数据目录路径。
        pattern:  文件的 glob 模式（默认："*.dat"）。

    返回:
        匹配文件路径的排序列表。
    """
    search = os.path.join(data_dir, pattern)
    files = sorted(glob.glob(search))
    return files


def load_all_instances(data_dir: str, pattern: str = "*.dat",
                       verbose: bool = True) -> List["Graph"]:
    """加载数据目录中所有实例并构建 Graph 对象。

    参数:
        data_dir: 数据目录路径。
        pattern:  文件的 glob 模式（默认："*.dat"）。
        verbose:  是否打印进度信息。

    返回:
        Graph 对象列表。
    """
    files = list_instance_files(data_dir, pattern)

    if not files:
        raise FileNotFoundError(
            f"在 {os.path.join(data_dir, pattern)} 中未找到文件"
        )

    if verbose:
        print(f"在 {data_dir} 中找到 {len(files)} 个实例文件")

    graphs = []
    for fp in files:
        try:
            graph = build_graph_from_file(fp)
            graphs.append(graph)
            if verbose:
                print(f"  ✓ {os.path.basename(fp)} → V={graph.vertices}")
        except Exception as e:
            if verbose:
                print(f"  ✗ {os.path.basename(fp)}: {e}")

    return graphs


# ---------------------------------------------------------------------------
# 随机扰动采样器（用于训练样本生成）
# ---------------------------------------------------------------------------

class SeededSample:
    """基于种子的随机扰动实例包装器。

    对图进行需求和成本的随机扰动，以生成多样化的训练样本。
    每次使用相同种子创建时，会产生相同的扰动结果，保证可复现性。

    属性:
        graph:          内部 Graph 对象（扰动后的副本）。
        depot:          车库顶点编号。
        num_vehicles:   车辆数量（创建后外部设置）。
        capacity:       车辆容量（创建后外部设置）。
        vehicles:       车辆对象列表（创建后外部设置）。
        positions:      车辆当前位置列表（创建后外部设置）。
    """

    def __init__(self, graph: "Graph", seed: int,
                 demand_change_rate: float = 0.20,
                 cost_change_rate: float = 0.20):
        import copy
        import random as _random

        rng = _random.Random(seed)

        # 对图进行深拷贝并扰动
        self.graph = copy.deepcopy(graph)
        self.seed = seed
        self.depot = self.graph.depot

        # 对图中所有弧施加随机扰动
        for arc in self.graph.all_arcs:
            arc.randomize(rng, demand_change_rate, cost_change_rate)

        # 外部可覆盖的属性（GP 评估通过 instance.capacity/num_vehicles 访问）
        self.num_vehicles: int = getattr(graph, 'num_vehicles', 0)
        self.capacity: float = getattr(graph, 'capacity', 0.0)
        self.vehicles: list = []
        self.positions: list = []

    def __repr__(self) -> str:
        return (f"SeededSample(depot={self.depot}, "
                f"vehicles={self.num_vehicles}, "
                f"capacity={self.capacity})")

    def __getattr__(self, name):
        """将未定义的属性访问委托给底层 Graph 对象。

        这使得 SeededSample 可以作为 instance 参数直接传入
        CPPEnv/CARPEnv（后者期望 Graph 的方法如 .od, .all_arcs 等）。
        """
        # 避免递归：__getattr__ 仅在常规查找失败时被调用
        graph = self.__dict__.get("graph", None)
        if graph is not None:
            return getattr(graph, name)
        raise AttributeError(
            f"'{type(self).__name__}' 没有属性 '{name}'"
        )


# ---------------------------------------------------------------------------
# 西语（UC）格式解析器
# ---------------------------------------------------------------------------

def _split_uc_sections(text: str) -> Dict[str, str]:
    """将 .dat 文本按 LISTA_* 节标题分割为命名节。

    西语格式使用形如 "LISTA_ARISTAS_REQ :" 的标签作为节标题。
    在此标签之前的所有内容属于 HEADER。
    每条边占一行，格式为 "(u, v)  coste X  demanda Y"。

    返回:
        {节名: 节文本}
    """
    lines = text.strip().split("\n")

    sections: Dict[str, str] = {}
    current_section = "HEADER"
    current_lines: List[str] = []

    # 识别 LISTA_* 节标题的模式
    lista_pattern = re.compile(r"^(LISTA_[A-Z_]+)\s*:?\s*$")

    for line in lines:
        stripped = line.strip()
        if not stripped:
            continue

        m = lista_pattern.match(stripped)
        if m:
            # 保存上一节
            if current_lines:
                sections[current_section] = "\n".join(current_lines)
                current_lines = []
            current_section = m.group(1)
        else:
            current_lines.append(line)

    # 保存最后一节
    if current_lines:
        sections[current_section] = "\n".join(current_lines)

    return sections


def _parse_uc_header(text: str) -> Dict[str, Union[int, float, str]]:
    """解析西语格式的头部描述符。

    解析 KEY : VALUE 行。已知键包括：
        NOMBRE, COMENTARIO, VERTICES, ARISTAS_REQ, ARISTAS_NOREQ,
        VEHICULOS, CAPACIDAD, TIPO_COSTES_ARISTAS, COSTE_TOTAL_REQ,
        DEPOSITO

    返回:
        描述符字典。
    """
    desc: Dict[str, Union[int, float, str]] = {}

    for line in text.strip().split("\n"):
        line = line.strip()
        if not line:
            continue

        # 匹配 KEY : VALUE 或 KEY: VALUE
        m = re.match(r"^([A-Z_]+)\s*:\s*(.*)", line)
        if not m:
            continue

        key = m.group(1).strip()
        val = m.group(2).strip()

        # 数值字段
        int_keys = {
            "VERTICES", "ARISTAS_REQ", "ARISTAS_NOREQ",
            "VEHICULOS", "DEPOSITO",
        }
        float_keys = {"CAPACIDAD", "COSTE_TOTAL_REQ"}

        if key in int_keys:
            try:
                desc[key] = int(val)
            except ValueError:
                desc[key] = val
        elif key in float_keys:
            try:
                desc[key] = float(val)
            except ValueError:
                desc[key] = val
        else:
            desc[key] = val

    return desc


def _parse_uc_edge_list(text: str, start_id: int = 0) -> List[EdgeRow]:
    """解析西语格式的边列表节。

    边行格式：
        CARP: ( 1, 2)  coste 13 demanda 1
        CPP:  ( 1, 2)  coste 13

    参数:
        text:     边列表节的原始文本。
        start_id: 起始边 ID。

    返回:
        EdgeRow 对象列表。
    """
    edges: List[EdgeRow] = []
    edge_id = start_id

    for line in text.strip().split("\n"):
        line = line.strip()
        if not line:
            continue

        # 匹配 (u, v) coste X demanda Y 或 (u, v) coste X
        # 使用宽松的正则表达式
        m = re.match(
            r"\(\s*(\d+)\s*,\s*(\d+)\s*\)\s+"
            r"coste\s+([\d.]+)"
            r"(?:\s+demanda\s+([\d.]+))?",
            line,
        )
        if not m:
            continue

        u = int(m.group(1))
        v = int(m.group(2))
        cost = float(m.group(3))
        demand = float(m.group(4)) if m.group(4) is not None else 0.0

        edges.append(EdgeRow(
            edge_id=edge_id,
            node_a=u,
            node_b=v,
            cost=cost,
            demand=demand,
        ))
        edge_id += 1

    return edges