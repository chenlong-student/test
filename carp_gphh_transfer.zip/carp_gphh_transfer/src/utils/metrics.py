"""
实验评估的统计指标。

提供均值、标准差、性能退化率（PDR）以及统计检验的计算。
"""

import math
import statistics
from typing import List, Dict, Optional, Tuple


def compute_mean(values: List[float]) -> float:
    """计算算术平均值。"""
    if not values:
        return 0.0
    return statistics.fmean(values)


def compute_std(values: List[float]) -> float:
    """计算总体标准差。"""
    if len(values) <= 1:
        return 0.0
    return statistics.pstdev(values)


def compute_median(values: List[float]) -> float:
    """计算中位数。"""
    if not values:
        return 0.0
    return statistics.median(values)


def compute_pdr(base_values: List[float],
                transfer_values: List[float]) -> float:
    """计算性能退化率（Performance Degradation Ratio）。

    PDR = (mean(迁移) - mean(基准)) / mean(基准) × 100%

    正值PDR表示迁移效果比基准差。
    负值PDR表示迁移效果更好。

    参数:
        base_values:     基准适应度值（如在目标问题上训练的）。
        transfer_values: 迁移适应度值（如零样本迁移的）。

    返回:
        PDR百分比（如15.3表示15.3%的退化）。
    """
    base_mean = compute_mean(base_values)
    transfer_mean = compute_mean(transfer_values)

    if base_mean == 0.0:
        return 0.0

    return (transfer_mean - base_mean) / abs(base_mean) * 100.0


def compute_speedup_ratio(base_times: List[float],
                          new_times: List[float]) -> float:
    """计算加速比：基准时间 / 新方法时间。

    值大于1表示新方法更快。
    """
    base_mean = compute_mean(base_times)
    new_mean = compute_mean(new_times)

    if new_mean == 0.0:
        return float("inf")

    return base_mean / new_mean


def compute_wilcoxon_p_value(sample1: List[float],
                             sample2: List[float]) -> float:
    """计算Wilcoxon符号秩检验的p值。

    检验两个配对样本是否显著不同。

    参数:
        sample1, sample2: 配对观测值（长度相同）。

    返回:
        双尾p值。
    """
    from scipy import stats

    if len(sample1) != len(sample2):
        raise ValueError("样本长度必须相同")

    _, p_value = stats.wilcoxon(sample1, sample2)
    return float(p_value)


def summarize_runs(results: List[Dict],
                   metric_keys: Optional[List[str]] = None) -> Dict:
    """将多次独立运行的结果汇总为统计字典。

    参数:
        results:    每次运行的结果字典列表。
        metric_keys: 需要汇总的键（默认为所有数值键）。

    返回:
        包含以下键的字典：{指标}_mean, {指标}_std, {指标}_median, {指标}_min, {指标}_max。
    """
    if not results:
        return {}

    if metric_keys is None:
        # 自动检测数值键
        metric_keys = []
        for key, val in results[0].items():
            if isinstance(val, (int, float)):
                metric_keys.append(key)

    summary = {}
    for key in metric_keys:
        values = [r[key] for r in results if key in r]
        if values:
            summary[f"{key}_mean"] = compute_mean(values)
            summary[f"{key}_std"] = compute_std(values)
            summary[f"{key}_median"] = compute_median(values)
            summary[f"{key}_min"] = min(values)
            summary[f"{key}_max"] = max(values)

    summary["n_runs"] = len(results)
    return summary


def confidence_interval(values: List[float],
                        confidence: float = 0.95) -> Tuple[float, float]:
    """计算均值的置信区间。

    参数:
        values:     样本值。
        confidence: 置信水平（默认0.95）。

    返回:
        (下限, 上限)。
    """
    from scipy import stats

    n = len(values)
    if n < 2:
        return (values[0], values[0]) if values else (0.0, 0.0)

    mean = compute_mean(values)
    sem = compute_std(values) / math.sqrt(n)
    interval = sem * stats.t.ppf((1 + confidence) / 2.0, n - 1)

    return (mean - interval, mean + interval)