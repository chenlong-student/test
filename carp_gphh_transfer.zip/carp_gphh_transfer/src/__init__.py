# src/__init__.py
"""2S-GPHH: 面向CARP的两阶段遗传编程超启发式算法，结合CPP迁移学习。"""