# 2S-GPHH：面向CARP的两阶段遗传编程超启发式算法

**基于CPP到CARP的跨问题迁移学习**

---

## 概述

本仓库实现了一种新颖的**两阶段GPHH**框架，通过将路径决策分解为两个阶段来求解
**容量约束弧路径问题（CARP）**：

1. **第一阶段 — 提议策略（CPP训练）**：一个纯拓扑GP树，对所有未访问弧进行
   评分，基于纯图结构直觉提出**Top-k**候选集。

2. **第二阶段 — 选择策略（CARP训练）**：一个容量感知GP树，评估k+1个选项
   （k条候选弧 + 返回车场），选择考虑容量约束的最佳动作。

### 核心创新点

- **跨问题迁移学习**：CPP训练得到的拓扑直觉可以零样本迁移到任意容量
  或规模的CARP问题上
- **自动容量死锁预防**："返回车场"特权动作消除了不可行路径
- **O(k·N) 复杂度**：容量敏感计算仅限制在k+1个候选项上
- **高可解释性**：拓扑直觉与资源调度显式分离

## 项目结构

```
carp_gphh_transfer/
├── config/                 # YAML配置文件
├── data/                   # 基准测试数据集
├── src/
│   ├── core/               # 图、状态、解等数据结构
│   ├── env/                # CPP和CARP仿真环境
│   ├── gp/                 # GP引擎、原语、终端符、树简化器
│   ├── policies/           # 两阶段策略 + 基线方法
│   └── utils/              # 输入输出、日志、指标、序列化
├── experiments/            # 训练和评估脚本
├── saved_models/           # 训练好的GP个体
├── visualization/          # 绘图和分析脚本
├── logs/                   # 实验日志
├── outputs/                # 结构化实验结果
├── requirements.txt
└── setup.py
```

## 安装

```bash
cd carp_gphh_transfer
pip install -r requirements.txt
pip install -e .
```

## 快速开始

### 1. 训练第一阶段：CPP提议策略

```bash
python experiments/train_stage1_proposal.py --dataset gdb --seed 0 --generations 51
```

在CPP实例上训练纯拓扑GP树，保存到 `saved_models/proposal_trees/run_00/`。

### 2. 训练第二阶段：CARP选择策略

```bash
python experiments/train_stage2_selection.py \
    --proposal saved_models/proposal_trees/run_00/best_ind_final.pkl \
    --dataset gdb --seed 0 --generations 51
```

冻结提议树，在CARP实例上训练容量感知的选择树。

### 3. 运行主基准测试（模块2）

```bash
python experiments/run_main_benchmark.py \
    --dataset gdb \
    --proposal saved_models/proposal_trees/run_00/best_ind_final.pkl \
    --selection saved_models/selection_trees/paired_with_best_ind_final/best_ind_final.pkl \
    --single-tree saved_models/proposal_trees/run_00/best_ind_final.pkl \
    --runs 30
```

### 4. 运行零样本泛化测试（模块3）

```bash
python experiments/run_generalization_test.py \
    --dataset egl \
    --proposal saved_models/proposal_trees/run_00/best_ind_final.pkl \
    --selection saved_models/selection_trees/paired_with_best_ind_final/best_ind_final.pkl \
    --runs 30
```

### 5. 运行消融实验（模块4）

```bash
python experiments/run_ablation_study.py \
    --ablation k_sensitivity \
    --dataset gdb \
    --selection saved_models/selection_trees/paired_with_best_ind_final/best_ind_final.pkl \
    --runs 10
```

### 6. 可视化结果

```bash
python visualization/plot_performance.py
python visualization/plot_generalization.py
python visualization/plot_ablation.py
python visualization/plot_tree.py --input saved_models/proposal_trees/run_00/best_ind_final.pkl
```

## 配置说明

所有超参数通过 `config/` 目录中的YAML文件配置：

| 文件 | 内容 |
|------|------|
| `gp_config.yaml` | GP进化参数（种群大小、交叉率、树深度、k值） |
| `env_config.yaml` | CPP/CARP环境配置（容量、车辆数） |
| `exp_config.yaml` | 实验路径、并行执行、日志配置 |

## 基线方法

| 方法 | 描述 |
|--------|-------------|
| **1S-GPHH** | 传统单树GPHH，使用全部特征 |
| **2S-GPHH-KNN** | 两阶段，使用K近邻作为提议策略 |
| **2S-GPHH-Random** | 两阶段，使用随机提议策略 |
| **Augment-Merge** | 经典运筹学构造启发式 |
| **Path-Scanning** | 经典运筹学构造启发式（5种平局打破规则） |

## 引用

如果您在研究中使用了本代码，请引用：

```
[待定 — 论文引用]
```

## 许可证

MIT License