#!/usr/bin/env python3
"""
GP树结构可视化。

将DEAP PrimitiveTree渲染为树形图，使用networkx + matplotlib绘制，
也可选择导出为Graphviz DOT格式。

用法:
    python visualization/plot_tree.py --input saved_models/proposal_trees/run_00/best_ind_final.pkl
"""

import os
import sys
import argparse
import pickle
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import networkx as nx
from deap import gp


def build_tree_graph(individual) -> nx.DiGraph:
    """将DEAP PrimitiveTree转换为NetworkX有向图。

    每个节点存储:
    - label: 节点的显示名称
    - type:  "primitive"（函数节点）或 "terminal"（终端节点）
    - arity: 对于函数节点，表示子节点数量
    """
    G = nx.DiGraph()
    node_counter = [0]

    def add_subtree(parent_idx, nodes, start_idx):
        node = nodes[start_idx]
        current_idx = node_counter[0]
        node_counter[0] += 1

        # 确定节点标签
        if isinstance(node, gp.Primitive):
            label = node.name
            ntype = "primitive"
            arity = node.arity
        else:
            val = getattr(node, "value", node)
            name = getattr(node, "name", None)
            if name is not None:
                label = name
            else:
                label = str(val)
                if isinstance(val, float) and len(label) > 6:
                    label = f"{val:.3f}"
            ntype = "terminal"
            arity = 0

        G.add_node(current_idx, label=label, type=ntype)

        if parent_idx is not None:
            G.add_edge(parent_idx, current_idx)

        # 处理子节点
        child_start = start_idx + 1
        if isinstance(node, gp.Primitive):
            for _ in range(node.arity):
                child_start = add_subtree(current_idx, nodes, child_start)

        return child_start

    nodes = list(individual)
    add_subtree(None, nodes, 0)
    return G


def plot_tree(individual, output_path: str, title: str = "GP树结构"):
    """将GP树渲染为层级结构图。

    使用NetworkX的层级布局进行绘制。
    """
    G = build_tree_graph(individual)

    # 尝试使用Graphviz层级布局，失败则回退到弹簧布局
    try:
        pos = nx.nx_agraph.graphviz_layout(G, prog="dot")
    except ImportError:
        # 回退方案：使用弹簧布局
        pos = nx.spring_layout(G, k=1, iterations=50)

    labels = nx.get_node_attributes(G, "label")
    types = nx.get_node_attributes(G, "type")

    # 按节点类型着色
    node_colors = [
        "#3498db" if types.get(n) == "primitive" else "#2ecc71"
        for n in G.nodes()
    ]

    fig, ax = plt.subplots(figsize=(16, 10))
    nx.draw(
        G, pos, labels=labels,
        node_color=node_colors,
        node_size=800,
        font_size=8,
        font_color="white",
        edge_color="gray",
        arrows=False,
        ax=ax,
    )

    # 图例
    from matplotlib.patches import Patch
    legend_elements = [
        Patch(facecolor="#3498db", label="函数节点 (Primitive)"),
        Patch(facecolor="#2ecc71", label="终端节点 (Terminal)"),
    ]
    ax.legend(handles=legend_elements, loc="upper right")

    ax.set_title(title)
    ax.axis("off")

    plt.tight_layout()
    plt.savefig(output_path)
    plt.close()
    print(f"树结构图已保存至 {output_path}")


def main():
    parser = argparse.ArgumentParser(description="绘制GP树结构图")
    parser.add_argument("--input", type=str, required=True,
                       help="个体.pkl文件路径")
    parser.add_argument("--output", type=str,
                       default="visualization/output_figures/tree.png")
    parser.add_argument("--title", type=str, default="GP树结构")
    args = parser.parse_args()

    os.makedirs(os.path.dirname(args.output), exist_ok=True)

    with open(args.input, "rb") as f:
        individual = pickle.load(f)

    print(f"已加载个体: 大小={len(individual)}, 高度={individual.height}")

    # 简化并打印表达式
    try:
        from src.gp.tree_simplifier import tree_to_expression
        expr = tree_to_expression(individual)
        print(f"表达式: {expr}")
    except Exception as e:
        print(f"无法简化: {e}")
        print(f"原始个体: {individual}")

    plot_tree(individual, args.output, args.title)


if __name__ == "__main__":
    main()