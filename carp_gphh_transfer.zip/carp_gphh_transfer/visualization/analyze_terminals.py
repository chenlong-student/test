#!/usr/bin/env python3
"""
分析GP树中的终端特征使用频率。

生成柱状图，展示各代最优个体中哪些终端（特征）的使用频率最高。

用法:
    python visualization/analyze_terminals.py --input saved_models/proposal_trees/run_00/best_ind_final.pkl
"""

import os
import sys
import argparse
import json
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns
from deap import gp


def count_terminals(individual) -> dict:
    """统计GP树中每个终端的出现次数。

    返回:
        字典，映射 终端名称 → 出现次数。
    """
    counts = {}
    for node in individual:
        node_name = getattr(node, "name", None)
        node_arity = getattr(node, "arity", None)
        if node_name is not None and node_arity == 0:
            counts[node_name] = counts.get(node_name, 0) + 1
    return counts


def plot_terminal_heatmap(terminal_data: dict, output_path: str,
                          title: str = "终端特征使用频率"):
    """绘制终端使用频率的柱状图。

    参数:
        terminal_data: 字典，映射 终端名称 → 次数。
        output_path:   输出图像路径。
        title:         图表标题。
    """
    if not terminal_data:
        print("没有终端数据可以绘制")
        return

    # 按频率排序
    sorted_items = sorted(terminal_data.items(), key=lambda x: -x[1])
    names = [item[0] for item in sorted_items]
    counts = [item[1] for item in sorted_items]

    fig, ax = plt.subplots(figsize=(10, 6))

    # 按终端类型着色
    topology_terms = {"CFH", "CFD", "CTD", "DC", "SC", "FRT", "FUT",
                      "DEG_S", "DEG_E", "CLUS", "BETW", "DIST_DEPOT"}
    capacity_terms = {"DEM", "FULL", "RQ", "CR", "CFR1", "CTT1", "DEM1",
                      "RQ1", "CapRisk", "ERC"}

    colors = []
    for name in names:
        if name in topology_terms:
            colors.append("#3498db")  # 蓝色表示拓扑特征
        elif name in capacity_terms:
            colors.append("#e74c3c")  # 红色表示容量特征
        else:
            colors.append("#95a5a6")  # 灰色表示未知

    bars = ax.bar(range(len(names)), counts, color=colors, edgecolor="white")
    ax.set_xticks(range(len(names)))
    ax.set_xticklabels(names, rotation=45, ha="right")
    ax.set_ylabel("出现次数")
    ax.set_title(title)

    # 图例
    from matplotlib.patches import Patch
    legend_elements = [
        Patch(facecolor="#3498db", label="拓扑特征"),
        Patch(facecolor="#e74c3c", label="容量特征"),
        Patch(facecolor="#95a5a6", label="其他"),
    ]
    ax.legend(handles=legend_elements, loc="upper right")

    # 添加数值标签
    for bar, count in zip(bars, counts):
        ax.text(
            bar.get_x() + bar.get_width() / 2,
            bar.get_height() + max(counts) * 0.02,
            str(count),
            ha="center", va="bottom", fontsize=9,
        )

    plt.tight_layout()
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    plt.savefig(output_path)
    plt.close()
    print(f"终端分析图已保存至 {output_path}")


def analyze_evolution_stats(stats_file: str, output_path: str):
    """从进化统计JSON文件中分析各代终端使用情况。"""
    if not os.path.exists(stats_file):
        print(f"统计文件未找到: {stats_file}")
        return

    with open(stats_file, "r") as f:
        stats = json.load(f)

    # 绘制各代唯一终端数量
    gens = [s["gen"] for s in stats]
    unique_terms = [s.get("best_unique_terms", 0) for s in stats]
    sizes = [s.get("best_size", 0) for s in stats]

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 5))

    ax1.plot(gens, unique_terms, marker=".", color="blue", linewidth=1.5)
    ax1.set_xlabel("代数")
    ax1.set_ylabel("最优个体中唯一终端数")
    ax1.set_title("进化过程中的终端多样性")

    ax2.plot(gens, sizes, marker=".", color="green", linewidth=1.5)
    ax2.set_xlabel("代数")
    ax2.set_ylabel("树大小（节点数）")
    ax2.set_title("进化过程中的最优树大小")

    plt.tight_layout()
    plt.savefig(output_path)
    plt.close()
    print(f"进化分析图已保存至 {output_path}")


def main():
    parser = argparse.ArgumentParser(
        description="分析GP树中终端特征的使用情况"
    )
    parser.add_argument("--input", type=str, default=None,
                       help="个体.pkl或.json文件路径")
    parser.add_argument("--stats", type=str, default=None,
                       help="evolution_stats.json文件路径，用于代际分析")
    parser.add_argument("--output-dir", type=str,
                       default="visualization/output_figures")
    args = parser.parse_args()

    os.makedirs(args.output_dir, exist_ok=True)

    if args.input and os.path.exists(args.input):
        if args.input.endswith(".json"):
            with open(args.input, "r") as f:
                data = json.load(f)
            terminals_used = data.get("terminals_used", [])
            if terminals_used:
                terminal_data = {t: 1 for t in terminals_used}
                plot_terminal_heatmap(
                    terminal_data,
                    os.path.join(args.output_dir, "terminals_heatmap.png"),
                    f"使用的终端: {os.path.basename(args.input)}",
                )
        elif args.input.endswith(".pkl"):
            import pickle
            with open(args.input, "rb") as f:
                individual = pickle.load(f)
            counts = count_terminals(individual)
            plot_terminal_heatmap(
                counts,
                os.path.join(args.output_dir, "terminals_heatmap.png"),
                "最优个体中的终端特征频率",
            )

    if args.stats and os.path.exists(args.stats):
        analyze_evolution_stats(
            args.stats,
            os.path.join(args.output_dir, "evolution_analysis.png"),
        )

    print("完成。")


if __name__ == "__main__":
    main()