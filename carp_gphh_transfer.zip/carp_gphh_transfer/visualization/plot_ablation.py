#!/usr/bin/env python3
"""
消融实验结果可视化：k-灵敏度分析与收敛曲线。

用法:
    python visualization/plot_ablation.py --k-input outputs/ablation_k_sensitivity.csv
"""

import os
import sys
import argparse
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns

sns.set_style("whitegrid")
plt.rcParams.update({"font.size": 12, "figure.dpi": 150})


def plot_k_sensitivity(df: pd.DataFrame, output_dir: str):
    """双轴图：成本与时间随k值的变化。"""
    fig, ax1 = plt.subplots(figsize=(10, 6))
    ax2 = ax1.twinx()

    agg = df.groupby("k").agg({
        "mean_cost": ["mean", "std"],
        "mean_time_s": "mean",
    }).sort_index()

    k_values = agg.index.values

    # 成本（左轴）
    color1 = "tab:blue"
    ax1.errorbar(
        k_values,
        agg[("mean_cost", "mean")].values,
        yerr=agg[("mean_cost", "std")].values,
        marker="o", color=color1, linewidth=2, capsize=5,
        label="平均成本",
    )
    ax1.set_xlabel("候选池大小 k")
    ax1.set_ylabel("平均总成本", color=color1)
    ax1.tick_params(axis="y", labelcolor=color1)

    # 时间（右轴）
    color2 = "tab:red"
    ax2.plot(
        k_values,
        agg[("mean_time_s", "mean")].values,
        marker="s", color=color2, linewidth=2, linestyle="--",
        label="平均时间",
    )
    ax2.set_ylabel("平均求解时间 (s)", color=color2)
    ax2.tick_params(axis="y", labelcolor=color2)

    # 最佳区域标注
    ax1.axvspan(3, 8, alpha=0.1, color="green")
    ax1.text(5.5, ax1.get_ylim()[0] + 0.05 * (ax1.get_ylim()[1] - ax1.get_ylim()[0]),
            "最佳区域", ha="center", fontsize=10, color="green")

    ax1.set_title("k-灵敏度分析：成本–时间权衡")
    lines1, labels1 = ax1.get_legend_handles_labels()
    lines2, labels2 = ax2.get_legend_handles_labels()
    ax1.legend(lines1 + lines2, labels1 + labels2, loc="upper right")

    plt.tight_layout()
    out_path = os.path.join(output_dir, "k_sensitivity.png")
    plt.savefig(out_path)
    plt.close()
    print(f"k-灵敏度图已保存至 {out_path}")


def plot_proposal_ablation(df: pd.DataFrame, output_dir: str):
    """柱状图：不同建议机制的成本对比。"""
    fig, ax = plt.subplots(figsize=(8, 5))

    agg = df.groupby("proposal_mode")["mean_cost"].agg(["mean", "std"])

    colors = ["#2ecc71", "#f39c12", "#e74c3c"]
    bars = ax.bar(
        agg.index, agg["mean"].values,
        yerr=agg["std"].values,
        color=colors, edgecolor="white", capsize=8,
    )

    ax.set_ylabel("平均总成本")
    ax.set_xlabel("建议机制")
    ax.set_title("建议机制消融分析")

    for bar, val in zip(bars, agg["mean"].values):
        ax.text(
            bar.get_x() + bar.get_width() / 2,
            bar.get_height() * 1.01,
            f"{val:.1f}",
            ha="center", va="bottom", fontsize=11,
        )

    plt.tight_layout()
    out_path = os.path.join(output_dir, "proposal_ablation.png")
    plt.savefig(out_path)
    plt.close()
    print(f"建议机制消融图已保存至 {out_path}")


def main():
    parser = argparse.ArgumentParser(description="绘制消融实验结果图")
    parser.add_argument("--k-input", type=str,
                       default="outputs/ablation_k_sensitivity.csv")
    parser.add_argument("--proposal-input", type=str,
                       default="outputs/ablation_proposal.csv")
    parser.add_argument("--output-dir", type=str,
                       default="visualization/output_figures")
    args = parser.parse_args()

    os.makedirs(args.output_dir, exist_ok=True)

    if os.path.exists(args.k_input):
        df_k = pd.read_csv(args.k_input)
        plot_k_sensitivity(df_k, args.output_dir)

    if os.path.exists(args.proposal_input):
        df_prop = pd.read_csv(args.proposal_input)
        plot_proposal_ablation(df_prop, args.output_dir)

    print("完成。")


if __name__ == "__main__":
    main()