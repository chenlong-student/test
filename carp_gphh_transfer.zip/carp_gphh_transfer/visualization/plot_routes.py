#!/usr/bin/env python3
"""
路径轨迹可视化。

在图上绘制车辆路径，对比2S-GPHH（聚类、局部化路径）
与1S-GPHH（分散、长跳转路径）。

用法:
    python visualization/plot_routes.py --instance data/carp_benchmarks/gdb/gdb1.dat
"""

import os
import sys
import argparse
import math
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import numpy as np
import networkx as nx

from src.utils.io_parser import parse_instance_file, build_graph_from_dict
from src.utils.individual_io import load_individual
from src.gp.gp_engine import GPEngine, GPSettings
from src.env.carp_env import CARPEnv
from src.policies import (
    TwoStagePolicy, ProposalPolicy, SelectionPolicy,
    SingleTreePolicy,
)


def layout_graph(graph, depot: int):
    """使用弹簧布局为图节点生成二维坐标。"""
    G = nx.DiGraph()
    for arc in graph.all_arcs:
        G.add_edge(arc.start_vertex, arc.end_vertex, weight=arc.coste)

    # 使用弹簧布局实现自然间距
    pos = nx.spring_layout(G, seed=42, k=2, iterations=100)

    # 将车场置于中心
    depot_pos = pos.get(depot, np.array([0.5, 0.5]))
    offset = np.array([0.5, 0.5]) - depot_pos
    for v in pos:
        pos[v] = pos[v] + offset

    return pos


def plot_routes(instance, routes_1s, routes_2s, output_path: str,
                instance_name: str = ""):
    """绘制路径轨迹对比图。

    参数:
        instance:       图/实例对象。
        routes_1s:      1S-GPHH的Route对象列表。
        routes_2s:      2S-GPHH的Route对象列表。
        output_path:    输出图像路径。
        instance_name:  标题中使用的实例名称。
    """
    pos = layout_graph(instance, instance.depot)

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(18, 8))

    # --- 绘制图节点 ---
    for ax in (ax1, ax2):
        # 车场
        ax.scatter(
            *pos[instance.depot],
            c="red", s=200, marker="s", zorder=5, label="车场",
            edgecolors="darkred", linewidths=2,
        )
        # 其他节点
        other_nodes = [
            v for v in pos.keys()
            if v != instance.depot and v <= instance.vertices
        ]
        if other_nodes:
            xs = [pos[v][0] for v in other_nodes]
            ys = [pos[v][1] for v in other_nodes]
            ax.scatter(xs, ys, c="lightgray", s=80, zorder=3, edgecolors="gray")

        # 绘制边（非需求弧用浅灰色表示）
        for arc in instance.all_arcs:
            if not arc.is_required:
                x1, y1 = pos[arc.start_vertex]
                x2, y2 = pos[arc.end_vertex]
                ax.plot([x1, x2], [y1, y2], color="lightgray",
                       linewidth=0.5, alpha=0.3, zorder=1)

        ax.set_aspect("equal")
        ax.axis("off")

    # --- 绘制1S-GPHH路径（左侧） ---
    colors_1s = plt.cm.Reds(np.linspace(0.4, 0.9, max(len(routes_1s), 1)))
    _draw_routes(ax1, routes_1s, pos, colors_1s, "1S-GPHH")
    ax1.set_title("1S-GPHH（单树策略）", fontsize=14, fontweight="bold")

    # --- 绘制2S-GPHH路径（右侧） ---
    colors_2s = plt.cm.Blues(np.linspace(0.4, 0.9, max(len(routes_2s), 1)))
    _draw_routes(ax2, routes_2s, pos, colors_2s, "2S-GPHH")
    ax2.set_title("2S-GPHH（两阶段策略）", fontsize=14, fontweight="bold")

    fig.suptitle(f"路径轨迹对比: {instance_name}",
                fontsize=16, fontweight="bold")
    plt.tight_layout()

    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    plt.savefig(output_path)
    plt.close()
    print(f"路径图已保存至 {output_path}")


def _draw_routes(ax, routes, pos, colors, label_prefix: str):
    """在坐标轴上绘制一组路径。"""
    depot = None
    for route in routes:
        if route.arcs:
            depot = route.depot
            break
    if depot is None:
        return

    for i, route in enumerate(routes):
        if not route.arcs:
            continue
        color = colors[i % len(colors)]

        # 车场 → 第一条弧
        first = route.arcs[0]
        dx1, dy1 = pos[depot]
        dx2, dy2 = pos[first.start_vertex]
        ax.annotate(
            "", xy=(dx2, dy2), xytext=(dx1, dy1),
            arrowprops=dict(
                arrowstyle="->", color=color,
                lw=2, alpha=0.7, shrinkA=5, shrinkB=5,
            ),
        )

        # 弧之间的死heading
        for j in range(len(route.arcs) - 1):
            a1 = route.arcs[j]
            a2 = route.arcs[j + 1]
            x1, y1 = pos[a1.end_vertex]
            x2, y2 = pos[a2.start_vertex]
            ax.annotate(
                "", xy=(x2, y2), xytext=(x1, y1),
                arrowprops=dict(
                    arrowstyle="->", color=color,
                    lw=2, alpha=0.7, shrinkA=5, shrinkB=5,
                ),
            )

        # 最后一条弧 → 车场
        last = route.arcs[-1]
        x1, y1 = pos[last.end_vertex]
        x2, y2 = pos[depot]
        ax.annotate(
            "", xy=(x2, y2), xytext=(x1, y1),
            arrowprops=dict(
                arrowstyle="->", color=color,
                lw=2, alpha=0.5, shrinkA=5, shrinkB=5,
                linestyle="dashed",
            ),
        )

    # 图例
    legend_elements = [
        mpatches.Patch(color="red", label="车场"),
        mpatches.Patch(color=list(colors[0]) if len(colors) > 0 else "blue",
                      label=f"{label_prefix} 路径"),
    ]
    ax.legend(handles=legend_elements, loc="upper right", fontsize=9)


def simulate_and_get_routes(instance, policy) -> list:
    """模拟策略并获取生成的路径。"""
    env = CARPEnv(
        instance,
        depot=instance.depot,
        capacity=getattr(instance, 'capacity', 100.0),
        num_vehicles=getattr(instance, 'num_vehicles', 5),
        seed=42,
    )
    env.reset()
    while not env.is_done():
        action = policy.select_action(env)
        env.step(action)
    env.finalize()
    solution = env.get_solution()
    return solution.routes


def main():
    parser = argparse.ArgumentParser(description="绘制路径轨迹对比图")
    parser.add_argument("--instance", type=str, required=True,
                       help="CARP实例文件路径 (.dat)")
    parser.add_argument("--proposal", type=str, default=None,
                       help="建议策略树文件路径 (.pkl)")
    parser.add_argument("--selection", type=str, default=None,
                       help="选择策略树文件路径 (.pkl)")
    parser.add_argument("--single-tree", type=str, default=None,
                       help="1S-GPHH树文件路径 (.pkl)")
    parser.add_argument("--k-candidates", type=int, default=5)
    parser.add_argument("--output", type=str,
                       default="visualization/output_figures/route_comparison.png")
    args = parser.parse_args()

    if not os.path.exists(args.instance):
        print(f"实例文件未找到: {args.instance}")
        return

    # 加载实例
    data = parse_instance_file(args.instance)
    graph = build_graph_from_dict(data)
    instance_name = os.path.basename(args.instance).replace(".dat", "")

    # GP引擎
    settings = GPSettings(problem="CARP", k_candidates=args.k_candidates)
    engine = GPEngine(settings)

    # 模拟1S-GPHH
    routes_1s = []
    if args.single_tree and os.path.exists(args.single_tree):
        st_ind = load_individual(args.single_tree)
        policy_1s = SingleTreePolicy(st_ind, engine)
        routes_1s = simulate_and_get_routes(graph, policy_1s)
        print(f"1S-GPHH: {len(routes_1s)} 条路径")

    # 模拟2S-GPHH
    routes_2s = []
    if (args.proposal and args.selection and
        os.path.exists(args.proposal) and os.path.exists(args.selection)):
        prop_ind = load_individual(args.proposal)
        sel_ind = load_individual(args.selection)
        prop_pol = ProposalPolicy(prop_ind, engine, k_candidates=args.k_candidates)
        sel_pol = SelectionPolicy(sel_ind, engine)
        policy_2s = TwoStagePolicy(prop_pol, sel_pol, args.k_candidates)
        routes_2s = simulate_and_get_routes(graph, policy_2s)
        print(f"2S-GPHH: {len(routes_2s)} 条路径")

    if routes_1s or routes_2s:
        plot_routes(graph, routes_1s, routes_2s, args.output, instance_name)
    else:
        print("没有可用的策略。请提供 --single-tree 或 --proposal + --selection。")


if __name__ == "__main__":
    main()