#!/usr/bin/env python3
"""
泛化结果可视化：PDR箱线图与迁移折线图。

读取 generalization_pdr_results.csv 并生成：
1. 按策略和容量倍率分组的PDR箱线图
2. 跨容量变体的迁移性能折线图

用法:
    python visualization/plot_generalization.py --input outputs/generalization_pdr_results.csv
"""

import os
import sys
import argparse
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns

sns.set_style("whitegrid")
plt.rcParams.update({
    "font.size": 12,
    "figure.dpi": 150,
})


def plot_pdr_boxplot(df: pd.DataFrame, output_dir: str):
    """按策略和容量倍率绘制PDR箱线图。"""
    fig, ax = plt.subplots(figsize=(10, 6))

    # 筛选有PDR值的行
    pdr_df = df.dropna(subset=["pdr_percent"])

    sns.boxplot(
        data=pdr_df,
        x="capacity_multiplier",
        y="pdr_percent",
        hue="policy",
        ax=ax,
        palette="Set2",
    )

    ax.axhline(y=0, color="gray", linestyle="--", linewidth=1)
    ax.set_xlabel("容量倍率 (× Q_base)")
    ax.set_ylabel("性能退化率 (PDR, %)")
    ax.set_title("跨容量泛化能力：PDR分布")
    ax.legend(title="策略", loc="upper right")

    plt.tight_layout()
    out_path = os.path.join(output_dir, "pdr_boxplot.png")
    plt.savefig(out_path)
    plt.close()
    print(f"PDR箱线图已保存至 {out_path}")


def plot_transfer_lines(df: pd.DataFrame, output_dir: str):
    """折线图：各策略在不同容量变体下的平均成本。"""
    fig, ax = plt.subplots(figsize=(10, 6))

    cost_df = df.dropna(subset=["mean_cost"])

    for policy in cost_df["policy"].unique():
        policy_df = cost_df[cost_df["policy"] == policy]
        agg = policy_df.groupby("capacity_multiplier")["mean_cost"].agg(
            ["mean", "std"]
        ).sort_index()

        ax.errorbar(
            agg.index, agg["mean"], yerr=agg["std"],
            marker="o", label=policy, linewidth=2, capsize=5,
        )

    ax.set_xlabel("容量倍率 (× Q_base)")
    ax.set_ylabel("平均总成本")
    ax.set_title("容量稳健性：成本随容量缩放的变化")
    ax.legend()

    plt.tight_layout()
    out_path = os.path.join(output_dir, "transfer_lines.png")
    plt.savefig(out_path)
    plt.close()
    print(f"迁移折线图已保存至 {out_path}")


def main():
    parser = argparse.ArgumentParser(description="绘制泛化结果图")
    parser.add_argument("--input", type=str,
                       default="outputs/generalization_pdr_results.csv")
    parser.add_argument("--output-dir", type=str,
                       default="visualization/output_figures")
    args = parser.parse_args()

    if not os.path.exists(args.input):
        print(f"输入文件未找到: {args.input}")
        return

    os.makedirs(args.output_dir, exist_ok=True)
    df = pd.read_csv(args.input)

    plot_pdr_boxplot(df, args.output_dir)
    plot_transfer_lines(df, args.output_dir)
    print("完成。")


if __name__ == "__main__":
    main()