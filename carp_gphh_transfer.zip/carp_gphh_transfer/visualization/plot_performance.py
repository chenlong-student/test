#!/usr/bin/env python3
"""
性能对比可视化：成本与运行时间。

读取 main_benchmark_results.csv 并生成：
1. 柱状图：各方法在不同数据集上的平均成本
2. 折线图：运行时间 vs 实例规模 (N)
3. 加速比图

用法:
    python visualization/plot_performance.py --input outputs/main_benchmark_results.csv
"""

import os
import sys
import argparse
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

import pandas as pd
import matplotlib
matplotlib.use("Agg")  # 非交互式后端
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import numpy as np
import seaborn as sns

# 全局样式
sns.set_style("whitegrid")
plt.rcParams.update({
    "font.size": 12,
    "axes.titlesize": 14,
    "axes.labelsize": 13,
    "legend.fontsize": 11,
    "figure.dpi": 150,
})


def plot_cost_comparison(df: pd.DataFrame, output_dir: str):
    """柱状图：各策略在各实例集上的平均成本。"""
    fig, ax = plt.subplots(figsize=(12, 6))

    policies = df["policy"].unique()
    datasets = df["instance"].apply(
        lambda x: x.split("-")[0] if "-" in x else x[:3]
    ).unique()

    # 按数据集聚合
    agg = df.groupby(["policy", df["instance"].str[:3]])["mean_cost"].mean().unstack()

    x = np.arange(len(agg.columns))
    width = 0.8 / len(agg.index)

    colors = plt.cm.Set2(np.linspace(0, 1, len(agg.index)))

    for i, (policy, row) in enumerate(agg.iterrows()):
        bars = ax.bar(x + i * width, row.values, width,
                     label=policy, color=colors[i], edgecolor="white")

    ax.set_ylabel("平均总成本")
    ax.set_xlabel("数据集")
    ax.set_title("各数据集解质量对比")
    ax.set_xticks(x + width * (len(agg.index) - 1) / 2)
    ax.set_xticklabels(agg.columns)
    ax.legend(loc="upper left")

    plt.tight_layout()
    out_path = os.path.join(output_dir, "cost_comparison.png")
    plt.savefig(out_path)
    plt.close()
    print(f"成本对比图已保存至 {out_path}")


def plot_runtime_comparison(df: pd.DataFrame, output_dir: str):
    """折线图：运行时间随实例规模的变化。"""
    fig, ax = plt.subplots(figsize=(10, 6))

    for policy in df["policy"].unique():
        policy_df = df[df["policy"] == policy]
        # 按实例名排序（近似按规模排序）
        policy_df = policy_df.sort_values("instance")

        ax.plot(
            range(len(policy_df)),
            policy_df["mean_time_s"].values,
            marker="o", label=policy, linewidth=2, markersize=5,
        )

    ax.set_ylabel("平均求解时间 (s)")
    ax.set_xlabel("实例（按规模排序）")
    ax.set_title("各实例规模的运行时间变化")
    ax.legend()
    ax.set_yscale("log")

    plt.tight_layout()
    out_path = os.path.join(output_dir, "runtime_comparison.png")
    plt.savefig(out_path)
    plt.close()
    print(f"运行时间对比图已保存至 {out_path}")


def plot_speedup(df: pd.DataFrame, output_dir: str):
    """加速比柱状图。"""
    fig, ax = plt.subplots(figsize=(10, 5))

    # 计算加速比：每个实例的 1S-GPHH 时间 / 2S-GPHH 时间
    single_tree = df[df["policy"] == "1S-GPHH"].set_index("instance")["mean_time_s"]
    two_stage = df[df["policy"] == "2S-GPHH"].set_index("instance")["mean_time_s"]

    common = single_tree.index.intersection(two_stage.index)
    speedup = (single_tree[common] / two_stage[common]).dropna()

    colors = ["green" if v >= 1 else "red" for v in speedup.values]
    bars = ax.bar(range(len(speedup)), speedup.values, color=colors, edgecolor="white")
    ax.axhline(y=1.0, color="gray", linestyle="--", linewidth=1, label="无加速")

    ax.set_ylabel("加速比 (×)")
    ax.set_xlabel("实例")
    ax.set_title("2S-GPHH 相对于 1S-GPHH 的加速比")
    ax.set_xticks(range(len(speedup)))
    ax.set_xticklabels([s[:15] for s in speedup.index], rotation=45, ha="right")

    # 添加数值标签
    for bar, val in zip(bars, speedup.values):
        ax.text(
            bar.get_x() + bar.get_width() / 2,
            bar.get_height() + 0.1,
            f"{val:.1f}×",
            ha="center", va="bottom", fontsize=9,
        )

    plt.tight_layout()
    out_path = os.path.join(output_dir, "speedup.png")
    plt.savefig(out_path)
    plt.close()
    print(f"加速比图已保存至 {out_path}")


def main():
    parser = argparse.ArgumentParser(description="绘制性能对比图")
    parser.add_argument("--input", type=str,
                       default="outputs/main_benchmark_results.csv")
    parser.add_argument("--output-dir", type=str,
                       default="visualization/output_figures")
    args = parser.parse_args()

    if not os.path.exists(args.input):
        print(f"输入文件未找到: {args.input}")
        print("请先运行 experiments/run_main_benchmark.py。")
        return

    os.makedirs(args.output_dir, exist_ok=True)

    df = pd.read_csv(args.input)
    print(f"从 {args.input} 加载了 {len(df)} 行数据")
    print(f"列名: {list(df.columns)}")
    print(f"策略: {list(df['policy'].unique())}")

    plot_cost_comparison(df, args.output_dir)
    plot_runtime_comparison(df, args.output_dir)
    plot_speedup(df, args.output_dir)

    print("\n所有图表已成功生成。")


if __name__ == "__main__":
    main()