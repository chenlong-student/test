# Implementation Plan: 2S-GPHH Two-Stage Transfer Learning for CARP

## 1. Architecture Overview

The project implements a **Two-Stage Genetic Programming Hyper-Heuristic (2S-GPHH)** that decouples CARP routing decisions into:
- **Stage 1 (Proposal Policy)**: A CPP-trained GP tree that scores all unvisited arcs using pure topology features, outputting a **Top-k candidate set**.
- **Stage 2 (Selection Policy)**: A CARP-trained GP tree that evaluates the k+1 options (k arcs + Return-to-Depot) using capacity-aware features, selecting the **final action**.

The existing codebase (`further_improved_gpucarp-python/GPHH_CARP/`) provides:
- Fast stack-machine GP evaluation engine (`evaluate.py`)
- DEAP-based GP infrastructure (`breeding.py`, `toolboxRegister.py`)
- Instance parsing with stochastic sampling (`Instance.py`)
- Terminal/function definitions (`functions.py`, `terminalSetARP.py`, `terminalStateCARP.py`)

**Strategy**: Adapt and extend the existing evaluation engine rather than rewriting. The fast pre-compiled program execution is performance-critical and well-tested.

## 2. Implementation Phases (in order)

### Phase 1: Project Scaffold & Core Data Structures
**Files to create:**
- `requirements.txt` — deap, networkx, numpy, matplotlib, rich, sympy, pyyaml, pandas, seaborn
- `setup.py` — minimal package setup
- `config/gp_config.yaml` — GP parameters (pop size, crossover/mutation rates, tree depth limits, k values)
- `config/env_config.yaml` — CPP/CARP environment config (depot, capacity Q, vehicle count)
- `config/exp_config.yaml` — experiment run config (dataset paths, 30 runs, parallel threads)
- `src/__init__.py`, `src/core/__init__.py`
- `src/core/graph.py` — Node, Edge/Arc classes (adapted from existing `Arc.py`), Graph representation with adjacency and OD matrix
- `src/core/state.py` — Dynamic decision state: VehicleState, RouteState, environment snapshot for GP feature context
- `src/core/solution.py` — Route, Solution classes for cost calculation and route tracking

**Key design decisions:**
- Arc class stays close to the existing `Arc.py` (forward/reverse arc pairing is essential)
- `state.py` generalizes the existing terminal context array approach but supports both CPP (topology-only) and CARP (capacity-aware) feature sets
- Graph uses NetworkX for visualization but keeps the fast Dijkstra-based OD matrix for evaluation

### Phase 2: Simulation Environments
**Files to create:**
- `src/env/__init__.py`
- `src/env/base_env.py` — Abstract base class with `reset()`, `step(action)`, `get_features(arc)`, `is_done()`
- `src/env/cpp_env.py` — CPP environment: single vehicle, no capacity, serves all required arcs. Tracks position, unvisited set, total cost.
- `src/env/carp_env.py` — CARP environment: multi-vehicle, capacity Q, depot return/replenish mechanism. Tracks vehicle positions, remaining capacities, route costs.

**Key design decisions:**
- CPP env uses same graph structure but `capacity = inf`, `num_vehicles = 1`
- CARP env supports multiple vehicles with capacity-aware state transitions
- Both environments use the precomputed OD matrix (shortest paths) from the existing `Instance.py`
- `step()` returns `(next_state, cost, done, info)` following a gym-like interface

### Phase 3: GP Engine (adapted from existing)
**Files to create:**
- `src/gp/__init__.py`
- `src/gp/primitives.py` — Function nodes: add, sub, mul, div (protected), max, min, if, sin, cos, exp, ln, neg, sqrt, abs (copied from existing `functions.py`)
- `src/gp/terminals_cpp.py` — CPP topology-only terminal set:
  - `CFH` (Cost From Here): distance from current position to arc start
  - `CTD` (Cost To Depot): distance from arc end to depot
  - `DC` (Deadheading Cost): direct cost of traversing the arc
  - `SC` (Serving Cost): cost of servicing the arc
  - `FRT` (Fraction Remaining Tasks): proportion of unvisited arcs
  - `DEG_S` (Degree of Start Node): start vertex degree in the graph
  - `DEG_E` (Degree of End Node): end vertex degree  
  - `CLUS` (Clustering Coefficient): local edge density around the arc
  - `BETW` (Betweenness Centrality proxy): how "bridge-like" an arc is
  - `DIST_DEPOT` (Distance to Depot): arc's proximity to depot
  - `ERC` (Ephemeral Random Constant)
- `src/gp/terminals_carp.py` — CARP capacity-aware terminal set (extends CPP set):
  - `RemCap` (Remaining Capacity): current vehicle's remaining capacity
  - `Demand/Cap` (Demand Saturation): arc demand / remaining capacity
  - `DistToDepot` (Return Cost): deadhead distance from current position back to depot
  - `CapRisk` (Capacity Risk): risk score for running out of capacity after serving this arc
  - `FULL` (Fullness): route_load / vehicle_capacity
  - `RQ` (Remaining Query): remaining capacity
  - Plus all CPP topology terminals
- `src/gp/tree_simplifier.py` — SymPy-based tree simplification (adapted from existing `individualSimple.py`)
- `src/gp/gp_engine.py` — Main GP evolution engine (adapted from existing `main_gphh_arp.py` + `breeding.py`):
  - Population initialization (ramped half-and-half)
  - Tournament selection
  - Subtree crossover, subtree mutation, reproduction
  - Elite preservation with diversity radius
  - Multi-threaded fitness evaluation
  - Individual serialization hooks (save best per generation)

**Key design decisions:**
- Preserve the fast stack-machine evaluation architecture from existing `evaluate.py`
- The two terminal sets are separate to prevent feature leakage between stages
- `gp_engine.py` is configurable for both CPP and CARP training modes

### Phase 4: Policy Layer (THE CORE INNOVATION)
**Files to create:**
- `src/policies/__init__.py`
- `src/policies/base_policy.py` — Abstract policy interface: `select_action(state, env) -> action`
- `src/policies/proposal_policy.py` — **CPP Proposal Policy**:
  - Loads a frozen CPP-trained GP tree
  - `propose(state, env) -> List[Arc]`: 
    1. Hard Constraint Gate: filter arcs where `demand > Q_max` (infeasible even with full capacity)
    2. For each remaining unvisited arc, compute topology-only features, evaluate GP tree → priority score
    3. Sort by score, return top-k arcs
    4. If < k arcs remain, pad with nearest-neighbor topological arcs
- `src/policies/selection_policy.py` — **CARP Selection Policy**:
  - Loads a CARP-trained GP tree
  - `select(state, candidates, env) -> action`:
    1. Build k+1 option set: k proposed arcs + Return-to-Depot action
    2. For each option, compute capacity-aware features, evaluate GP tree → priority score
    3. Select best-scoring option
    4. Return-to-Depot is represented as a special action with features: `CFH = dist_to_depot`, `DEM = 0`, etc.
- `src/policies/two_stage_policy.py` — **Composite Two-Stage Policy**:
  - Binds ProposalPolicy + SelectionPolicy
  - `select_action(state, env) -> action`: calls propose → select pipeline
  - Handles edge cases (empty candidate set, all candidates filtered by hard gate)
- `src/policies/baselines.py` — Baseline policies:
  - `SingleTreePolicy` (1S-GPHH): traditional single tree evaluating all arcs with all features
  - `KNNProposalPolicy`: Stage 1 replaced by K-nearest-neighbor by Dijkstra distance
  - `RandomProposalPolicy`: Stage 1 replaced by random k-arc selection
  - `ClassicalHeuristic`: Augment-Merge, Path-Scanning (implemented from literature)

**Key design decisions:**
- The Return-to-Depot action is the key mechanism preventing capacity deadlock
- Hard Constraint Gate runs BEFORE GP tree evaluation (performance optimization)
- Policy serialization uses JSON (human-readable) + pickle (fast loading)

### Phase 5: Utility & Data Layer
**Files to create:**
- `src/utils/__init__.py`
- `src/utils/io_parser.py` — CARP/CPP file parser (adapted from existing `Instance.py` parsers)
- `src/utils/logger.py` — Rich-based console logging with progress bars
- `src/utils/individual_io.py` — Serialization: GP tree ↔ JSON/pickle
- `src/utils/metrics.py` — Statistics: Mean, Std, PDR (Performance Degradation Ratio), Wilcoxon test

### Phase 6: Experiment Scripts
**Files to create:**
- `experiments/train_stage1_proposal.py` — Train CPP Proposal Policy:
  1. Load CPP benchmark instances
  2. Initialize GP engine with CPP terminal set
  3. Run evolution for N generations
  4. Save best individual to `saved_models/proposal_trees/`
- `experiments/train_stage2_selection.py` — Train CARP Selection Policy:
  1. Load frozen Proposal tree
  2. Load CARP benchmark instances
  3. Initialize GP engine with CARP terminal set
  4. In each evaluation: Proposal proposes k candidates → Selection picks one (or Return-to-Depot)
  5. Save best Selection individual to `saved_models/selection_trees/`
- `experiments/run_main_benchmark.py` — **Module 2**: Main performance benchmark
  - 30 independent runs on gdb/val/egl datasets
  - Compare: 2S-GPHH vs 1S-GPHH vs Classical Heuristics vs 2S-GPHH-KNN vs 2S-GPHH-Random
  - Record: Mean Cost, Best Cost, Std Dev, CPU Time per Step, Total Time
- `experiments/run_generalization_test.py` — **Module 3**: Zero-shot generalization
  - Cross-capacity Q test (0.5x, 1.0x, 2.0x Q_base)
  - Cross-scale test (train on N≤30, test on N≥150)
  - Record PDR (Performance Degradation Ratio)
- `experiments/run_ablation_study.py` — **Module 4**: Ablation studies
  - k sensitivity: k ∈ {1, 3, 5, 8, 12, 20}
  - Proposal mechanism ablation: CPP-tree vs KNN vs Random
  - Evolution protocol ablation: Phase-wise vs Co-evolution vs Mixed single-stage
- `experiments/run_baselines_classical.py` — Run classical heuristics (AM, PS)

### Phase 7: Visualization
**Files to create:**
- `visualization/plot_performance.py` — Cost vs Runtime comparison charts
- `visualization/plot_generalization.py` — PDR boxplots, transfer line charts
- `visualization/plot_ablation.py` — k-sensitivity dual-axis plots, convergence curves
- `visualization/plot_tree.py` — GP tree structure rendering (graphviz/networkx export)
- `visualization/plot_routes.py` — Route trajectory visualization (matplotlib)
- `visualization/analyze_terminals.py` — Terminal frequency heatmaps

### Phase 8: Configuration & Orchestration
**Files to create:**
- `README.md` — Project documentation
- `data/` — Benchmark datasets (symlink/copy from existing data folders)
- `saved_models/` — Model storage directories
- `logs/`, `outputs/` — Experiment output directories

## 3. Critical Technical Decisions

### 3.1 Preserving the Fast Evaluation Engine
The existing `evaluate.py` uses a clever pre-compiled stack-machine approach that avoids DEAP's slow tree interpretation. We MUST preserve this. The adaptation:
- Compile each GP tree once into a tuple of instructions
- During route simulation, call `_execute_program(program, context)` for each candidate
- Context is a 16-element list (or extended to ~20 for new terminals)

### 3.2 Two-Stage Evaluation Flow (the novel part)
```
while unvisited_arcs:
    # Stage 1: Proposal
    candidates = proposal_policy.propose(state, env)  # returns k arcs
    
    # Stage 2: Selection  
    action = selection_policy.select(state, candidates, env)  # returns arc or RETURN_TO_DEPOT
    
    if action == RETURN_TO_DEPOT:
        env.return_to_depot_and_replenish()
    else:
        env.service_arc(action)
```

### 3.3 Feature Independence Guarantee
To ensure the Proposal tree cannot "cheat" by learning capacity:
- CPP env sets all capacity features to constant dummy values (0.0 or 1.0)
- CPP terminal set physically excludes capacity terminals
- During freeze-and-transfer, the Proposal tree's compiled program is locked immutable

### 3.4 Return-to-Depot as a Special Action
The Selection policy evaluates k+1 "options" where the (k+1)-th is Return-to-Depot:
- It gets artificial features: CFH = dist(current_pos, depot), DEM = 0, SC = 0, DC = 0
- If selected, the vehicle deadheads back to depot, refills, then the next decision cycle begins
- This cleanly handles the "none of the proposed arcs are capacity-feasible" case

## 4. File Dependency Graph (build order)

```
Phase 1 (no deps):
  requirements.txt, setup.py, config/*.yaml
  src/core/graph.py, src/core/state.py, src/core/solution.py

Phase 2 (depends on Phase 1):
  src/env/base_env.py, src/env/cpp_env.py, src/env/carp_env.py

Phase 3 (depends on Phase 1):
  src/gp/primitives.py, src/gp/terminals_cpp.py, src/gp/terminals_carp.py
  src/gp/tree_simplifier.py, src/gp/gp_engine.py

Phase 4 (depends on Phase 2, 3):
  src/policies/base_policy.py, src/policies/proposal_policy.py
  src/policies/selection_policy.py, src/policies/two_stage_policy.py
  src/policies/baselines.py

Phase 5 (depends on Phase 1):
  src/utils/io_parser.py, src/utils/logger.py
  src/utils/individual_io.py, src/utils/metrics.py

Phase 6 (depends on Phase 4, 5):
  experiments/train_stage1_proposal.py
  experiments/train_stage2_selection.py
  experiments/run_main_benchmark.py
  experiments/run_generalization_test.py
  experiments/run_ablation_study.py
  experiments/run_baselines_classical.py

Phase 7 (depends on Phase 6 output data):
  visualization/plot_*.py

Phase 8:
  README.md, data/ symlinks, directory creation
```

## 5. Estimated File Count & Complexity

| Category | Files | Total Lines (est.) |
|----------|-------|---------------------|
| Config | 3 | ~200 |
| Core data structures | 3 | ~500 |
| Environments | 3 | ~600 |
| GP engine | 6 | ~1200 |
| Policies | 5 | ~1000 |
| Utilities | 4 | ~600 |
| Experiment scripts | 6 | ~1500 |
| Visualization | 6 | ~800 |
| Project files | 3 | ~200 |
| **Total** | **~39** | **~6600** |

## 6. Key Risks & Mitigations

1. **Risk**: The fast evaluation engine doesn't cleanly separate CPP vs CARP feature computation.
   **Mitigation**: Create two separate `_precompute_*_features` functions; the CPP one skips all capacity-related loops.

2. **Risk**: Top-k selection is a bottleneck (sorting N scores per decision).
   **Mitigation**: Use `heapq.nlargest(k, ...)` which is O(N log k) instead of O(N log N).

3. **Risk**: The Proposal tree produces poor candidates, causing frequent Return-to-Depot.
   **Mitigation**: Track rejection rate as a diagnostic metric; if >50%, increase k or trigger co-fine-tuning.

4. **Risk**: Experiment scripts produce inconsistent results due to stochasticity.
   **Mitigation**: Fix all random seeds; use the existing seed management system from `configure_parameters.py`.