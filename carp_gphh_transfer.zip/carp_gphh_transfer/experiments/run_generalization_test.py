#!/usr/bin/env python3
"""
实验模块3：零样本泛化测试。

测试跨容量和跨规模的迁移能力:
1. 跨容量 (Cross-Q): 冻结提议策略，变化测试容量 (0.5x, 1.0x, 2.0x Q_base)
2. 跨规模 (Cross-Scale): 在小规模实例 (N≤30) 上训练，在大规模实例 (N≥150) 上测试

用法:
    python experiments/run_generalization_test.py --dataset egl --runs 30
"""

import os
import sys
import time
import json
import argparse
import math
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from src.gp.gp_engine import GPEngine, GPSettings
from src.env.carp_env import CARPEnv
from src.policies import (
    TwoStagePolicy, ProposalPolicy, SelectionPolicy,
    SingleTreePolicy,
)
from src.utils.io_parser import (
    parse_instance_file, build_graph_from_dict,
    list_instance_files, SeededSample,
)
from src.utils.logger import ExperimentLogger
from src.utils.metrics import compute_mean, compute_std, compute_pdr
from src.utils.individual_io import load_individual


def run_capacity_test(instance, policy, policy_name: str,
                      capacity_multiplier: float, seed: int) -> dict:
    """使用缩放后的容量进行模拟。

    参数:
        instance:             实例对象。
        policy:               策略对象。
        policy_name:          策略名称。
        capacity_multiplier:  容量缩放倍率。
        seed:                 随机种子。

    返回:
        包含 total_cost 等指标的字典。
    """
    base_capacity = getattr(instance, 'capacity', 100.0)
    scaled_capacity = base_capacity * capacity_multiplier

    env = CARPEnv(
        instance,
        depot=instance.depot,
        capacity=scaled_capacity,
        num_vehicles=getattr(instance, 'num_vehicles', 5),
        seed=seed,
    )
    env.reset()

    while not env.is_done():
        action = policy.select_action(env)
        env.step(action)

    total_cost = env.finalize()

    return {
        "policy": policy_name,
        "capacity_multiplier": capacity_multiplier,
        "base_capacity": base_capacity,
        "scaled_capacity": scaled_capacity,
        "total_cost": total_cost,
    }


def main():
    parser = argparse.ArgumentParser(
        description="零样本泛化测试（模块3）"
    )
    parser.add_argument("--dataset", type=str, default="egl",
                       choices=["gdb", "val", "egl"])
    parser.add_argument("--data-dir", type=str,
                       default="data/carp_benchmarks")
    parser.add_argument("--proposal", type=str, required=True,
                       help="冻结的提议树文件路径 (.pkl)")
    parser.add_argument("--selection", type=str, required=True,
                       help="选择树文件路径 (.pkl)")
    parser.add_argument("--single-tree", type=str, default=None,
                       help="用于对比的 1S-GPHH 树文件路径")
    parser.add_argument("--runs", type=int, default=30)
    parser.add_argument("--k-candidates", type=int, default=5)
    parser.add_argument("--output", type=str,
                       default="outputs/generalization_pdr_results.csv")
    args = parser.parse_args()

    logger = ExperimentLogger(
        log_dir="logs",
        experiment_name=f"generalization_{args.dataset}",
    )
    logger.section(f"零样本泛化测试 [{args.dataset}]")

    # --- 加载实例 ---
    data_path = os.path.join(args.data_dir, args.dataset)
    instance_files = list_instance_files(data_path)

    # 如果没有找到数据则报错
    if not instance_files:
        logger.error(f"在 {data_path} 中未找到 .dat 文件")
        return

    logger.info(f"找到 {len(instance_files)} 个实例")

    # --- 加载策略 ---
    settings = GPSettings(problem="CARP", k_candidates=args.k_candidates)
    engine = GPEngine(settings)

    # 2S-GPHH
    prop_ind = load_individual(args.proposal)
    sel_ind = load_individual(args.selection)
    prop_pol = ProposalPolicy(prop_ind, engine, k_candidates=args.k_candidates)
    sel_pol = SelectionPolicy(sel_ind, engine)
    two_stage = TwoStagePolicy(prop_pol, sel_pol, args.k_candidates)

    policies = {"2S-GPHH": two_stage}

    # 1S-GPHH（可选对比）
    if args.single_tree:
        st_ind = load_individual(args.single_tree)
        policies["1S-GPHH"] = SingleTreePolicy(st_ind, engine)

    # --- 容量变体 ---
    capacity_variants = [0.5, 1.0, 2.0]

    # --- 运行跨容量测试 ---
    all_results = []

    for fpath in instance_files[:5]:  # 限制数量以加速
        data = parse_instance_file(fpath)
        instance_name = os.path.basename(fpath).replace(".dat", "")
        base_q = data.get("capacity", 100.0)
        logger.info(f"\n--- 实例: {instance_name} (Q_base={base_q}) ---")

        for policy_name, policy in policies.items():
            for q_mult in capacity_variants:
                costs = []
                for run in range(args.runs):
                    seed = run * 100 + hash(instance_name) % 10000
                    sample = SeededSample(
                        build_graph_from_dict(data), seed,
                        demand_change_rate=0.20,
                        cost_change_rate=0.20,
                    )
                    sample.num_vehicles = data.get("vehicles", 5)
                    sample.capacity = base_q

                    result = run_capacity_test(
                        sample, policy, policy_name, q_mult, seed
                    )
                    costs.append(result["total_cost"])

                # Q=1.0 作为参考基准
                if q_mult == 1.0:
                    reference_costs = costs
                else:
                    pdr = compute_pdr(reference_costs, costs)

                    summary = {
                        "instance": instance_name,
                        "policy": policy_name,
                        "capacity_multiplier": q_mult,
                        "mean_cost": compute_mean(costs),
                        "std_cost": compute_std(costs),
                        "best_cost": min(costs),
                        "pdr_percent": pdr,
                    }
                    all_results.append(summary)

                    logger.info(
                        f"  {policy_name:15s} Q={q_mult:.1f}x: "
                        f"成本={summary['mean_cost']:.1f}, "
                        f"PDR={pdr:+.2f}%"
                    )

    # --- 保存结果 ---
    os.makedirs(os.path.dirname(args.output), exist_ok=True)
    import csv
    if all_results:
        with open(args.output, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=all_results[0].keys())
            writer.writeheader()
            writer.writerows(all_results)

    logger.success(f"结果已保存到 {args.output}")

    # --- 汇总：PDR对比 ---
    logger.section("PDR 汇总")
    for policy_name in sorted(set(r["policy"] for r in all_results)):
        for q_mult in [0.5, 2.0]:
            pdr_vals = [
                r["pdr_percent"] for r in all_results
                if r["policy"] == policy_name
                and abs(r["capacity_multiplier"] - q_mult) < 0.01
            ]
            if pdr_vals:
                logger.info(
                    f"  {policy_name:15s} Q={q_mult:.1f}x: "
                    f"平均 PDR={compute_mean(pdr_vals):+.2f}%"
                )


if __name__ == "__main__":
    main()