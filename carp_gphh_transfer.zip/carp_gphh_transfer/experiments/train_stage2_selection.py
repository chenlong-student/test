#!/usr/bin/env python3
"""
实验：第二阶段训练 — CARP 选择策略。

加载冻结的 CPP 提议树，并在此基础上演化一个
经过 CARP 训练的选择树。选择树学习从提议策略的
top-k 候选弧加上"返回车场"候选中挑选最佳弧。

用法:
    python experiments/train_stage2_selection.py \
        --proposal saved_models/proposal_trees/run_00/best_ind_final.pkl \
        --dataset gdb --seed 0
"""

import os
import sys
import argparse
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from src.gp.gp_engine import GPEngine, GPSettings
from src.utils.io_parser import (
    parse_instance_file, build_graph_from_dict, SeededSample,
    list_instance_files,
)
from src.utils.logger import ExperimentLogger
from src.utils.individual_io import save_individual, load_individual


def create_carp_samples(graph, settings: GPSettings, rng_seed: int):
    """从 CARP 图创建 SeededSample 列表。

    参数:
        graph:       图对象。
        settings:    GP 超参数设置。
        rng_seed:    随机数种子。

    返回:
        SeededSample 列表，包含车辆属性信息。
    """
    import random
    rng = random.Random(rng_seed)

    # 设置图上的车辆属性
    if hasattr(graph, 'capacity'):
        capacity = graph.capacity
    else:
        capacity = 100.0

    if hasattr(graph, 'num_vehicles'):
        num_vehicles = graph.num_vehicles
    else:
        num_vehicles = 5

    samples = []
    for i in range(settings.training_sample_num):
        sample_seed = rng.randint(1, 2**31 - 1)
        sample = SeededSample(
            graph, sample_seed,
            demand_change_rate=settings.demand_change_rate,
            cost_change_rate=settings.cost_change_rate,
        )
        # 注入车辆信息
        sample.num_vehicles = num_vehicles
        sample.capacity = capacity
        sample.vehicles = [
            type(sample.vehicles[0])(
                vehicle_id=i,
                capacity=capacity,
                remaining_capacity=capacity,
                current_position=sample.depot,
            )
            for i in range(num_vehicles)
        ]
        sample.positions = [sample.depot] * num_vehicles
        samples.append(sample)
    return samples


def main():
    parser = argparse.ArgumentParser(
        description="训练第二阶段：CARP 选择策略"
    )
    parser.add_argument("--proposal", type=str, required=True,
                       help="冻结的提议树文件路径 (.pkl)")
    parser.add_argument("--dataset", type=str, default="gdb",
                       choices=["gdb", "val", "egl"],
                       help="训练用的 CARP 数据集")
    parser.add_argument("--data-dir", type=str,
                       default="data/carp_benchmarks",
                       help="CARP 基准数据目录路径")
    parser.add_argument("--seed", type=int, default=0,
                       help="随机种子")
    parser.add_argument("--generations", type=int, default=51,
                       help="演化代数")
    parser.add_argument("--pop-size", type=int, default=1024,
                       help="种群大小")
    parser.add_argument("--k-candidates", type=int, default=5,
                       help="提议策略的 top-k 候选数")
    parser.add_argument("--output-dir", type=str,
                       default="saved_models/selection_trees",
                       help="训练好的选择树的输出目录")
    args = parser.parse_args()

    logger = ExperimentLogger(
        log_dir="logs",
        experiment_name=f"train_selection_{args.dataset}",
    )
    logger.section(f"第二阶段：训练 CARP 选择策略 [{args.dataset}]")

    # --- 加载冻结的提议树 ---
    if not os.path.exists(args.proposal):
        logger.error(f"未找到提议树：{args.proposal}")
        return

    proposal_ind = load_individual(args.proposal)
    logger.info(f"已加载提议树：大小={len(proposal_ind)}, "
                f"高度={proposal_ind.height}")

    # --- GP 设置 ---
    settings = GPSettings(
        problem="CARP",
        seed=args.seed,
        generations=args.generations,
        population_size=args.pop_size,
        use_extended_terminals=True,
        include_erc=True,
        k_candidates=args.k_candidates,
        output_dir=args.output_dir,
    )

    # --- 加载 CARP 实例 ---
    data_path = os.path.join(args.data_dir, args.dataset)
    instance_files = list_instance_files(data_path)

    if not instance_files:
        logger.error(f"在 {data_path} 中未找到 .dat 文件")
        logger.info("请先将数据文件复制到 data/carp_benchmarks/<dataset>/")

    logger.info(f"找到 {len(instance_files)} 个 CARP 实例")

    if not instance_files:
        logger.error("没有可用的 CARP 实例。退出。")
        return

    # --- 创建训练样本 ---
    train_samples = []
    for fpath in instance_files[:min(len(instance_files), 5)]:  # 限制数量以加速
        data = parse_instance_file(fpath)
        graph = build_graph_from_dict(data)
        samples = create_carp_samples(graph, settings, args.seed)
        train_samples.extend(samples)

    logger.info(f"创建了 {len(train_samples)} 个训练样本")

    # --- 测试样本 ---
    data = parse_instance_file(instance_files[0])
    graph = build_graph_from_dict(data)
    test_samples = create_carp_samples(graph, settings, args.seed + 10000)

    # --- 初始化 GP 引擎 ---
    engine = GPEngine(settings)
    engine.set_proposal_policy(proposal_ind)

    # --- 使用冻结的提议策略运行演化 ---
    logger.info(f"开始两阶段演化，k={args.k_candidates}")

    result = engine.run(
        train_instances=train_samples,
        test_instances=test_samples,
        proposal_individual=proposal_ind,
    )

    # --- 保存最优选择树 ---
    best = result["best_individual"]
    prop_name = os.path.splitext(os.path.basename(args.proposal))[0]
    run_dir = os.path.join(
        args.output_dir,
        f"paired_with_{prop_name}",
    )
    os.makedirs(run_dir, exist_ok=True)

    save_individual(
        best,
        os.path.join(run_dir, "best_ind_final"),
        metadata={
            "dataset": args.dataset,
            "seed": args.seed,
            "k_candidates": args.k_candidates,
            "proposal_source": args.proposal,
            "train_fitness": result["best_fitness"],
            "test_fitness": result.get("test_fitness"),
        },
    )

    logger.success(f"训练完成。最优适应度：{result['best_fitness']:.2f}")
    logger.success(f"模型已保存至 {run_dir}/")


if __name__ == "__main__":
    main()