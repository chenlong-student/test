#!/usr/bin/env python3
"""
实验：第一阶段训练 — CPP 提议策略。

在 CPP 实例上演化一个纯拓扑 GP 树。
训练好的树将被冻结并保存，供第二阶段训练使用。

用法:
    python experiments/train_stage1_proposal.py
    python experiments/train_stage1_proposal.py --dataset val --seed 42
"""

import os
import sys
import argparse
from pathlib import Path

# 将项目根目录添加到 Python 路径
PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from src.gp.gp_engine import GPEngine, GPSettings
from src.utils.io_parser import (
    parse_instance_file, build_graph_from_dict, SeededSample,
    list_instance_files,
)
from src.utils.logger import ExperimentLogger
from src.utils.individual_io import save_individual


def create_cpp_samples(graph, settings: GPSettings,
                       rng_seed: int):
    """从 CPP 图创建 SeededSample 列表。

    参数:
        graph:       图对象。
        settings:    GP 超参数设置。
        rng_seed:    随机数种子。

    返回:
        SeededSample 列表，供训练使用。
    """
    import random
    rng = random.Random(rng_seed)

    samples = []
    for i in range(settings.training_sample_num):
        sample_seed = rng.randint(1, 2**31 - 1)
        sample = SeededSample(
            graph, sample_seed,
            demand_change_rate=settings.demand_change_rate,
            cost_change_rate=settings.cost_change_rate,
        )
        samples.append(sample)
    return samples


def main():
    parser = argparse.ArgumentParser(
        description="训练第一阶段：CPP 提议策略"
    )
    parser.add_argument("--dataset", type=str, default="gdb",
                       choices=["gdb", "val", "egl"],
                       help="CPP 训练数据集")
    parser.add_argument("--data-dir", type=str,
                       default="data/cpp_benchmarks",
                       help="CPP 基准数据目录路径")
    parser.add_argument("--seed", type=int, default=0,
                       help="随机种子")
    parser.add_argument("--generations", type=int, default=51,
                       help="演化代数")
    parser.add_argument("--pop-size", type=int, default=1024,
                       help="种群大小")
    parser.add_argument("--output-dir", type=str,
                       default="saved_models/proposal_trees",
                       help="训练好的树的输出目录")
    args = parser.parse_args()

    # --- 初始化设置 ---
    logger = ExperimentLogger(
        log_dir="logs",
        experiment_name=f"train_proposal_{args.dataset}",
    )
    logger.section(f"第一阶段：训练 CPP 提议策略 [{args.dataset}]")

    # --- GP 设置 ---
    settings = GPSettings(
        problem="CPP",
        seed=args.seed,
        generations=args.generations,
        population_size=args.pop_size,
        use_extended_terminals=True,
        include_erc=True,
        output_dir=args.output_dir,
    )

    # --- 加载 CPP 实例 ---
    data_path = os.path.join(args.data_dir, args.dataset)
    instance_files = list_instance_files(data_path)
    logger.info(f"在 {data_path} 中找到 {len(instance_files)} 个 CPP 实例")

    if not instance_files:
        logger.error(f"在 {data_path} 中未找到 .dat 文件")
        logger.info("请先将数据文件复制到 data/cpp_benchmarks/<dataset>/")
        return

    if not instance_files:
        logger.error("没有可用的实例。退出。")
        return

    # --- 创建训练样本 ---
    train_samples = []
    for fpath in instance_files:
        data = parse_instance_file(fpath)
        graph = build_graph_from_dict(data)
        samples = create_cpp_samples(graph, settings, args.seed)
        train_samples.extend(samples)

    logger.info(f"从 {len(instance_files)} 个实例创建了 "
                f"{len(train_samples)} 个训练样本")

    # --- 初始化 GP 引擎 ---
    engine = GPEngine(settings)

    # --- 创建测试样本（来自第一个实例） ---
    data = parse_instance_file(instance_files[0])
    graph = build_graph_from_dict(data)
    test_samples = create_cpp_samples(graph, settings, args.seed + 10000)

    # --- 运行演化 ---
    logger.info(f"开始演化：{settings.generations} 代，"
                f"种群大小={settings.population_size}")

    result = engine.run(
        train_instances=train_samples,
        test_instances=test_samples,
    )

    # --- 保存最优个体 ---
    best = result["best_individual"]
    run_dir = os.path.join(args.output_dir, f"run_{args.seed:02d}")
    os.makedirs(run_dir, exist_ok=True)

    save_individual(
        best,
        os.path.join(run_dir, "best_ind_final"),
        metadata={
            "dataset": args.dataset,
            "seed": args.seed,
            "generations": args.generations,
            "train_fitness": result["best_fitness"],
            "test_fitness": result.get("test_fitness"),
            "stats": result["stats_history"][-1] if result["stats_history"] else {},
        },
    )

    # --- 保存各代统计信息 ---
    import json
    stats_path = os.path.join(run_dir, "evolution_stats.json")
    with open(stats_path, "w", encoding="utf-8") as f:
        json.dump(result["stats_history"], f, indent=2)

    logger.success(f"训练完成。最优适应度：{result['best_fitness']:.2f}")
    logger.success(f"模型已保存至 {run_dir}/")


if __name__ == "__main__":
    main()