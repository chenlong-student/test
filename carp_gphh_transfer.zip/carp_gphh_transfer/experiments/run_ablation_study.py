#!/usr/bin/env python3
"""
实验模块4：消融实验。

三个消融维度：
1. k-灵敏度：k ∈ {1, 3, 5, 8, 12, 20}
2. 提案机制：CPP树 vs KNN vs 随机
3. 演化协议：分阶段 vs 协同演化 vs 混合单阶段

用法:
    python experiments/run_ablation_study.py --ablation k_sensitivity --dataset gdb
"""

import os
import sys
import time
import json
import argparse
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from src.gp.gp_engine import GPEngine, GPSettings
from src.env.carp_env import CARPEnv
from src.policies import (
    TwoStagePolicy, ProposalPolicy, SelectionPolicy,
    SingleTreePolicy, KNNProposalPolicy, RandomProposalPolicy,
)
from src.utils.io_parser import (
    parse_instance_file, build_graph_from_dict,
    list_instance_files, SeededSample,
)
from src.utils.logger import ExperimentLogger
from src.utils.metrics import compute_mean, compute_std
from src.utils.individual_io import load_individual


def run_k_sensitivity(instance_files, proposal_path, selection_path,
                      args, logger, engine):
    """消融实验1：k的灵敏度分析。"""
    logger.section("消融实验1：k-灵敏度分析")

    k_values = [1, 3, 5, 8, 12, 20]
    all_results = []

    prop_ind = load_individual(proposal_path)
    sel_ind = load_individual(selection_path)

    for instance_file in instance_files[:3]:
        data = parse_instance_file(instance_file)
        instance_name = os.path.basename(instance_file).replace(".dat", "")

        for k in k_values:
            # 使用当前k值构建策略
            settings = GPSettings(problem="CARP", k_candidates=k)
            local_engine = GPEngine(settings)

            prop_pol = ProposalPolicy(
                deepcopy(prop_ind), local_engine, k_candidates=k
            )
            sel_pol = SelectionPolicy(
                deepcopy(sel_ind), local_engine
            )
            policy = TwoStagePolicy(prop_pol, sel_pol, k)

            costs = []
            times = []
            rejection_rates = []

            for run in range(args.runs):
                seed = run * 100
                sample = SeededSample(
                    build_graph_from_dict(data), seed,
                    demand_change_rate=0.20,
                    cost_change_rate=0.20,
                )
                sample.num_vehicles = data.get("vehicles", 5)
                sample.capacity = data.get("capacity", 100.0)

                env = CARPEnv(
                    sample,
                    depot=sample.depot,
                    capacity=sample.capacity,
                    num_vehicles=sample.num_vehicles,
                    seed=seed,
                )
                env.reset()

                t_start = time.perf_counter()
                policy.reset_stats()
                while not env.is_done():
                    action = policy.select_action(env)
                    env.step(action)
                total_cost = env.finalize()
                total_time = time.perf_counter() - t_start

                costs.append(total_cost)
                times.append(total_time)
                rejection_rates.append(policy.get_rejection_rate())

            result = {
                "instance": instance_name,
                "k": k,
                "mean_cost": compute_mean(costs),
                "best_cost": min(costs),
                "std_cost": compute_std(costs),
                "mean_time_s": compute_mean(times),
                "mean_rejection_rate": compute_mean(rejection_rates),
            }
            all_results.append(result)
            logger.info(
                f"  k={k:2d}: 成本={result['mean_cost']:.1f}, "
                f"时间={result['mean_time_s']:.4f}s, "
                f"拒绝率={result['mean_rejection_rate']:.3f}"
            )

    # 保存结果
    output = args.output or "outputs/ablation_k_sensitivity.csv"
    save_csv(all_results, output)
    logger.success(f"结果已保存到 {output}")
    return all_results


def run_proposal_ablation(instance_files, proposal_path, selection_path,
                          args, logger, engine):
    """消融实验2：提案机制对比。"""
    logger.section("消融实验2：提案机制消融")

    sel_ind = load_individual(selection_path)
    prop_ind = load_individual(proposal_path) if proposal_path else None

    # 三种提案模式
    modes = {}

    # 模式A：CPP树提案
    if prop_ind:
        prop_pol = ProposalPolicy(
            deepcopy(prop_ind), engine, k_candidates=args.k_candidates
        )
        sel_pol_a = SelectionPolicy(deepcopy(sel_ind), engine)
        modes["CPP-Tree"] = TwoStagePolicy(prop_pol, sel_pol_a, args.k_candidates)

    # 模式B：KNN提案
    knn_prop = KNNProposalPolicy(k_candidates=args.k_candidates)
    sel_pol_b = SelectionPolicy(deepcopy(sel_ind), engine)
    modes["KNN"] = TwoStagePolicy(knn_prop, sel_pol_b, args.k_candidates)

    # 模式C：随机提案
    rand_prop = RandomProposalPolicy(k_candidates=args.k_candidates)
    sel_pol_c = SelectionPolicy(deepcopy(sel_ind), engine)
    modes["Random"] = TwoStagePolicy(rand_prop, sel_pol_c, args.k_candidates)

    all_results = []

    for instance_file in instance_files[:3]:
        data = parse_instance_file(instance_file)
        instance_name = os.path.basename(instance_file).replace(".dat", "")

        for mode_name, policy in modes.items():
            costs = []

            for run in range(args.runs):
                seed = run * 100
                sample = SeededSample(
                    build_graph_from_dict(data), seed,
                    demand_change_rate=0.20, cost_change_rate=0.20,
                )
                sample.num_vehicles = data.get("vehicles", 5)
                sample.capacity = data.get("capacity", 100.0)

                env = CARPEnv(
                    sample, depot=sample.depot,
                    capacity=sample.capacity,
                    num_vehicles=sample.num_vehicles,
                    seed=seed,
                )
                env.reset()
                while not env.is_done():
                    action = policy.select_action(env)
                    env.step(action)
                costs.append(env.finalize())

            result = {
                "instance": instance_name,
                "proposal_mode": mode_name,
                "mean_cost": compute_mean(costs),
                "best_cost": min(costs),
                "std_cost": compute_std(costs),
            }
            all_results.append(result)
            logger.info(
                f"  {mode_name:12s}: 成本={result['mean_cost']:.1f} "
                f"± {result['std_cost']:.1f}"
            )

    output = args.output or "outputs/ablation_proposal.csv"
    save_csv(all_results, output)
    logger.success(f"结果已保存到 {output}")
    return all_results


def run_evolution_protocol_ablation(args, logger):
    """消融实验3：演化协议对比。

    这需要实际的训练运行，因此更复杂。
    我们比较：
    - 协议1：分阶段（冻结提案 → 训练选择）
    - 协议2：协同演化（两棵树同时演化）
    - 协议3：单阶段混合（一棵树，全部特征）
    """
    logger.section("消融实验3：演化协议对比")
    logger.warning(
        "演化协议消融需要完整的训练运行。"
        "这是一个占位符——请分别运行 train_stage1 和 train_stage2，"
        "然后从 evolution_stats.json 中比较收敛曲线。"
    )

    # 此消融实验输出操作说明，而非内联运行
    logger.info("运行协议2（协同演化）：")
    logger.info("  修改 gp_engine.py 使两棵树同时演化")
    logger.info("运行协议3（单阶段）：")
    logger.info("  使用 problem='CARP' 且不指定提案树的训练脚本")

    return []


def save_csv(results: list, filepath: str):
    """保存结果为CSV文件。"""
    import csv
    if not results:
        return
    os.makedirs(os.path.dirname(filepath), exist_ok=True)
    with open(filepath, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=results[0].keys())
        writer.writeheader()
        writer.writerows(results)


def deepcopy(obj):
    """DEAP个体的安全深拷贝。"""
    from copy import deepcopy as dc
    return dc(obj)


def main():
    parser = argparse.ArgumentParser(
        description="消融实验（模块4）"
    )
    parser.add_argument("--ablation", type=str, default="k_sensitivity",
                       choices=["k_sensitivity", "proposal", "evolution",
                                "all"],
                       help="要运行的消融实验")
    parser.add_argument("--dataset", type=str, default="gdb")
    parser.add_argument("--data-dir", type=str,
                       default="data/carp_benchmarks")
    parser.add_argument("--proposal", type=str, default=None,
                       help="提案树文件路径 (.pkl)")
    parser.add_argument("--selection", type=str, required=True,
                       help="选择树文件路径 (.pkl)")
    parser.add_argument("--runs", type=int, default=10)
    parser.add_argument("--k-candidates", type=int, default=5)
    parser.add_argument("--output", type=str, default=None)
    args = parser.parse_args()

    logger = ExperimentLogger(
        log_dir="logs",
        experiment_name=f"ablation_{args.ablation}",
    )

    # 加载实例
    data_path = os.path.join(args.data_dir, args.dataset)
    instance_files = list_instance_files(data_path)

    if not instance_files:
        logger.error(f"在 {data_path} 中未找到 .dat 文件")
        return

    logger.info(f"找到 {len(instance_files)} 个实例")

    # GP引擎
    settings = GPSettings(problem="CARP", k_candidates=args.k_candidates)
    engine = GPEngine(settings)

    if args.ablation in ("k_sensitivity", "all"):
        run_k_sensitivity(
            instance_files, args.proposal, args.selection,
            args, logger, engine,
        )

    if args.ablation in ("proposal", "all"):
        run_proposal_ablation(
            instance_files, args.proposal, args.selection,
            args, logger, engine,
        )

    if args.ablation in ("evolution", "all"):
        run_evolution_protocol_ablation(args, logger)


if __name__ == "__main__":
    main()