#!/usr/bin/env python3
"""
实验模块2：主要性能基准测试。

将2S-GPHH与所有基线方法在gdb、val和egl数据集上进行比较。
每个方法在每个实例上独立运行30次。

指标：
- 平均成本、最佳成本、标准差
- 每步CPU时间、总求解时间
- 相对1S-GPHH的加速比

用法:
    python experiments/run_main_benchmark.py --dataset gdb --runs 30
"""

import os
import sys
import time
import json
import argparse
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from src.gp.gp_engine import GPEngine, GPSettings
from src.env.carp_env import CARPEnv
from src.policies import (
    TwoStagePolicy, ProposalPolicy, SelectionPolicy,
    SingleTreePolicy, KNNProposalPolicy, RandomProposalPolicy,
    AugmentMergeHeuristic, PathScanningHeuristic,
)
from src.utils.io_parser import (
    parse_instance_file, build_graph_from_dict,
    list_instance_files, SeededSample,
)
from src.utils.logger import ExperimentLogger
from src.utils.metrics import compute_mean, compute_std, compute_speedup_ratio
from src.utils.individual_io import load_individual


def run_single_instance(instance, policy, policy_name: str,
                        seed: int) -> dict:
    """运行单次仿真并收集指标。"""
    env = CARPEnv(
        instance,
        depot=instance.depot,
        capacity=getattr(instance, 'capacity', 100.0),
        num_vehicles=getattr(instance, 'num_vehicles', 5),
        seed=seed,
    )
    env.reset()

    t_start = time.perf_counter()
    step_times = []

    while not env.is_done():
        t_step = time.perf_counter()
        action = policy.select_action(env)
        env.step(action)
        step_times.append(time.perf_counter() - t_step)

    total_cost = env.finalize()
    total_time = time.perf_counter() - t_start

    return {
        "policy": policy_name,
        "total_cost": total_cost,
        "total_time_s": total_time,
        "n_steps": len(step_times),
        "time_per_step_ms": (sum(step_times) / len(step_times) * 1000
                            if step_times else 0.0),
    }


def run_classical_heuristic(instance, heuristic, name: str) -> dict:
    """运行经典启发式算法（非GP，完整求解）。"""
    env = CARPEnv(
        instance,
        depot=instance.depot,
        capacity=getattr(instance, 'capacity', 100.0),
        num_vehicles=getattr(instance, 'num_vehicles', 5),
        seed=0,
    )
    env.reset()

    t_start = time.perf_counter()
    solution = heuristic.solve(env)
    total_time = time.perf_counter() - t_start

    return {
        "policy": name,
        "total_cost": solution.total_cost,
        "total_time_s": total_time,
        "n_steps": solution.total_arcs_serviced,
        "time_per_step_ms": 0.0,
    }


def main():
    parser = argparse.ArgumentParser(
        description="主要性能基准测试（模块2）"
    )
    parser.add_argument("--dataset", type=str, default="gdb",
                       choices=["gdb", "val", "egl"],
                       help="测试的数据集")
    parser.add_argument("--data-dir", type=str,
                       default="data/carp_benchmarks")
    parser.add_argument("--proposal", type=str, default=None,
                       help="提案树文件路径 (.pkl)")
    parser.add_argument("--selection", type=str, default=None,
                       help="选择树文件路径 (.pkl)")
    parser.add_argument("--single-tree", type=str, default=None,
                       help="1S-GPHH树文件路径 (.pkl)")
    parser.add_argument("--runs", type=int, default=30,
                       help="独立运行次数")
    parser.add_argument("--k-candidates", type=int, default=5)
    parser.add_argument("--output", type=str,
                       default="outputs/main_benchmark_results.csv")
    args = parser.parse_args()

    logger = ExperimentLogger(
        log_dir="logs",
        experiment_name=f"benchmark_{args.dataset}",
    )
    logger.section(f"主要基准测试: {args.dataset} 数据集")

    # --- 加载实例 ---
    data_path = os.path.join(args.data_dir, args.dataset)
    instance_files = list_instance_files(data_path)

    if not instance_files:
        logger.error(f"在 {data_path} 中未找到 .dat 文件")
        return

    logger.info(f"找到 {len(instance_files)} 个实例")

    if not instance_files:
        logger.error("没有可用实例。退出。")
        return

    # --- 加载策略 ---
    policies = {}

    # GP引擎（所有基于GP的策略共享）
    settings = GPSettings(problem="CARP", k_candidates=args.k_candidates)
    engine = GPEngine(settings)

    # 2S-GPHH
    if args.proposal and args.selection:
        prop_ind = load_individual(args.proposal)
        sel_ind = load_individual(args.selection)
        prop_pol = ProposalPolicy(prop_ind, engine, k_candidates=args.k_candidates)
        sel_pol = SelectionPolicy(sel_ind, engine)
        policies["2S-GPHH"] = TwoStagePolicy(prop_pol, sel_pol, args.k_candidates)
        logger.info("已加载 2S-GPHH 策略")

    # 1S-GPHH
    if args.single_tree:
        st_ind = load_individual(args.single_tree)
        policies["1S-GPHH"] = SingleTreePolicy(st_ind, engine)
        logger.info("已加载 1S-GPHH 策略")

    # KNN基线 + CARP选择
    if args.selection:
        sel_ind = load_individual(args.selection)
        sel_pol_2 = SelectionPolicy(sel_ind, engine)
        knn_prop = KNNProposalPolicy(k_candidates=args.k_candidates)
        policies["2S-GPHH-KNN"] = TwoStagePolicy(knn_prop, sel_pol_2, args.k_candidates)

        rand_prop = RandomProposalPolicy(k_candidates=args.k_candidates)
        policies["2S-GPHH-Random"] = TwoStagePolicy(rand_prop, sel_pol_2, args.k_candidates)

    # 经典启发式算法
    policies["Augment-Merge"] = AugmentMergeHeuristic()
    policies["Path-Scanning"] = PathScanningHeuristic()

    logger.info(f"待测试的策略: {list(policies.keys())}")

    # --- 运行基准测试 ---
    all_results = []

    for fpath in instance_files:
        data = parse_instance_file(fpath)
        instance_name = os.path.basename(fpath).replace(".dat", "")
        logger.info(f"\n--- 实例: {instance_name} ---")

        for policy_name, policy in policies.items():
            instance_results = []

            for run in range(args.runs):
                seed = run * 100 + hash(instance_name) % 10000

                if policy_name in ("Augment-Merge", "Path-Scanning"):
                    # 经典启发式算法是确定性的 → 只运行一次
                    if run == 0:
                        result = run_classical_heuristic(
                            build_graph_from_dict(data),
                            policy, policy_name,
                        )
                        # 复制结果用于统计
                        instance_results = [result] * args.runs
                    break

                sample = SeededSample(
                    build_graph_from_dict(data),
                    seed,
                    demand_change_rate=0.20,
                    cost_change_rate=0.20,
                )
                sample.num_vehicles = data.get("vehicles", 5)
                sample.capacity = data.get("capacity", 100.0)

                result = run_single_instance(sample, policy, policy_name, seed)
                instance_results.append(result)

            # 汇总统计
            costs = [r["total_cost"] for r in instance_results]
            times = [r["total_time_s"] for r in instance_results]

            summary = {
                "instance": instance_name,
                "policy": policy_name,
                "n_runs": len(instance_results),
                "mean_cost": compute_mean(costs),
                "best_cost": min(costs),
                "std_cost": compute_std(costs),
                "mean_time_s": compute_mean(times),
                "mean_time_per_step_ms": compute_mean(
                    [r["time_per_step_ms"] for r in instance_results]
                ),
            }
            all_results.append(summary)
            logger.info(
                f"  {policy_name:20s}: "
                f"均值={summary['mean_cost']:.1f}, "
                f"最优={summary['best_cost']:.1f}, "
                f"标准差={summary['std_cost']:.1f}, "
                f"时间={summary['mean_time_s']:.3f}s"
            )

    # --- 保存结果 ---
    os.makedirs(os.path.dirname(args.output), exist_ok=True)

    import csv
    if all_results:
        with open(args.output, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=all_results[0].keys())
            writer.writeheader()
            writer.writerows(all_results)

    logger.success(f"结果已保存到 {args.output}")

    # --- 汇总表 ---
    logger.section("汇总")
    for policy_name in sorted(set(r["policy"] for r in all_results)):
        policy_results = [r for r in all_results if r["policy"] == policy_name]
        avg_cost = compute_mean([r["mean_cost"] for r in policy_results])
        avg_time = compute_mean([r["mean_time_s"] for r in policy_results])
        logger.info(f"  {policy_name:20s}: 平均成本={avg_cost:.1f}, "
                    f"平均时间={avg_time:.4f}s")


if __name__ == "__main__":
    main()