#!/usr/bin/env python3
"""
在 CARP 基准实例上运行经典运筹学启发式算法。

在数据集中的所有实例上运行 Augment-Merge 和 Path-Scanning 算法。
这些结果作为解质量对比的下界参考。

用法:
    python experiments/run_baselines_classical.py --dataset gdb
"""

import os
import sys
import time
import argparse
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from src.env.carp_env import CARPEnv
from src.policies.baselines import AugmentMergeHeuristic, PathScanningHeuristic
from src.utils.io_parser import (
    parse_instance_file, build_graph_from_dict,
    list_instance_files, SeededSample,
)
from src.utils.logger import ExperimentLogger
from src.utils.metrics import compute_mean, compute_std


def main():
    parser = argparse.ArgumentParser(
        description="在 CARP 基准实例上运行经典启发式算法"
    )
    parser.add_argument("--dataset", type=str, default="gdb",
                       choices=["gdb", "val", "egl"])
    parser.add_argument("--data-dir", type=str,
                       default="data/carp_benchmarks")
    parser.add_argument("--runs", type=int, default=30,
                       help="随机变体的运行次数（确定性方法默认1）")
    parser.add_argument("--output", type=str,
                       default="outputs/classical_baselines.csv")
    args = parser.parse_args()

    logger = ExperimentLogger(
        log_dir="logs",
        experiment_name=f"classical_{args.dataset}",
    )
    logger.section(f"经典启发式算法 [{args.dataset}]")

    # 加载实例
    data_path = os.path.join(args.data_dir, args.dataset)
    instance_files = list_instance_files(data_path)

    if not instance_files:
        logger.error(f"在 {data_path} 中未找到 .dat 文件")
        return

    logger.info(f"在 {len(instance_files)} 个实例上运行")

    heuristics = {
        "Augment-Merge": AugmentMergeHeuristic(),
        "Path-Scanning": PathScanningHeuristic(),
    }

    all_results = []

    for fpath in instance_files:
        data = parse_instance_file(fpath)
        instance_name = os.path.basename(fpath).replace(".dat", "")

        for h_name, heuristic in heuristics.items():
            costs = []
            times = []
            routes_used = []

            for run in range(args.runs):
                seed = run * 100
                sample = SeededSample(
                    build_graph_from_dict(data), seed,
                    demand_change_rate=0.20,
                    cost_change_rate=0.20,
                )
                sample.num_vehicles = data.get("vehicles", 5)
                sample.capacity = data.get("capacity", 100.0)

                env = CARPEnv(
                    sample, depot=sample.depot,
                    capacity=sample.capacity,
                    num_vehicles=sample.num_vehicles,
                    seed=seed,
                )
                env.reset()

                t_start = time.perf_counter()
                solution = heuristic.solve(env)
                elapsed = time.perf_counter() - t_start

                costs.append(solution.total_cost)
                times.append(elapsed)
                routes_used.append(solution.num_routes_used)

            result = {
                "instance": instance_name,
                "heuristic": h_name,
                "mean_cost": compute_mean(costs),
                "best_cost": min(costs),
                "std_cost": compute_std(costs),
                "mean_time_s": compute_mean(times),
                "mean_routes": compute_mean(routes_used),
            }
            all_results.append(result)
            logger.info(
                f"  {instance_name:15s} {h_name:15s}: "
                f"Cost={result['best_cost']:.1f}, "
                f"Routes={result['mean_routes']:.1f}, "
                f"Time={result['mean_time_s']:.4f}s"
            )

    # 保存结果
    import csv
    os.makedirs(os.path.dirname(args.output), exist_ok=True)
    if all_results:
        with open(args.output, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=all_results[0].keys())
            writer.writeheader()
            writer.writerows(all_results)

    logger.success(f"结果已保存至 {args.output}")


if __name__ == "__main__":
    main()