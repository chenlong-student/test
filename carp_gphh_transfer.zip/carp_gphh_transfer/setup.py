from setuptools import setup, find_packages

setup(
    name="carp_gphh_transfer",
    version="0.1.0",
    description="面向弧路径问题的两阶段GPHH：CPP到CARP的跨问题迁移学习",
    author="",
    packages=find_packages(where="."),
    package_dir={"": "."},
    python_requires=">=3.9",
    install_requires=[
        "deap>=1.4.1",
        "networkx>=3.1",
        "numpy>=1.24.0",
        "matplotlib>=3.7.0",
        "rich>=13.0.0",
        "sympy>=1.12",
        "pyyaml>=6.0",
        "pandas>=2.0.0",
        "seaborn>=0.12.0",
        "scipy>=1.10.0",
        "tqdm>=4.65.0",
        "joblib>=1.2.0",
    ],
)